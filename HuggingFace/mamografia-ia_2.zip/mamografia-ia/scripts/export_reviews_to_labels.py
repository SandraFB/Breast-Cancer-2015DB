"""Cierra el ciclo de aprendizaje: descarga las revisiones de los radiólogos desde Supabase
(vista `labeled_for_training`) y genera un CSV compatible con la plantilla de etiquetas, más las
imágenes, para re-entrenar los modelos.

  SUPABASE_URL=... SUPABASE_SERVICE_ROLE_KEY=... \
  python scripts/export_reviews_to_labels.py --out data/labels/labels_supabase.csv --images data/raw/supabase
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path

import pandas as pd


def main():
    from supabase import create_client
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="data/labels/labels_supabase.csv")
    ap.add_argument("--images", default="data/raw/supabase")
    args = ap.parse_args()
    sb = create_client(os.environ["SUPABASE_URL"], os.environ["SUPABASE_SERVICE_ROLE_KEY"])
    rows = sb.table("labeled_for_training").select("*").execute().data
    if not rows:
        print("Sin revisiones todavía.")
        return
    img_dir = Path(args.images)
    img_dir.mkdir(parents=True, exist_ok=True)
    out = []
    for r in rows:
        fname = f"{r['image_id']}{Path(r['storage_path']).suffix or '.png'}"
        (img_dir / fname).write_bytes(sb.storage.from_("mamografias").download(r["storage_path"]))
        out.append({"image_id": r["image_id"], "filename": fname, "group_id": r["image_id"],
                    "laterality": r["laterality"], "projection": r["projection"],
                    "birads": r["birads"], "pathology": r["pathology"],
                    "biopsy_confirmed": int(bool(r["biopsy_confirmed"])), "density": r["density"],
                    "lesion_type": r["lesion_type"], "report_text": r["report_text"] or ""})
    pd.DataFrame(out).to_csv(args.out, index=False, encoding="utf-8-sig")
    print(f"{len(out)} imágenes revisadas -> {args.out}. Preprocese {img_dir} y reentrene.")


if __name__ == "__main__":
    main()
