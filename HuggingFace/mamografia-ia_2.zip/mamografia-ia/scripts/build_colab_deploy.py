"""Genera notebooks/MamoIA_Deploy_HF.ipynb: publica la API (código + modelos de Drive) en un
Hugging Face Space y la prueba. Ejecutar: python scripts/build_colab_deploy.py"""
import base64
import io
import textwrap
import zipfile
from pathlib import Path

import nbformat as nbf

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "notebooks" / "MamoIA_Deploy_HF.ipynb"


def bundle_b64() -> str:
    buf = io.BytesIO()
    files = (list((ROOT / "src").rglob("*.py")) + list((ROOT / "configs").glob("*.yaml"))
             + list((ROOT / "api").glob("*.py")) + [ROOT / "pyproject.toml"])
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(files):
            if "__pycache__" not in p.parts:
                z.write(p, p.relative_to(ROOT))
        for p in (ROOT / "deploy" / "hf_space").iterdir():   # Dockerfile y README del Space en la raíz
            z.write(p, p.name)
    return "\n".join(textwrap.wrap(base64.b64encode(buf.getvalue()).decode(), 100))


cells = []
md = lambda s: cells.append(nbf.v4.new_markdown_cell(s.strip()))  # noqa: E731
code = lambda s: cells.append(nbf.v4.new_code_cell(s.strip()))    # noqa: E731

md("""
# MamoIA · Publicar la API en Hugging Face Spaces

Toma los modelos entrenados de `MyDrive/MamoIA/export_api` y publica la API de inferencia en un
**Space Docker** de tu cuenta de Hugging Face. Al final imprime la **URL** y la **clave** que hay que
poner como *secrets* en Lovable (`MAMOIA_API_URL` y `MAMOIA_API_KEY`).

**Antes de ejecutar**
1. En <https://huggingface.co/settings/tokens> crea un token con permiso **Write**.
2. En Colab → 🔑 *Secretos*, agrega `HF_TOKEN` (y, si usarán Claude, `ANTHROPIC_API_KEY`) y activa el
   acceso del notebook.
3. No hace falta GPU: Entorno de ejecución → CPU.

> El Space es **público** (cualquiera ve el código) pero la API exige la clave `x-api-key`. Las
> imágenes no se guardan en el Space: se procesan en memoria y se descartan.
""")
code("""
# ======================= PARÁMETROS =======================
HF_USER    = "QSandradelaf"
SPACE_NAME = "mammoai-api"
WORK       = "/content/drive/MyDrive/MamoIA"
EXPORT     = f"{WORK}/export_api"              # classifier.pt, captioner.pt, model_card.json
DICOM_URL  = "https://drive.google.com/drive/folders/1V7nw-jPS-Exgji956VLryd_3kqeKzMk_?usp=drive_link"
# ===========================================================
SPACE_ID  = f"{HF_USER}/{SPACE_NAME}"
SPACE_URL = f"https://{HF_USER.lower()}-{SPACE_NAME.lower()}.hf.space"
print(SPACE_ID, "->", SPACE_URL)
""")
md("## 1 · Drive, token y paquete")
code("""
import os, sys, subprocess, secrets, json, shutil, time, io, zipfile, base64, glob
from google.colab import drive, userdata
drive.mount("/content/drive")
subprocess.run([sys.executable, "-m", "pip", "install", "-q", "huggingface_hub>=0.24", "requests"], check=True)
HF_TOKEN = userdata.get("HF_TOKEN")
try:
    ANTHROPIC = userdata.get("ANTHROPIC_API_KEY")
except Exception:
    ANTHROPIC = ""
for f in ("classifier.pt", "captioner.pt"):
    assert os.path.exists(f"{EXPORT}/{f}"), f"Falta {EXPORT}/{f}: ejecuta antes el notebook de entrenamiento"
print("Modelos encontrados:", os.listdir(EXPORT))
""")
code("""
#@title 📦 Código de la API (embebido; ejecútala)
BUNDLE = \"\"\"
""" + bundle_b64() + """
\"\"\"
SPACE_DIR = "/content/space"
shutil.rmtree(SPACE_DIR, ignore_errors=True)
zipfile.ZipFile(io.BytesIO(base64.b64decode(BUNDLE))).extractall(SPACE_DIR)
os.makedirs(f"{SPACE_DIR}/checkpoints", exist_ok=True)
for f in ("classifier.pt", "captioner.pt", "model_card.json"):
    if os.path.exists(f"{EXPORT}/{f}"):
        shutil.copy(f"{EXPORT}/{f}", f"{SPACE_DIR}/checkpoints/{f}")
print(sorted(os.listdir(SPACE_DIR)), sorted(os.listdir(f"{SPACE_DIR}/checkpoints")))
""")
cells[-1].metadata["cellView"] = "form"
md("## 2 · Crear / actualizar el Space y sus secretos")
code("""
from huggingface_hub import HfApi
api = HfApi(token=HF_TOKEN)
print("Sesión HF:", api.whoami()["name"])
api.create_repo(SPACE_ID, repo_type="space", space_sdk="docker", exist_ok=True, private=False)

# la clave se genera una vez y se guarda en tu Drive (no se publica)
key_file = f"{EXPORT}/mamoia_api_key.txt"
if not os.path.exists(key_file):
    open(key_file, "w").write(secrets.token_urlsafe(32))
API_KEY = open(key_file).read().strip()
api.add_space_secret(SPACE_ID, "MAMOIA_API_KEY", API_KEY)
if ANTHROPIC:
    api.add_space_secret(SPACE_ID, "ANTHROPIC_API_KEY", ANTHROPIC)
    api.add_space_variable(SPACE_ID, "CLAUDE_MODEL", "claude-sonnet-5-5")

api.upload_folder(repo_id=SPACE_ID, repo_type="space", folder_path=SPACE_DIR,
                  commit_message="MamoIA API + modelos")
print("Subido. Construyendo la imagen Docker (5-10 min la primera vez)…")
""")
code("""
# espera a que el Space esté en RUNNING
for i in range(90):
    st = api.get_space_runtime(SPACE_ID).stage
    print(f"\\r{i * 20:4d}s  estado: {st}      ", end="")
    if st == "RUNNING":
        break
    if st in ("BUILD_ERROR", "RUNTIME_ERROR", "CONFIG_ERROR"):
        raise RuntimeError(f"El Space falló ({st}). Revisa los logs en https://huggingface.co/spaces/{SPACE_ID}")
    time.sleep(20)
print()
""")
md("## 3 · Probar la API con una mastografía real")
code("""
import requests, re
H = {"x-api-key": API_KEY}
for _ in range(10):
    try:
        r = requests.get(f"{SPACE_URL}/health", timeout=60); break
    except Exception:
        time.sleep(15)
print(json.dumps(r.json(), indent=1, ensure_ascii=False)[:800])

fid = re.search(r"folders/([A-Za-z0-9_-]+)", DICOM_URL).group(1)
cands = glob.glob(f"/content/drive/.shortcut-targets-by-id/{fid}/*/Paciente_0*/*")
if cands:
    t = time.time()
    with open(sorted(cands)[0], "rb") as f:
        r = requests.post(f"{SPACE_URL}/analyze", headers=H, files={"file": ("img", f)},
                          data={"llm_backend": "claude" if ANTHROPIC else "template"}, timeout=300)
    j = r.json()
    print(r.status_code, f"{time.time() - t:.1f}s", {k: v for k, v in j["resumen"].items() if k != "report_md"})
    from IPython.display import Markdown, display, Image
    display(Markdown(j["resumen"]["report_md"]))
    display(Image(base64.b64decode(j["imagenes_jpg_b64"]["gradcam"]), width=300))
else:
    print("(No encontré el acceso directo a la carpeta DICOM para la prueba; la API ya está publicada.)")
""")
md("## 4 · Datos para Lovable")
code("""
print("Copia estos dos valores en Lovable cuando te pida los secrets de la Edge Function:\\n")
print("MAMOIA_API_URL =", SPACE_URL)
print("MAMOIA_API_KEY =", API_KEY)
print("\\n(La clave también está guardada en", key_file, ")")
""")

nb = nbf.v4.new_notebook()
nb.cells = cells
nb.metadata = {"colab": {"provenance": [], "name": OUT.name}, "kernelspec": {"name": "python3", "display_name": "Python 3"},
               "language_info": {"name": "python"}}
nbf.write(nb, OUT)
print("->", OUT)
