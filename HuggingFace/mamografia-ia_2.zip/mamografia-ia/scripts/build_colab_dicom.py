"""Genera notebooks/MamoIA_Colab_DICOM.ipynb (pipeline completo con los DICOM de Drive y los reportes
en Excel). Ejecutar: python scripts/build_colab_dicom.py"""
from pathlib import Path

import nbformat as nbf

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "notebooks" / "MamoIA_Colab_DICOM.ipynb"


def _package_b64() -> str:
    """Empaqueta src/, configs/ y pyproject.toml en un zip base64 que viaja dentro del notebook."""
    import base64
    import io
    import textwrap
    import zipfile
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(list((ROOT / "src").rglob("*.py")) + list((ROOT / "configs").glob("*.yaml"))
                        + [ROOT / "pyproject.toml"]):
            if "__pycache__" not in p.parts:
                z.write(p, p.relative_to(ROOT))
    return "\n".join(textwrap.wrap(base64.b64encode(buf.getvalue()).decode(), 100))


PKG_CELL = ('''#@title 📦 Instalar paquete `mamoia` (embebido en el notebook; ejecútala, no hace falta abrirla)
import base64, io, os, sys, zipfile, shutil
PKG_B64 = """
''' + _package_b64() + '''
"""
if os.path.isdir(PKG_DIR):
    shutil.rmtree(PKG_DIR)
zipfile.ZipFile(io.BytesIO(base64.b64decode(PKG_B64))).extractall(PKG_DIR)
sys.path.insert(0, f"{PKG_DIR}/src")                                   # este kernel
os.environ["PYTHONPATH"] = f"{PKG_DIR}/src:" + os.environ.get("PYTHONPATH", "")   # subprocesos
for m in [m for m in sys.modules if m == "mamoia" or m.startswith("mamoia.")]:
    del sys.modules[m]                                                   # recarga si se re-ejecuta
os.chdir(PKG_DIR)
import mamoia
print("Paquete mamoia", mamoia.__version__, "listo en", PKG_DIR)
''')
cells = []


def md(s):
    cells.append(nbf.v4.new_markdown_cell(s.strip()))


def code(s, colab=False):
    c = nbf.v4.new_code_cell(s.strip())
    if colab:
        c.metadata["tags"] = ["colab"]
    cells.append(c)


md("""
# MamoIA · pipeline completo con DICOM + reportes de radiología (Colab)

**Datos:** estudios DICOM por paciente (`Paciente_001 … Paciente_119`, carpeta compartida de Drive) e
interpretaciones en Excel (`PX_1-15`, `PX_16-53`, `PX_54-119`: BI-RADS 3, 4 y 5 con reporte libre).

**Qué hace este notebook**

| Paso | Resultado |
|---|---|
| 1-2 | Descarga los DICOM desde Drive y los convierte a PNG anonimizados (VOI LUT, MONOCHROME1, vista por etiquetas DICOM) |
| 3 | **Extrae etiquetas de los reportes** (BI-RADS, 4a/4b/4c, densidad, lateralidad, tipo de lesión, cuadrante, biopsia) con reglas y, opcionalmente, con un LLM |
| 4 | Construye etiquetas por **mama** y por **imagen** (ground truth débil derivado del reporte) |
| 5 | Entrena la CNN con **validación cruzada por paciente** y la evalúa por imagen, mama y paciente (AUC con IC 95 %) |
| 6 | Grad-CAM y CADe clásico de la tesis sobre casos fuera de muestra |
| 7 | Entrena el captioner **CNN-LSTM** (textos objetivo derivados de los reportes reales) |
| 8 | Genera el **reporte bilateral** con el LLM y lo compara con la categoría del radiólogo |
| 9 | Exporta los modelos para la API / app web (Lovable + Supabase) |

> ⚠️ **Uso docente y de investigación.** No es un dispositivo médico. Las imágenes y reportes son datos
> de pacientes: trabajen sólo en su Drive institucional, no suban nada a repositorios públicos y no
> envíen imágenes a servicios externos (el LLM sólo recibe texto anonimizado / JSON).

**Antes de empezar:** Entorno de ejecución → Cambiar tipo → **GPU (T4)**.
""")

md("## 0 · Parámetros")
code("""
# ======================= PARÁMETROS (editar) =======================
# Carpeta compartida con los DICOM: basta con pegar el enlace, el ID se extrae solo
DICOM_URL = "https://drive.google.com/drive/folders/1V7nw-jPS-Exgji956VLryd_3kqeKzMk_?usp=drive_link"
WORK = "/content/drive/MyDrive/MamoIA"                    # resultados persistentes (checkpoints, CSV)
XLSX_DIR = f"{WORK}/reportes"                             # aquí los 3 Excel PX_*.xlsx (o se piden al ejecutar)
LOCAL = "/content/data"                                   # disco local de Colab (rápido)
PKG_DIR = "/content/mamoia_pkg"                           # el paquete viene EMBEBIDO en este notebook

TARGET   = "b5_vs_resto"     # b5_vs_resto | b45_vs_resto | hallazgo_vs_contralateral (ver paso 4)
N_FOLDS  = 5                 # validación cruzada por paciente
EPOCHS   = 20
IMG_SIZE = [1024, 512]       # alto, ancho. Para pruebas rápidas: [512, 256]
BACKBONE = "efficientnet_b0" # timm: efficientnet_b0 | convnext_tiny | resnet50 ...
BATCH    = 8
CBIS_PRETRAIN = False        # True: preentrena con CBIS-DDSM (≈6 GB, +1 h) antes de la VC
LLM_BACKEND = "template"     # template | claude | ollama
USE_LLM_FOR_LABELS = False   # True: el LLM también extrae campos y resume reportes (cuesta API)
# ===================================================================
import re
DRIVE_FOLDER_ID = re.search(r"folders/([A-Za-z0-9_-]+)", DICOM_URL).group(1) if "folders/" in DICOM_URL else DICOM_URL
print("Carpeta DICOM:", DRIVE_FOLDER_ID)
""")

md("""## 1 · Entorno
La primera celda instala el paquete `mamoia` **desde el propio notebook** (no hay que subir ningún zip);
la segunda monta Drive e instala las dependencias.""")
code(PKG_CELL)
cells[-1].metadata["cellView"] = "form"
code("""
import os, sys, subprocess, glob, json, shutil
from google.colab import drive
drive.mount("/content/drive")
os.makedirs(WORK, exist_ok=True); os.makedirs(LOCAL, exist_ok=True)
subprocess.run([sys.executable, "-m", "pip", "install", "-q", "timm", "pydicom>=2.4", "pylibjpeg",
                "pylibjpeg-libjpeg", "pylibjpeg-openjpeg", "python-gdcm", "anthropic", "openpyxl"], check=True)
# Clave de Claude (opcional): Colab → 🔑 Secretos → ANTHROPIC_API_KEY
try:
    from google.colab import userdata
    os.environ["ANTHROPIC_API_KEY"] = userdata.get("ANTHROPIC_API_KEY") or ""
except Exception:
    pass
import torch; print("GPU:", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "NO (Entorno de ejecución → GPU)")
""", colab=True)
code("""
import os, sys, subprocess, glob, json, shutil
import numpy as np, pandas as pd, cv2, matplotlib.pyplot as plt
from IPython.display import display, Markdown
pd.set_option("display.max_colwidth", 120); pd.set_option("display.width", 200)

def sh(cmd):
    \"\"\"Ejecuta un comando mostrando la salida en vivo (entrenamientos largos).\"\"\"
    print("$", cmd)
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, cwd=PKG_DIR)
    for line in p.stdout:
        if "Warning" not in line:
            print(line, end="")
    if p.wait() != 0:
        raise RuntimeError(f"falló: {cmd}")

CKPT = f"{WORK}/checkpoints"; LAB = f"{WORK}/labels"; OUTD = f"{WORK}/outputs"
for d in (CKPT, f"{CKPT}/cv", LAB, OUTD):
    os.makedirs(d, exist_ok=True)
import mamoia; print("mamoia", mamoia.__version__, "OK")
""")

md("""## 2 · DICOM → PNG anonimizados
La carpeta se toma **automáticamente** del enlace `DICOM_URL`:
1. Si la carpeta compartida ya está visible en tu Drive montado (acceso directo en Mi unidad), se lee de ahí.
2. Si no, se descarga con **tu** sesión de Google (aparece una ventana para autorizar una sola vez).
   Es reanudable: si se corta, vuelve a ejecutar la celda.""")
code("""
DICOM_DIR = f"{LOCAL}/dicom"
def _shared_on_drive(fid):
    # Colab expone las carpetas compartidas con acceso directo en .shortcut-targets-by-id/<ID>/<nombre>
    base = f"/content/drive/.shortcut-targets-by-id/{fid}"
    if os.path.isdir(base):
        subs = [os.path.join(base, d) for d in os.listdir(base)]
        return subs[0] if len(subs) == 1 and os.path.isdir(subs[0]) else base
    return None

src = _shared_on_drive(DRIVE_FOLDER_ID)
if src and glob.glob(f"{src}/Paciente_*"):
    print("Leyendo desde el acceso directo de Drive:", src)
    if not os.path.isdir(DICOM_DIR):
        shutil.copytree(src, DICOM_DIR)          # copia local: el entrenamiento lee mucho más rápido
else:
    from mamoia.data.gdrive import colab_auth, download_folder
    colab_auth()
    download_folder(DRIVE_FOLDER_ID, DICOM_DIR)
pacientes = sorted(glob.glob(f"{DICOM_DIR}/Paciente_*"))
print(f"{len(pacientes)} carpetas de paciente en {DICOM_DIR}")
assert pacientes, "No se encontraron carpetas Paciente_*: revisa que tu cuenta tenga acceso a DICOM_URL"
""", colab=True)
code("""
from mamoia.config import load_config
from mamoia.data.dicom_io import ingest_dicom_tree, fill_missing_views
cfg = load_config()
cfg["preprocess"]["out_height"], cfg["preprocess"]["out_width"] = IMG_SIZE
PROC = f"{LOCAL}/dicom_proc"
inv = fill_missing_views(ingest_dicom_tree(DICOM_DIR, PROC, cfg["preprocess"]))
inv.to_csv(f"{LAB}/inventory_dicom.csv", index=False)
print(f"{len(inv)} imágenes · {inv.patient_id.nunique()} pacientes")
display(pd.crosstab(inv.laterality, inv.projection, margins=True))
display(inv.groupby(["lat_source", "proj_source"]).size().rename("n").to_frame())
print("Fabricantes:", inv.Manufacturer.value_counts().to_dict())
print("Vistas no estándar (se excluyen del entrenamiento):", int((~inv.is_standard_view).sum()))
""")
md("""### 2.1 · Control de calidad de las vistas
Las imágenes sin etiqueta DICOM de vista se infieren (heurística ≈ 91 % de exactitud o por eliminación).
**Revísalas**: el CSV `vistas_revision.csv` en tu Drive se puede corregir a mano (columnas `laterality`,
`projection`) y se vuelve a aplicar automáticamente.""")
code("""
rev_path = f"{LAB}/vistas_revision.csv"
dudosas = inv[(inv.lat_source != "tag") | (~inv.proj_source.isin(["tag", "texto"]))]
if os.path.exists(rev_path):                       # aplica correcciones manuales previas
    rev = pd.read_csv(rev_path)
    inv = inv.drop(columns=["laterality", "projection"]).merge(
        rev[["image_id", "laterality", "projection"]], on="image_id", how="left").fillna({"laterality": "U", "projection": "U"})
    print("Correcciones manuales aplicadas:", len(rev))
elif len(dudosas):
    dudosas[["image_id", "patient_id", "dicom_file", "laterality", "lat_source", "projection", "proj_source"]].to_csv(rev_path, index=False)
    print(f"{len(dudosas)} imágenes con vista inferida -> revisar {rev_path}")

def show_patient(pid, n=4):
    g = inv[inv.patient_id == pid].sort_values(["laterality", "projection"]).head(n)
    fig, ax = plt.subplots(1, len(g), figsize=(3 * len(g), 5))
    for a, r in zip(np.atleast_1d(ax), g.itertuples()):
        a.imshow(cv2.imread(r.img_path, 0), cmap="gray"); a.set_title(f"{r.laterality}{r.projection}\\n{r.proj_source}", fontsize=8); a.axis("off")
    plt.suptitle(pid); plt.show()
for pid in inv.patient_id.drop_duplicates().head(3):
    show_patient(pid)
""")

md("""## 3 · Etiquetas a partir de los reportes del radiólogo
El extractor por reglas (`mamoia/text/report_parser.py`) anonimiza el texto (quita nombres de médicos y
fechas) y extrae: BI-RADS y subcategoría, densidad ACR, **lateralidad del hallazgo**, tipo de lesión (con
manejo de negaciones: *"sin nódulos"*), cuadrante, tamaño, márgenes y **resultado de biopsia** cuando el
addendum lo reporta.""")
code("""
xlsx = sorted(glob.glob(f"{XLSX_DIR}/*.xlsx"))
if not xlsx:
    from google.colab import files
    os.makedirs(XLSX_DIR, exist_ok=True)
    print("Sube los 3 Excel PX_*.xlsx")
    for name, data in files.upload().items():
        open(f"{XLSX_DIR}/{name}", "wb").write(data)
    xlsx = sorted(glob.glob(f"{XLSX_DIR}/*.xlsx"))
print(xlsx)
""", colab=True)
code("""
from mamoia.text.report_parser import parse_all, expand_to_breasts, breast_targets
rep = parse_all(xlsx)
rep.to_csv(f"{LAB}/reportes_extraidos.csv", index=False, encoding="utf-8-sig")
print(len(rep), "reportes")
for c in ["birads", "birads_sub", "density", "lesion_laterality", "lesion_type", "lesion_quadrant", "biopsy_result"]:
    print(f"{c:18s}", rep[c].value_counts(dropna=False).to_dict())
display(rep[["patient_id", "birads", "birads_sub", "density", "lesion_laterality", "lesion_type",
             "lesion_quadrant", "lesion_size_mm", "biopsy_result", "impresion"]].head(12))
""")
md("""**Ejercicio:** elijan 20 reportes al azar, lean el texto (`rep.report_anon`) y verifiquen a mano la
lateralidad y el tipo de lesión. ¿Qué exactitud tiene el extractor? ¿Qué patrones fallan?""")
code("""
# (opcional) extracción con LLM y concordancia con las reglas
if USE_LLM_FOR_LABELS and LLM_BACKEND in ("claude", "ollama"):
    from mamoia.llm.extract import extract_fields, compare, cache_json
    llm_rows = []
    for r in rep.itertuples():
        d = cache_json(f"{LAB}/llm_cache/extract_{r.patient_id}.json", extract_fields, r.report_anon, LLM_BACKEND)
        llm_rows.append({"patient_id": r.patient_id, **d})
    llm = pd.DataFrame(llm_rows)
    llm.to_csv(f"{LAB}/reportes_extraidos_llm.csv", index=False)
    display(pd.DataFrame(compare(rep, llm)).T)
    dis = rep.merge(llm, on="patient_id", suffixes=("_reglas", "_llm"))
    display(dis[dis.lesion_laterality_reglas != dis.lesion_laterality_llm][["patient_id", "lesion_laterality_reglas", "lesion_laterality_llm", "impresion"]])
else:
    print("Extracción con LLM desactivada (USE_LLM_FOR_LABELS=False)")
""")

md("""## 4 · Ground truth débil por mama y por imagen
Todos los estudios son BI-RADS 3-5 (no hay controles normales). Estrategia:

* **Mama con el hallazgo** → recibe la categoría del reporte. **Mama contralateral** (si el hallazgo es
  claramente unilateral y no hay mastectomía) → *sin hallazgo sospechoso* (negativo).
* Si la biopsia está reportada, **manda la biopsia** (maligno = 1, benigno = 0).
* `TARGET`:
  * `b5_vs_resto`: 1 = BI-RADS 5 / biopsia maligna; 0 = BI-RADS 3-4, contralateral, biopsia benigna.
  * `b45_vs_resto`: 1 = BI-RADS 4-5; 0 = BI-RADS 3 y contralaterales.
  * `hallazgo_vs_contralateral`: detección (¿esta mama tiene el hallazgo reportado?).

> Es una etiqueta **derivada del radiólogo**, no histopatológica: el modelo aprende a reproducir la
> lectura del radiólogo. Discútanlo en el informe.""")
code("""
from mamoia.data.labels import build_image_labels
breasts = breast_targets(expand_to_breasts(rep), TARGET)
breasts.to_csv(f"{LAB}/reportes_por_mama.csv", index=False)
img_lab = build_image_labels(inv, breasts)
img_lab["preprocessed"] = True
labels_csv = f"{LAB}/labels_dicom_{TARGET}.csv"
img_lab.to_csv(labels_csv, index=False)

sin_reporte = sorted(set(inv.patient_id) - set(rep.patient_id))
sin_imagen = sorted(set(rep.patient_id) - set(inv.patient_id))
print("Pacientes con imágenes y sin reporte:", sin_reporte[:10], "…" if len(sin_reporte) > 10 else "")
print("Pacientes con reporte y sin imágenes:", sin_imagen[:10], "…" if len(sin_imagen) > 10 else "")
print("\\nImágenes por etiqueta:", img_lab.y_malig.value_counts().to_dict())
display(pd.crosstab(img_lab.label_source.fillna("sin etiqueta"), img_lab.y_malig, margins=True))
""")

md("## 5 · Clasificador CNN con validación cruzada por paciente")
code("""
OV = (f'--set classifier.backbone={BACKBONE} --set "classifier.img_size={IMG_SIZE}" '
      f'--set train.epochs={EPOCHS} --set train.batch_size={BATCH} --set train.num_workers=2')
INIT = ""
if CBIS_PRETRAIN:
    sh("pip -q install kagglehub")
    import kagglehub
    root = kagglehub.dataset_download("awsaf49/cbis-ddsm-breast-cancer-image-dataset")
    os.makedirs("data/public", exist_ok=True)
    if not os.path.exists("data/public/cbis-ddsm"):
        os.symlink(root, "data/public/cbis-ddsm")
    if not os.path.exists(f"{CKPT}/cls_cbis.pt"):
        sh(f"python -m mamoia.train.train_classifier --source public --out {CKPT}/cls_cbis.pt {OV} --set train.epochs=10")
    INIT = f"--init {CKPT}/cls_cbis.pt"

for k in range(N_FOLDS):
    out = f"{CKPT}/cv/fold{k}.pt"
    if os.path.exists(out.replace(".pt", ".oof.csv")):
        print(f"fold {k} ya entrenado"); continue
    sh(f"python -m mamoia.train.train_classifier --source csv --labels-csv {labels_csv} "
       f"--n-folds {N_FOLDS} --fold {k} --out {out} {INIT} {OV}")
""")
code("""
from mamoia.train.evaluate_cv import evaluate_oof
oof = pd.concat([pd.read_csv(f) for f in sorted(glob.glob(f"{CKPT}/cv/fold*.oof.csv"))], ignore_index=True)
res = evaluate_oof(oof, f"{OUTD}/cv")
tabla = pd.DataFrame({lvl: {k: m.get(k) for k in ("n", "auc", "auc_ic95", "sensibilidad", "especificidad",
                                                  "vpp", "vpn", "sens_a_esp_0.80")} for lvl, m in res.items()}).T
display(tabla)
from IPython.display import Image
display(Image(f"{OUTD}/cv/roc_cv.png"))
""")
md("""**Cómo leerlo:** *imagen* = cada vista por separado; *mama* = promedio de CC y MLO; *paciente* =
la mama más sospechosa. El IC 95 % viene de remuestrear pacientes (bootstrap). Con ~119 pacientes los
intervalos son amplios: repórtenlos siempre.""")

md("## 6 · Explicabilidad sobre casos fuera de muestra (Grad-CAM vs. CADe de la tesis)")
code("""
import torch
from mamoia.models.classifier import load_classifier
from mamoia.explain.gradcam import gradcam, overlay
from mamoia.classic.cade import detect_rois, draw_rois
from mamoia.data.dataset import to_tensor
dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
o = oof.merge(img_lab[["image_id", "img_path"]], on="image_id")
casos = pd.concat([o[o.y_malig == 1].nlargest(3, "p_malig").assign(tipo="VP"),
                   o[o.y_malig == 0].nlargest(2, "p_malig").assign(tipo="FP"),
                   o[o.y_malig == 1].nsmallest(2, "p_malig").assign(tipo="FN")])
for r in casos.itertuples():
    model, ck = load_classifier(f"{CKPT}/cv/fold{int(r.fold)}.pt", dev); model.to(dev)
    img = cv2.imread(r.img_path, 0); img = cv2.resize(img, (ck["img_size"][1], ck["img_size"][0]))
    mask = img > 0
    heat = gradcam(model, to_tensor(img).unsqueeze(0).to(dev))
    cade = detect_rois(img, mask)
    fig, ax = plt.subplots(1, 3, figsize=(10, 6))
    ax[0].imshow(img, cmap="gray"); ax[1].imshow(overlay(img, heat)[..., ::-1]); ax[2].imshow(draw_rois(img, cade["rois"])[..., ::-1])
    for a, t in zip(ax, ["imagen", "Grad-CAM (CNN)", "CADe tesis 2015"]): a.set_title(t); a.axis("off")
    plt.suptitle(f"{r.tipo} · {r.image_id} · P={r.p_malig:.2f} · y={r.y_malig}"); plt.show()
""")

md("""## 7 · Modelo final y captioner CNN-LSTM
El modelo final se entrena con todos los pacientes (dejando un 10 % para test rápido); el desempeño a
reportar es el de la validación cruzada. Los textos objetivo del LSTM se construyen por mama a partir de
los campos extraídos del reporte (o con resúmenes del LLM si `USE_LLM_FOR_LABELS=True`).""")
code("""
FINAL = f"{CKPT}/classifier.pt"
if not os.path.exists(FINAL):
    sh(f"python -m mamoia.train.train_classifier --source csv --labels-csv {labels_csv} --out {FINAL} "
       f"{INIT} {OV} --set train.test_frac=0.1")
print(json.load(open(FINAL.replace(".pt", ".test.json")))["malignidad"])
""")
code("""
cap_csv = labels_csv.replace(".csv", "_caption.csv")
cap = img_lab.copy()
if USE_LLM_FOR_LABELS and LLM_BACKEND in ("claude", "ollama"):
    from mamoia.llm.extract import summarize_breast, cache_json
    txt = {}
    for r in rep.itertuples():
        for side in ("L", "R"):
            txt[(r.patient_id, side)] = cache_json(f"{LAB}/llm_cache/sum_{r.patient_id}_{side}.json",
                                                   summarize_breast, r.report_anon, side, LLM_BACKEND)
    cap["report_text"] = [txt.get((p, l), "") for p, l in zip(cap.patient_id, cap.laterality)]
cap.to_csv(cap_csv, index=False)
from mamoia.text.report_templates import describe
for r in cap.sample(3, random_state=1).to_dict("records"):
    print("·", describe(r))
if not os.path.exists(f"{CKPT}/captioner.pt"):
    sh(f"python -m mamoia.train.train_captioner --classifier {FINAL} --source csv --labels-csv {cap_csv} "
       f"--out {CKPT}/captioner.pt --set captioner.epochs=30 --set train.num_workers=2")
""")

md("## 8 · Reporte bilateral con LLM y comparación con el radiólogo")
code("""
from mamoia.pipeline import MamoPipeline
pipe = MamoPipeline.load(FINAL, f"{CKPT}/captioner.pt", cfg=cfg)
from mamoia.train.common import build_dataframe
# mismos pacientes de test (10 %) que usó el modelo final
dfF = build_dataframe(load_config(overrides=["train.test_frac=0.1"]), "csv", labels_csv=labels_csv)
pats = dfF[dfF.split == "test"].patient_id.unique()[:6]
filas = []
for pid in pats:
    g = img_lab[(img_lab.patient_id == pid) & img_lab.laterality.isin(["L", "R"])]
    study = [(f"{DICOM_DIR}/{r.dicom_file}", r.laterality, r.projection) for r in g.itertuples()]
    out = pipe.analyze_study(study, llm=LLM_BACKEND)
    rr = rep.set_index("patient_id").loc[pid]
    filas.append({"paciente": pid, "BI-RADS radiólogo": rr.birads, "lado radiólogo": rr.lesion_laterality,
                  "BI-RADS IA": out["reporte"]["report"]["birads_sugerido"],
                  "lado IA": {"izquierda": "L", "derecha": "R"}.get(out["reporte"]["findings"]["mama_de_mayor_sospecha"]),
                  "P(mal) L": out["por_mama"].get("L", {}).get("clasificador", {}).get("prob_malignidad"),
                  "P(mal) R": out["por_mama"].get("R", {}).get("clasificador", {}).get("prob_malignidad")})
    display(Markdown(f"---\\n## {pid} · radiólogo: BI-RADS {rr.birads} ({rr.lesion_laterality})\\n" + out["reporte"]["markdown"]))
comp = pd.DataFrame(filas); display(comp)
""")
md("""**Ejercicio:** extiendan la tabla a los pacientes fuera de muestra de *todos* los folds (usando el
modelo de cada fold) y calculen: concordancia de la mama más sospechosa con la lateralidad del reporte y
matriz de confusión BI-RADS IA vs. radiólogo. Pidan al radiólogo calificar 10 reportes a ciegas.""")

md("## 9 · Exportar para la API y la app web")
code("""
dst = f"{WORK}/export_api"
os.makedirs(dst, exist_ok=True)
for f in ("classifier.pt", "captioner.pt"):
    shutil.copy(f"{CKPT}/{f}", f"{dst}/{f}")
json.dump({"target": TARGET, "n_folds": N_FOLDS, "backbone": BACKBONE, "img_size": IMG_SIZE,
           "cv": {k: {kk: v.get(kk) for kk in ("auc", "auc_ic95")} for k, v in res.items()}},
          open(f"{dst}/model_card.json", "w"), indent=2, default=str)
print("Listo:", os.listdir(dst))
print("Copien estos archivos a checkpoints/ de la API (api/Dockerfile) y sigan docs/LOVABLE_PROMPT.md")
""")

nb = nbf.v4.new_notebook()
nb.cells = cells
nb.metadata = {"accelerator": "GPU", "colab": {"provenance": [], "gpuType": "T4", "name": OUT.name},
               "kernelspec": {"name": "python3", "display_name": "Python 3"}, "language_info": {"name": "python"}}
nbf.write(nb, OUT)
print("->", OUT)
