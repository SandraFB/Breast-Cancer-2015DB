"""Genera los notebooks de Colab (notebooks/0X_*.ipynb). Ejecutar: python scripts/build_notebooks.py"""
from pathlib import Path

import nbformat as nbf

OUT = Path(__file__).resolve().parents[1] / "notebooks"

SETUP = """# === Configuración del entorno (Colab) ===
# Opción A: el repositorio está en GitHub
REPO = "https://github.com/TU_USUARIO/mamografia-ia.git"   # <-- cambiar
# Opción B: subieron mamografia-ia.zip a Google Drive (MyDrive/mamografia-ia.zip)
import os, sys, subprocess
IN_COLAB = "google.colab" in sys.modules
if IN_COLAB:
    from google.colab import drive
    drive.mount("/content/drive")
    if not os.path.exists("/content/mamografia-ia"):
        if os.path.exists("/content/drive/MyDrive/mamografia-ia.zip"):
            subprocess.run(["unzip", "-q", "/content/drive/MyDrive/mamografia-ia.zip", "-d", "/content"])
        else:
            subprocess.run(["git", "clone", REPO, "/content/mamografia-ia"])
    os.chdir("/content/mamografia-ia")
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "-e", ".[llm]"])
    # Datos: copien DB-2015-IMG.zip y DB-segmentation-2015.zip a MyDrive/mamoia_datos/
    DATA = "/content/drive/MyDrive/mamoia_datos"
    os.makedirs("data/raw", exist_ok=True)
    if not os.path.exists("data/raw/prueba"):
        subprocess.run(["unzip", "-q", f"{DATA}/DB-2015-IMG.zip", "-d", "data/raw"])
        subprocess.run(["unzip", "-q", f"{DATA}/DB-segmentation-2015.zip", "-d", "data/raw"])
    # Persistir resultados en Drive entre sesiones
    for d in ("checkpoints", "data/processed", "data/labels"):
        os.makedirs(f"{DATA}/{d}", exist_ok=True)
        if not os.path.islink(d):
            subprocess.run(["rm", "-rf", d]); os.symlink(f"{DATA}/{d}", d)
import torch; print("GPU:", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "no (usar Entorno > GPU)")"""


def md(s):
    return nbf.v4.new_markdown_cell(s.strip())


def code(s):
    return nbf.v4.new_code_cell(s.strip())


NB = {
"01_datos_y_preprocesamiento": [
md("""# 01 · Datos, anonimización y CADe clásico (tesis 2015)
**Objetivos:** entender la base de datos, detectar duplicados, preprocesar (negativo → positivo, recorte
de la mama, CLAHE) y reproducir en Python el CADe por zonas de profundidad de la tesis.

> Las placas originales pueden traer el **nombre de la paciente impreso**. Trabajen sólo con las
> imágenes preprocesadas (recortadas) y nunca las suban a sitios públicos."""),
code(SETUP),
md("## 1. Inventario y plantilla de etiquetas"),
code("""!python -m mamoia.data.inventory --images data/raw/prueba --out data/labels/labels_template.csv
import pandas as pd
inv = pd.read_csv("data/labels/inventory.csv", dtype=str)
display(inv.head())
print(inv.name_pattern.value_counts())
print("Duplicados:"); display(inv[inv.is_duplicate == "True"][["image_id", "dup_of", "group_id"]])"""),
md("""**Pregunta:** ¿por qué es grave que `131e11` (duplicado de `127e11`) quede en *test* si `127e11` está
en *train*? ¿Qué hace `group_id`?"""),
md("## 2. Preprocesamiento"),
code("""!python -m mamoia.data.preprocess --images data/raw/prueba --out data/processed
import cv2, matplotlib.pyplot as plt
from mamoia.data.preprocess import read_gray
ids = ["0011", "0253", "208e54", "2022"]
fig, ax = plt.subplots(2, 4, figsize=(14, 8))
for i, n in enumerate(ids):
    raw = [f for f in os.listdir("data/raw/prueba") if f.split(".")[0] == n][0]
    ax[0, i].imshow(read_gray(f"data/raw/prueba/{raw}"), cmap="gray"); ax[0, i].set_title(f"original {n}")
    ax[1, i].imshow(cv2.imread(f"data/processed/img/{n}.png", 0), cmap="gray"); ax[1, i].set_title("preprocesada")
[a.axis("off") for a in ax.ravel()]; plt.show()"""),
md("## 3. CADe clásico: Top-Hat por zonas → CLAHE → difusión anisotrópica → umbral de Tsallis"),
code("""from mamoia.classic.cade import detect_rois, draw_rois, summarize_rois
from mamoia.config import load_config
cfg = load_config(); C = cfg["classic"]
img = cv2.imread("data/processed/img/0253.png", 0); mask = cv2.imread("data/processed/mask/0253.png", 0) > 0
r = detect_rois(img, mask, n_zones=C["depth_zones"], radius_frac=C["tophat_radius_frac"],
                diffusion_iters=C["diffusion_iters"], tsallis_q=C["tsallis_q"])
fig, ax = plt.subplots(1, 4, figsize=(16, 7))
ax[0].imshow(r["zones"], cmap="viridis"); ax[0].set_title("zonas de profundidad")
ax[1].imshow(r["enhanced"], cmap="gray"); ax[1].set_title("realce")
ax[2].imshow(r["binary"], cmap="gray"); ax[2].set_title(f"Tsallis t={r['threshold']}")
ax[3].imshow(draw_rois(img, r["rois"])[..., ::-1]); ax[3].set_title("ROIs (rojo = top 3)")
[a.axis("off") for a in ax]; plt.show()
summarize_rois(r["rois"])"""),
md("## 4. Resultados originales de la tesis (contornos verdes → máscaras)"),
code("""!python -m mamoia.classic.thesis_segmentations --seg data/raw/segmentation --out data/thesis_masks
s = "Paciente_03015"
fig, ax = plt.subplots(1, 2, figsize=(10, 7))
ax[0].imshow(cv2.imread(f"data/raw/segmentation/{s}.jpeg")[..., ::-1]); ax[0].set_title("tesis 2015")
ax[1].imshow(cv2.imread(f"data/thesis_masks/mask/{s}.png", 0), cmap="gray"); ax[1].set_title("máscara")
plt.show()"""),
md("""**Ejercicio:** apliquen `detect_rois` sobre `data/thesis_masks/clean/<imagen>.png` (la misma placa sin
contornos) y calculen el Dice contra la máscara 2015 con `mamoia.classic.thesis_segmentations.dice`.
Varíen `tophat_radius_frac` (casos 1-4 de la Tabla 3 de la tesis) y reporten el mejor."""),
md("""## 5. Etiquetado
Copien `data/labels/labels_template.csv` → `data/labels/labels.csv` y llénenlo con el radiólogo
(ver `docs/DATASET.md`). Mientras tanto pueden avanzar con el dataset público en el notebook 02."""),
],

"02_clasificador_benigno_maligno": [
md("""# 02 · Clasificador CNN: benigno / maligno (+ BI-RADS y densidad)
Transfer learning en dos etapas: **CBIS-DDSM** (patología confirmada por biopsia) → **base local 2015**.
Métricas: AUC, sensibilidad, especificidad, VPP/VPN con umbral de Youden elegido en validación."""),
code(SETUP),
md("## 1. Dataset público CBIS-DDSM (≈ 6 GB)"),
code("""!pip -q install kagglehub
import kagglehub, os
root = kagglehub.dataset_download("awsaf49/cbis-ddsm-breast-cancer-image-dataset")
os.makedirs("data/public", exist_ok=True)
if not os.path.exists("data/public/cbis-ddsm"): os.symlink(root, "data/public/cbis-ddsm")
from mamoia.data.public_datasets import load_cbis_ddsm
pub = load_cbis_ddsm("data/public/cbis-ddsm")
pub[["image_id", "pathology", "birads", "density", "lesion_type", "official_split"]].head()"""),
md("## 2. Preentrenamiento"),
code("""!python -m mamoia.train.train_classifier --source public --out checkpoints/cls_cbis.pt \\
    --set train.epochs=12 --set train.batch_size=8"""),
md("## 3. Ajuste fino con la base local (requiere `data/labels/labels.csv`)"),
code("""!python -m mamoia.train.train_classifier --source local --init checkpoints/cls_cbis.pt \\
    --out checkpoints/classifier.pt --set train.lr=1e-4 --set train.epochs=15"""),
md("## 4. Evaluación y curva ROC en test"),
code("""import json, numpy as np, matplotlib.pyplot as plt, torch
from sklearn.metrics import roc_curve
from torch.utils.data import DataLoader
from mamoia.config import load_config
from mamoia.train.common import build_dataframe
from mamoia.data.dataset import MammoDataset
from mamoia.models.classifier import load_classifier
from mamoia.train.train_classifier import predict
cfg = load_config(); dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model, ck = load_classifier("checkpoints/classifier.pt", dev); model.to(dev)
df = build_dataframe(cfg, "local"); te = df[df.split == "test"]
pt = predict(model, DataLoader(MammoDataset(te, ck["img_size"]), 8), dev)
m = pt["y"] >= 0
fpr, tpr, _ = roc_curve(pt["y"][m], pt["p"][m])
plt.plot(fpr, tpr); plt.plot([0, 1], [0, 1], "--"); plt.xlabel("1 - especificidad"); plt.ylabel("sensibilidad")
plt.title("ROC test"); plt.show()
print(json.load(open("checkpoints/classifier.test.json"))["malignidad"])"""),
md("""**Ejercicio:** calculen un intervalo de confianza al 95 % del AUC con *bootstrap* por paciente
(remuestreen `group_id`, no imágenes)."""),
md("## 5. Explicabilidad: Grad-CAM"),
code("""import cv2
from mamoia.explain.gradcam import gradcam, overlay
from mamoia.data.dataset import to_tensor
for iid in te.image_id.head(4):
    img = cv2.imread(f"data/processed/img/{iid}.png", 0)
    img = cv2.resize(img, (ck["img_size"][1], ck["img_size"][0]))
    x = to_tensor(img).unsqueeze(0).to(dev)
    h = gradcam(model, x)
    p = torch.sigmoid(model(x)["malignancy"]).item()
    plt.figure(figsize=(4, 7)); plt.imshow(overlay(img, h)[..., ::-1]); plt.title(f"{iid} P(mal)={p:.2f}"); plt.axis("off")
plt.show()"""),
],

"03_descripcion_cnn_lstm": [
md("""# 03 · Descripción automática con CNN + LSTM (atención)
El encoder es el backbone del clasificador (congelado). El LSTM genera la descripción palabra por
palabra, **condicionado** por las probabilidades del clasificador, y con atención espacial (Show,
Attend and Tell). Los textos de entrenamiento vienen de `report_text` (si el radiólogo lo escribió) o
de plantillas construidas con las etiquetas estructuradas (`text/report_templates.py`)."""),
code(SETUP),
md("## 1. ¿Qué texto aprende el modelo?"),
code("""from mamoia.text.report_templates import describe
import random
row = dict(laterality="L", projection="MLO", density="C", lesion_type="masa", lesion_shape="irregular",
           lesion_margin="espiculado", lesion_quadrant="CSE", depth_zone="media", birads="5")
print(describe(row))
rng = random.Random(1)
for _ in range(3): print(" ·", describe(row, variant=True, rng=rng))"""),
md("## 2. Entrenamiento"),
code("""!python -m mamoia.train.train_captioner --classifier checkpoints/classifier.pt --source both \\
    --out checkpoints/captioner.pt --set captioner.epochs=30"""),
md("## 3. Generación y mapas de atención"),
code("""import cv2, torch, matplotlib.pyplot as plt
from mamoia.pipeline import MamoPipeline
pipe = MamoPipeline.load("checkpoints/classifier.pt", "checkpoints/captioner.pt")
r = pipe.analyze("data/raw/prueba/0253.jpg", "L", "MLO", llm="template", with_images=False)
print("LSTM:", r.get("caption_lstm"))
fig, ax = plt.subplots(1, 3, figsize=(12, 7))
for a, k in zip(ax, ["preprocesada", "gradcam", "atencion_lstm"]):
    if k in r["_images"]:
        im = r["_images"][k]; a.imshow(im if im.ndim == 2 else im[..., ::-1], cmap="gray"); a.set_title(k)
    a.axis("off")
plt.show()"""),
md("""**Ejercicio:** visualicen la atención **palabra por palabra** (`captioner.generate` devuelve `alphas`
de forma T×N). ¿Hacia dónde mira el modelo cuando escribe "masa"? ¿Y "BI-RADS"?
**Reto:** reemplacen `nn.LSTMCell` por un `nn.TransformerDecoder` y comparen BLEU-4 y coincidencia clínica."""),
],

"04_reporte_llm": [
md("""# 04 · Reporte para el radiólogo con LLM
El LLM recibe un JSON (nunca la imagen), redacta en léxico BI-RADS y su salida se **valida** contra
reglas deterministas (`llm/recommendations.py`). Comparen tres redactores: plantilla, Claude y Ollama."""),
code(SETUP),
code("""import os, json
from getpass import getpass
if not os.environ.get("ANTHROPIC_API_KEY"):
    os.environ["ANTHROPIC_API_KEY"] = getpass("ANTHROPIC_API_KEY (Enter para omitir): ")
os.environ.setdefault("CLAUDE_MODEL", "claude-sonnet-5-5")"""),
md("## 1. Hallazgos estructurados que recibe el LLM"),
code("""from mamoia.pipeline import MamoPipeline
pipe = MamoPipeline.load("checkpoints/classifier.pt", "checkpoints/captioner.pt")
r = pipe.analyze("data/raw/prueba/0253.jpg", "L", "MLO", llm="template", with_images=False)
print(json.dumps(r["reporte"]["findings"], indent=1, ensure_ascii=False))"""),
md("## 2. Prompt del sistema"),
code("""from mamoia.llm.prompts import SYSTEM_PROMPT; print(SYSTEM_PROMPT)"""),
md("## 3. Comparación de redactores"),
code("""from IPython.display import Markdown, display
from mamoia.llm.report import write_report
for backend in ["template", "claude"]:
    rep = write_report(r, pipe.cfg, backend)
    display(Markdown(f"## {rep['llm_backend']}\\n" + rep["markdown"]))
    print("validación:", rep["validation_issues"])"""),
md("""## 4. Ollama (modelo abierto, opcional)
En Colab se puede instalar Ollama y servir un modelo de 7B en la GPU T4:"""),
code("""# !curl -fsSL https://ollama.com/install.sh | sh
# import subprocess, time; subprocess.Popen(["ollama", "serve"]); time.sleep(5)
# !ollama pull qwen2.5:7b-instruct
# rep = write_report(r, pipe.cfg, "ollama"); display(Markdown(rep["markdown"]))"""),
md("""**Ejercicio (evaluación de alucinaciones):** generen reportes para 30 imágenes con cada backend y
cuenten: (a) `validation_issues`, (b) hallazgos mencionados que NO están en el JSON. Pidan al
radiólogo calificar a ciegas claridad y utilidad (1-5)."""),
],

"05_api_y_app_web": [
md("""# 05 · API de inferencia y app web (Lovable + Supabase + GitHub)
Arquitectura: Lovable (frontend) → Supabase (Auth, Postgres, Storage, Edge Function `analyze`) → API
FastAPI (este repo) → escribe resultados en Supabase → la UI se actualiza por Realtime."""),
code(SETUP),
md("## 1. Probar la API localmente en Colab"),
code("""!pip -q install -e ".[api]"
import os
os.environ["CLASSIFIER_CKPT"] = "checkpoints/classifier.pt"
os.environ["CAPTIONER_CKPT"] = "checkpoints/captioner.pt"
from fastapi.testclient import TestClient
from api.main import app
c = TestClient(app)
print(c.get("/health").json())
with open("data/raw/prueba/0253.jpg", "rb") as f:
    j = c.post("/analyze", files={"file": ("0253.jpg", f, "image/jpeg")},
               data={"laterality": "L", "projection": "MLO", "llm_backend": "template"}).json()
print(j["reporte"]["markdown"])"""),
md("""## 2. Supabase
1. Crear proyecto en supabase.com → *SQL Editor* → pegar `supabase/migrations/0001_mamoia_init.sql`.
2. Instalar la CLI y desplegar la función:
   ```bash
   supabase functions deploy analyze
   supabase secrets set MAMOIA_API_URL=https://<su-api> MAMOIA_API_KEY=<clave-larga>
   ```
3. Asignar rol de revisor: `update profiles set role='radiologo' where id='<uuid>';`

## 3. Desplegar la API
- **Hugging Face Spaces** (SDK Docker): subir el repo con `api/Dockerfile` (renombrar a `Dockerfile` en la raíz o
  configurar el Space) y los checkpoints; *Settings → Secrets*: `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`,
  `MAMOIA_API_KEY`, `ANTHROPIC_API_KEY`.
- Alternativas: Render, Railway, Fly.io o un servidor del laboratorio (necesario si usarán Ollama).

## 4. Lovable
Conectar Supabase y GitHub en el proyecto de Lovable y pegar `docs/LOVABLE_PROMPT.md`.

## 5. Cerrar el ciclo
```bash
python scripts/export_reviews_to_labels.py --out data/labels/labels_supabase.csv
```
y reentrenar con las nuevas etiquetas revisadas por el radiólogo."""),
],
}


def main():
    OUT.mkdir(exist_ok=True)
    for name, cells in NB.items():
        nb = nbf.v4.new_notebook()
        nb.cells = cells
        nb.metadata = {"accelerator": "GPU", "colab": {"provenance": [], "gpuType": "T4"},
                       "kernelspec": {"name": "python3", "display_name": "Python 3"},
                       "language_info": {"name": "python"}}
        nbf.write(nb, OUT / f"{name}.ipynb")
        print("->", OUT / f"{name}.ipynb")


if __name__ == "__main__":
    main()
