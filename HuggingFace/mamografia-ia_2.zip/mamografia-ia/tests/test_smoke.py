"""Pruebas de humo con imágenes sintéticas (no requieren la base de datos). Ejecutar: pytest -q"""
import json

import numpy as np
import pandas as pd
import pytest
import torch

from mamoia.classic.cade import detect_rois, tsallis_threshold
from mamoia.data.inventory import parse_name
from mamoia.data.labels import build_targets, split_by_group
from mamoia.data.preprocess import preprocess
from mamoia.llm.backends import ClaudeBackend, _extract_json
from mamoia.llm.report import validate, write_report
from mamoia.models.captioner import LSTMCaptioner
from mamoia.models.classifier import MammoClassifier, multitask_loss
from mamoia.text.report_templates import describe
from mamoia.text.vocab import Vocab


def fake_mammo(negative=True, h=600, w=400, seed=0):
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[:h, :w]
    breast = ((xx / (0.8 * w)) ** 2 + ((yy - h / 2) / (0.45 * h)) ** 2) < 1
    img = np.zeros((h, w), np.uint8)
    img[breast] = 90 + rng.integers(0, 40, breast.sum())
    img[((xx - 150) ** 2 + (yy - 300) ** 2) < 25 ** 2] = 220          # "masa"
    img[20:60, w - 120:w - 20] = 255                                   # rótulo impreso
    return 255 - img if negative else img


def test_parse_names():
    vm = {"1": {"laterality": "L", "projection": "CC"}, "4": {"laterality": "R", "projection": "MLO"}}
    assert parse_name("0011", vm)["laterality"] == "L"
    p = parse_name("208e54", vm)
    assert (p["patient_id"], p["study_n"], p["projection"]) == ("208", 5, "MLO")
    assert parse_name("02b3lcc6")["birads_from_name"] == 3


def test_preprocess_inverts_crops_and_anonymizes():
    img, mask, meta = preprocess(fake_mammo(), out_hw=(256, 128))
    assert meta.inverted and img.shape == (256, 128) and mask.any()
    assert img[~mask].max() == 0           # el rótulo fuera de la mama desaparece


def test_cade_finds_mass():
    img, mask, _ = preprocess(fake_mammo(negative=False), out_hw=(512, 256))
    r = detect_rois(img, mask, min_roi_area_px=20)
    assert 0 < r["threshold"] < 255 and len(r["rois"]) >= 1
    assert 0 <= tsallis_threshold(img, mask) < 255


def test_targets_and_group_split():
    df = pd.DataFrame({"image_id": [f"i{i}" for i in range(40)], "group_id": [f"p{i // 4}" for i in range(40)],
                       "birads": ["5", "2", "4", "1"] * 10, "pathology": [""] * 40, "density": ["c"] * 40})
    df = build_targets(df)
    assert set(df.y_malig) == {0, 1} and (df.y_density == 2).all()
    s = split_by_group(df, 0.2, 0.2, seed=1)
    for g, sub in s.groupby("group_id"):
        assert sub.split.nunique() == 1    # sin fuga de paciente


def test_models_forward_backward():
    m = MammoClassifier("efficientnet_b0", pretrained=False)
    x = torch.randn(2, 1, 128, 64)
    o = m(x, return_features=True)
    batch = {"y_malig": torch.tensor([1.0, -1.0]), "y_birads": torch.tensor([5, -1]), "y_density": torch.tensor([-1, 2])}
    loss, parts = multitask_loss(o, batch, {"malignancy": 1, "birads": .5, "density": .25})
    loss.backward()
    assert set(parts) == {"malignancy", "birads", "density"}
    texts = [describe({"laterality": "L", "projection": "CC", "birads": "4", "lesion_type": "masa"})]
    v = Vocab.build(texts)
    cap = LSTMCaptioner(m, m.n_features, len(v), cond_dim=12, hidden_dim=64, embed_dim=32, attn_dim=32)
    tok = torch.tensor([v.encode(texts[0], 20)] * 2)
    lg, al = cap(x, tok)
    LSTMCaptioner.loss(lg, tok, al, v.pad).backward()
    seqs, _, _, _ = cap.generate(x[:1], v.bos, v.eos, 10, beam_size=2)
    assert isinstance(v.decode(seqs[0]), str)


def test_llm_validation_and_fallback():
    cfg = {"thresholds": {"malignancy_high": 0.5, "malignancy_low": 0.15},
           "llm": {"backend": "ollama", "ollama_host": "http://127.0.0.1:9"}}
    analysis = {"laterality": "L", "projection": "CC",
                "clasificador": {"prob_malignidad": 0.91, "prob_birads": [0, .05, .05, .1, .3, .5, 0],
                                 "prob_densidad": [.1, .2, .6, .1]}}
    out = write_report(analysis, cfg)
    assert out["llm_backend"].startswith("template (fallback")
    assert out["report"]["birads_sugerido"] == 5
    rep, issues = validate({"birads_sugerido": 2, "recomendaciones": []}, out["findings"])
    assert rep["birads_sugerido"] == 5 and any("cambio_birads" in i for i in issues)
    assert _extract_json('texto {"a": 1} fin') == {"a": 1}


def test_claude_backend_parses_json(monkeypatch):
    class Block:
        type, text = "text", json.dumps({"hallazgos": "x", "impresion": "y", "birads_sugerido": 4,
                                         "recomendaciones": ["biopsia"], "nivel_confianza": "moderado",
                                         "limitaciones": "z"})

    class FakeMessages:
        def create(self, **kw):
            assert "temperature" not in kw and kw["system"]
            return type("M", (), {"content": [Block()]})()

    pytest.importorskip("anthropic")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test")
    b = ClaudeBackend("claude-sonnet-5-5")
    b.client = type("C", (), {"messages": FakeMessages()})()
    assert b.generate({"birads_sugerido": 4})["birads_sugerido"] == 4


def test_report_parser_extracts_and_anonymizes():
    from mamoia.text.report_parser import breast_targets, expand_to_breasts, parse_report
    txt = ("Tejido fibroglandular disperso. Nódulo isodenso, espiculado, en tercio medio del cuadrante superior "
           "externo de mama izquierda de 15 mm. Sin microcalcificaciones. CONCLUSIÓN: Tejido tipo B. Nódulo espiculado "
           "en mama izquierda requiere biopsia. BIRADS 5. <= = ADDENDUM= => Elaborado por : DR. JUAN PEREZ LOPEZ, el día "
           "martes, 16 de diciembre de 2014 a las 12:53 hrs. Biopsia tomada la cual reporta carcinoma ductal infiltrante.")
    r = parse_report("Paciente_999", "Bi-Rads 5", txt)
    assert (r["birads"], r["density"], r["lesion_laterality"], r["lesion_type"]) == (5, "B", "L", "masa")
    assert r["lesion_quadrant"] == "CSE" and r["lesion_margin"] == "espiculado" and r["lesion_size_mm"] == 15
    assert r["biopsy_result"] == "maligno" and not r["has_microcalcificaciones"]
    assert "PEREZ" not in r["report_anon"] and "2014" not in r["report_anon"]
    import pandas as pd
    bt = breast_targets(expand_to_breasts(pd.DataFrame([r])), "b5_vs_resto").set_index("laterality")
    assert bt.loc["L", "y_malig"] == 1 and bt.loc["R", "y_malig"] == 0 and bt.loc["R", "label_source"] == "contralateral"


def test_dicom_reader_monochrome1(tmp_path):
    pydicom = pytest.importorskip("pydicom")
    from pydicom.dataset import FileDataset, FileMetaDataset
    from pydicom.uid import ExplicitVRLittleEndian, generate_uid
    from mamoia.data.dicom_io import is_dicom, read_dicom
    img = fake_mammo(negative=True).astype(np.uint16) * 16      # negativo: fondo claro
    meta = FileMetaDataset()
    meta.MediaStorageSOPClassUID = "1.2.840.10008.5.1.4.1.1.1.2"
    meta.MediaStorageSOPInstanceUID = generate_uid()
    meta.TransferSyntaxUID = ExplicitVRLittleEndian
    ds = FileDataset("x", {}, file_meta=meta, preamble=b"\0" * 128)
    ds.PatientName = "SECRETO^NOMBRE"
    ds.Modality, ds.Rows, ds.Columns = "MG", *img.shape
    ds.BitsAllocated, ds.BitsStored, ds.HighBit, ds.PixelRepresentation, ds.SamplesPerPixel = 16, 12, 11, 0, 1
    ds.PhotometricInterpretation, ds.SeriesDescription = "MONOCHROME1", "R MLO"
    ds.PixelData = img.tobytes()
    f = tmp_path / "00000001"
    ds.save_as(f, enforce_file_format=True)
    assert is_dicom(f)
    out, m = read_dicom(f)
    assert out[5, 5] < 50                                       # fondo oscuro tras invertir MONOCHROME1
    assert (m["laterality"], m["projection"], m["lat_source"]) == ("R", "MLO", "texto")
    assert "SECRETO" not in str(m)
