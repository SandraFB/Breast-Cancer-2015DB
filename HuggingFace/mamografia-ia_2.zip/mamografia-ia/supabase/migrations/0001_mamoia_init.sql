-- MamoIA · esquema de Supabase (Postgres) para la app web construida con Lovable.
-- Ejecutar en Supabase > SQL Editor, o dejar que Lovable lo aplique como migración.
-- Principios: (1) sin datos personales: cada estudio usa un código seudónimo;
--             (2) RLS: cada usuario sólo ve lo suyo; los revisores (rol 'radiologo') ven todo;
--             (3) la API de Python escribe resultados con la service_role key (omite RLS).

create extension if not exists "pgcrypto";

-- Perfiles y roles -----------------------------------------------------------------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'estudiante' check (role in ('estudiante','docente','radiologo')),
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name) values (new.id, new.raw_user_meta_data->>'full_name')
  on conflict do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

create or replace function public.is_reviewer() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role in ('docente','radiologo'));
$$;

create or replace function public.my_role() returns text
language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid();
$$;

-- Estudios e imágenes --------------------------------------------------------------
create table if not exists public.studies (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  code text not null,                       -- seudónimo, p.ej. "EST-0208-5"; NUNCA el nombre
  age_range text,                           -- "40-49", "50-59"... (opcional)
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.images (
  id uuid primary key default gen_random_uuid(),
  study_id uuid not null references public.studies(id) on delete cascade,
  owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  storage_path text not null,               -- bucket 'mamografias': {owner_id}/{study_id}/{archivo}
  laterality text check (laterality in ('L','R')),
  projection text check (projection in ('CC','MLO')),
  created_at timestamptz not null default now()
);

-- Análisis de IA -------------------------------------------------------------------
create table if not exists public.analyses (
  id uuid primary key default gen_random_uuid(),
  image_id uuid not null references public.images(id) on delete cascade,
  owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','processing','done','error')),
  llm_backend text default 'template' check (llm_backend in ('template','claude','ollama')),
  prob_malignancy real,
  birads_suggested smallint,
  density_pred text,
  caption_lstm text,
  report jsonb,                             -- {hallazgos, impresion, birads_sugerido, recomendaciones[], ...}
  report_md text,
  findings jsonb,                           -- entrada estructurada que recibió el LLM (auditoría)
  cade jsonb,                               -- resumen del CADe clásico (tesis 2015)
  heatmap_path text,                        -- Grad-CAM en storage
  cade_path text,
  attention_path text,
  model_version text,
  validation_issues text[],
  error text,
  created_at timestamptz not null default now(),
  finished_at timestamptz
);
create index if not exists analyses_image_idx on public.analyses(image_id);

-- Revisión del radiólogo (cierra el ciclo: estas filas se exportan como nuevas etiquetas)
create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  analysis_id uuid not null references public.analyses(id) on delete cascade,
  reviewer_id uuid not null default auth.uid() references auth.users(id),
  agrees boolean,
  final_birads smallint check (final_birads between 0 and 6),
  final_pathology text check (final_pathology in ('normal','benigno','maligno')),
  biopsy_confirmed boolean default false,
  density text check (density in ('A','B','C','D')),
  lesion_type text,
  corrected_report text,
  comments text,
  created_at timestamptz not null default now()
);

-- RLS ------------------------------------------------------------------------------
alter table public.profiles enable row level security;
alter table public.studies  enable row level security;
alter table public.images   enable row level security;
alter table public.analyses enable row level security;
alter table public.reviews  enable row level security;

create policy "perfil propio" on public.profiles for select using (id = auth.uid() or public.is_reviewer());
create policy "editar perfil propio" on public.profiles for update using (id = auth.uid())
  with check (id = auth.uid() and role = public.my_role());   -- nadie se auto-asigna 'radiologo'

create policy "estudios propios" on public.studies for all
  using (owner_id = auth.uid() or public.is_reviewer()) with check (owner_id = auth.uid());
create policy "imagenes propias" on public.images for all
  using (owner_id = auth.uid() or public.is_reviewer()) with check (owner_id = auth.uid());
create policy "ver analisis" on public.analyses for select using (owner_id = auth.uid() or public.is_reviewer());
create policy "crear analisis" on public.analyses for insert with check (owner_id = auth.uid());
create policy "ver revisiones" on public.reviews for select using (
  reviewer_id = auth.uid() or public.is_reviewer()
  or exists (select 1 from public.analyses a where a.id = analysis_id and a.owner_id = auth.uid()));
create policy "revisar" on public.reviews for insert with check (public.is_reviewer() and reviewer_id = auth.uid());

-- Realtime para que la UI se actualice cuando la API termina ------------------------
alter publication supabase_realtime add table public.analyses;

-- Storage --------------------------------------------------------------------------
insert into storage.buckets (id, name, public) values ('mamografias', 'mamografias', false)
  on conflict (id) do nothing;
insert into storage.buckets (id, name, public) values ('resultados', 'resultados', false)
  on conflict (id) do nothing;

create policy "subir a mi carpeta" on storage.objects for insert to authenticated
  with check (bucket_id = 'mamografias' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "leer mis archivos" on storage.objects for select to authenticated
  using (bucket_id in ('mamografias','resultados')
         and ((storage.foldername(name))[1] = auth.uid()::text or public.is_reviewer()));

-- Vista para el tablero y para exportar etiquetas -----------------------------------
create or replace view public.labeled_for_training with (security_invoker = true) as
select i.id as image_id, i.storage_path, i.laterality, i.projection,
       r.final_birads as birads, r.final_pathology as pathology, r.biopsy_confirmed,
       r.density, r.lesion_type, coalesce(r.corrected_report, a.report_md) as report_text,
       a.prob_malignancy, a.model_version, r.created_at as reviewed_at
from public.reviews r
join public.analyses a on a.id = r.analysis_id
join public.images i on i.id = a.image_id;
