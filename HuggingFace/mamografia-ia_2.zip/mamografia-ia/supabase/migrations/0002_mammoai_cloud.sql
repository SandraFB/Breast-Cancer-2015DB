-- MammoAI Assistant · esquema para Lovable Cloud (Supabase)
-- Roles en tabla aparte (evita escalamiento de privilegios), sin datos personales de pacientes.

-- Roles -----------------------------------------------------------------------------------
create type public.app_role as enum ('estudiante', 'docente', 'radiologo');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  created_at timestamptz not null default now()
);

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null,
  unique (user_id, role)
);

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create or replace function public.is_reviewer(_user_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role in ('docente', 'radiologo'))
$$;

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name) values (new.id, new.raw_user_meta_data->>'full_name');
  insert into public.user_roles (user_id, role) values (new.id, 'estudiante');
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Estudios, imágenes, análisis -------------------------------------------------------------
create table public.studies (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  code text not null,                         -- seudónimo (p.ej. EST-0208). NUNCA nombre de paciente
  age_range text,
  notes text,
  created_at timestamptz not null default now()
);

create table public.images (
  id uuid primary key default gen_random_uuid(),
  study_id uuid not null references public.studies(id) on delete cascade,
  owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  storage_path text not null,                 -- bucket mamografias: {owner_id}/{study_id}/{uuid}
  original_name text,
  laterality text check (laterality in ('L', 'R')),
  projection text check (projection in ('CC', 'MLO')),
  created_at timestamptz not null default now()
);

create table public.analyses (
  id uuid primary key default gen_random_uuid(),
  image_id uuid not null references public.images(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending', 'processing', 'done', 'error')),
  llm_backend text not null default 'template',
  llm_backend_used text,
  prob_malignancy real,
  threshold real,
  birads_suggested smallint,
  density_pred text,
  caption_lstm text,
  report_md text,
  report jsonb,
  findings jsonb,
  cade jsonb,
  localization jsonb,
  preview_path text, heatmap_path text, attention_path text, cade_path text,   -- bucket resultados
  model_version text,
  validation_issues text[],
  seconds real,
  error text,
  created_at timestamptz not null default now(),
  finished_at timestamptz
);
create index on public.analyses (image_id, created_at desc);

create table public.study_reports (
  id uuid primary key default gen_random_uuid(),
  study_id uuid not null references public.studies(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending', 'processing', 'done', 'error')),
  llm_backend text not null default 'template',
  llm_backend_used text,
  birads_suggested smallint,
  worst_side text,
  density_pred text,
  report_md text,
  report jsonb,
  per_breast jsonb,
  views jsonb,
  model_version text,
  validation_issues text[],
  seconds real,
  error text,
  created_at timestamptz not null default now(),
  finished_at timestamptz
);
create index on public.study_reports (study_id, created_at desc);

create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  study_report_id uuid references public.study_reports(id) on delete cascade,
  analysis_id uuid references public.analyses(id) on delete cascade,
  reviewer_id uuid not null default auth.uid() references auth.users(id),
  agrees boolean,
  final_birads smallint check (final_birads between 0 and 6),
  final_side text check (final_side in ('L', 'R', 'B', 'N')),
  final_pathology text check (final_pathology in ('normal', 'benigno', 'maligno', 'desconocida')),
  biopsy_confirmed boolean not null default false,
  density text check (density in ('A', 'B', 'C', 'D')),
  lesion_type text,
  report_quality smallint check (report_quality between 1 and 5),
  corrected_report text,
  comments text,
  created_at timestamptz not null default now(),
  check (study_report_id is not null or analysis_id is not null)
);

-- RLS ----------------------------------------------------------------------------------------
alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;
alter table public.studies enable row level security;
alter table public.images enable row level security;
alter table public.analyses enable row level security;
alter table public.study_reports enable row level security;
alter table public.reviews enable row level security;

create policy "ver perfiles" on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_reviewer(auth.uid()));
create policy "editar mi perfil" on public.profiles for update to authenticated using (id = auth.uid());

create policy "ver roles" on public.user_roles for select to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(), 'docente'));
create policy "docente asigna roles" on public.user_roles for insert to authenticated
  with check (public.has_role(auth.uid(), 'docente'));
create policy "docente quita roles" on public.user_roles for delete to authenticated
  using (public.has_role(auth.uid(), 'docente'));

create policy "estudios: ver" on public.studies for select to authenticated
  using (owner_id = auth.uid() or public.is_reviewer(auth.uid()));
create policy "estudios: crear" on public.studies for insert to authenticated with check (owner_id = auth.uid());
create policy "estudios: editar" on public.studies for update to authenticated using (owner_id = auth.uid());
create policy "estudios: borrar" on public.studies for delete to authenticated using (owner_id = auth.uid());

create policy "imagenes: ver" on public.images for select to authenticated
  using (owner_id = auth.uid() or public.is_reviewer(auth.uid()));
create policy "imagenes: crear" on public.images for insert to authenticated with check (owner_id = auth.uid());
create policy "imagenes: editar" on public.images for update to authenticated using (owner_id = auth.uid());
create policy "imagenes: borrar" on public.images for delete to authenticated using (owner_id = auth.uid());

-- análisis y reportes: los escribe SOLO la función de backend (service role); el usuario sólo lee
create policy "analisis: ver" on public.analyses for select to authenticated
  using (owner_id = auth.uid() or public.is_reviewer(auth.uid()));
create policy "reportes: ver" on public.study_reports for select to authenticated
  using (owner_id = auth.uid() or public.is_reviewer(auth.uid()));

create policy "revisiones: ver" on public.reviews for select to authenticated
  using (reviewer_id = auth.uid() or public.is_reviewer(auth.uid())
         or exists (select 1 from public.study_reports s where s.id = study_report_id and s.owner_id = auth.uid())
         or exists (select 1 from public.analyses a where a.id = analysis_id and a.owner_id = auth.uid()));
create policy "revisiones: crear" on public.reviews for insert to authenticated
  with check (public.is_reviewer(auth.uid()) and reviewer_id = auth.uid());

alter publication supabase_realtime add table public.analyses, public.study_reports;

-- Storage ------------------------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit)
values ('mamografias', 'mamografias', false, 62914560), ('resultados', 'resultados', false, 10485760)
on conflict (id) do nothing;

create policy "mamografias: subir a mi carpeta" on storage.objects for insert to authenticated
  with check (bucket_id = 'mamografias' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "mamografias: leer" on storage.objects for select to authenticated
  using (bucket_id = 'mamografias' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_reviewer(auth.uid())));
create policy "mamografias: borrar" on storage.objects for delete to authenticated
  using (bucket_id = 'mamografias' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "resultados: leer" on storage.objects for select to authenticated
  using (bucket_id = 'resultados' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_reviewer(auth.uid())));

-- Vista para exportar etiquetas revisadas (reentrenamiento) -----------------------------------
create or replace view public.labeled_for_training with (security_invoker = true) as
select st.code as study_code, sr.id as study_report_id, sr.birads_suggested as birads_ia, sr.worst_side as side_ia,
       r.final_birads, r.final_side, r.final_pathology, r.biopsy_confirmed, r.density, r.lesion_type,
       r.agrees, r.report_quality, r.corrected_report, sr.model_version, sr.llm_backend_used, r.created_at as reviewed_at
from public.reviews r
join public.study_reports sr on sr.id = r.study_report_id
join public.studies st on st.id = sr.study_id;
