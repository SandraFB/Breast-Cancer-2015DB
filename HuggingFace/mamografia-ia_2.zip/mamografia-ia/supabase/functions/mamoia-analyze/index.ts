// Edge Function: mamoia-analyze  (Lovable Cloud / Supabase)
//
// Invocación desde la app:
//   supabase.functions.invoke("mamoia-analyze", { body: { mode: "image", image_id, llm_backend } })
//   supabase.functions.invoke("mamoia-analyze", { body: { mode: "study", study_id, llm_backend } })
// Responde de inmediato (202) con el id del registro y procesa en segundo plano; la UI escucha los
// cambios por Realtime (tablas analyses / study_reports).
//
// Secrets: MAMOIA_API_URL (https://qsandradelaf-mammoai-api.hf.space) y MAMOIA_API_KEY.
// SUPABASE_URL, SUPABASE_ANON_KEY y SUPABASE_SERVICE_ROLE_KEY los provee la plataforma.
import { createClient, type SupabaseClient } from "npm:@supabase/supabase-js@2";

declare const EdgeRuntime: { waitUntil(p: Promise<unknown>): void };

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...cors, "content-type": "application/json" } });
const LLMS = ["template", "claude", "ollama"];

async function callApi(path: string, form: () => FormData): Promise<any> {
  const base = Deno.env.get("MAMOIA_API_URL")!.replace(/\/$/, "");
  const key = Deno.env.get("MAMOIA_API_KEY")!;
  let last = "";
  // el Space gratuito "duerme": los primeros intentos pueden dar 502/503 mientras arranca
  for (let i = 0; i < 6; i++) {
    try {
      const r = await fetch(`${base}${path}`, {
        method: "POST", headers: { "x-api-key": key }, body: form(), signal: AbortSignal.timeout(280_000),
      });
      if (r.ok) return await r.json();
      last = `${r.status} ${(await r.text()).slice(0, 300)}`;
      if (![502, 503, 504].includes(r.status)) break;
    } catch (e) {
      last = String(e);
    }
    await new Promise((res) => setTimeout(res, 20_000));
  }
  throw new Error(`API MamoIA: ${last}`);
}

const b64ToBytes = (b64: string) => Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));

async function runImage(admin: SupabaseClient, img: any, id: string, llm: string, uid: string) {
  try {
    const { data: blob, error } = await admin.storage.from("mamografias").download(img.storage_path);
    if (error || !blob) throw new Error(`No se pudo leer la imagen: ${error?.message}`);
    const r = await callApi("/analyze", () => {
      const f = new FormData();
      f.append("file", blob, img.original_name ?? "imagen");
      if (img.laterality) f.append("laterality", img.laterality);
      if (img.projection) f.append("projection", img.projection);
      f.append("llm_backend", llm);
      return f;
    });
    const paths: Record<string, string> = {};
    for (const [k, b64] of Object.entries(r.imagenes_jpg_b64 ?? {})) {
      const p = `${uid}/${id}/${k}.jpg`;
      const up = await admin.storage.from("resultados").upload(p, b64ToBytes(b64 as string),
        { contentType: "image/jpeg", upsert: true });
      if (!up.error) paths[k] = p;
    }
    const s = r.resumen ?? {};
    await admin.from("analyses").update({
      status: "done", prob_malignancy: s.prob_malignancy, threshold: r.clasificador?.umbral ?? null,
      birads_suggested: s.birads_suggested, density_pred: s.density_pred, caption_lstm: s.caption_lstm,
      report_md: s.report_md, report: r.reporte?.report ?? null, findings: r.reporte?.findings ?? null,
      cade: r.cade_clasico ?? null, localization: r.localizacion ?? null,
      preview_path: paths.preprocesada ?? null, heatmap_path: paths.gradcam ?? null,
      attention_path: paths.atencion_lstm ?? null, cade_path: paths.cade ?? null,
      model_version: s.model_version, llm_backend_used: s.llm_backend, validation_issues: s.validation_issues ?? [],
      seconds: s.seconds, finished_at: new Date().toISOString(),
    }).eq("id", id);
    // DICOM: la API lee lateralidad/proyección de las etiquetas; se completan si faltaban
    const patch: Record<string, string> = {};
    if (!img.laterality && ["L", "R"].includes(s.laterality)) patch.laterality = s.laterality;
    if (!img.projection && ["CC", "MLO"].includes(s.projection)) patch.projection = s.projection;
    if (Object.keys(patch).length) await admin.from("images").update(patch).eq("id", img.id);
  } catch (e) {
    await admin.from("analyses").update({ status: "error", error: String(e).slice(0, 500) }).eq("id", id);
  }
}

async function runStudy(admin: SupabaseClient, imgs: any[], id: string, llm: string) {
  try {
    const blobs: Blob[] = [];
    for (const im of imgs) {
      const { data, error } = await admin.storage.from("mamografias").download(im.storage_path);
      if (error || !data) throw new Error(`No se pudo leer ${im.original_name}: ${error?.message}`);
      blobs.push(data);
    }
    const r = await callApi("/analyze/study", () => {
      const f = new FormData();
      imgs.forEach((im, i) => f.append("files", blobs[i], im.original_name ?? `vista${i + 1}`));
      f.append("lateralities", imgs.map((im) => im.laterality ?? "").join(","));
      f.append("projections", imgs.map((im) => im.projection ?? "").join(","));
      f.append("llm_backend", llm);
      return f;
    });
    const s = r.resumen ?? {};
    await admin.from("study_reports").update({
      status: "done", birads_suggested: s.birads_suggested, worst_side: s.worst_side, density_pred: s.density_pred,
      report_md: s.report_md, report: r.reporte?.report ?? null, per_breast: r.por_mama ?? null, views: r.vistas ?? null,
      model_version: s.model_version, llm_backend_used: s.llm_backend, validation_issues: s.validation_issues ?? [],
      seconds: s.seconds, finished_at: new Date().toISOString(),
    }).eq("id", id);
  } catch (e) {
    await admin.from("study_reports").update({ status: "error", error: String(e).slice(0, 500) }).eq("id", id);
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const url = Deno.env.get("SUPABASE_URL")!;
    const asUser = createClient(url, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } },
    });
    const { data: { user } } = await asUser.auth.getUser();
    if (!user) return json({ error: "No autenticado" }, 401);
    const admin = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    const body = await req.json();
    const llm = LLMS.includes(body.llm_backend) ? body.llm_backend : "template";

    if (body.mode === "study") {
      // RLS: sólo estudios propios (o de revisores)
      const { data: study } = await asUser.from("studies").select("id, owner_id").eq("id", body.study_id).single();
      if (!study) return json({ error: "Estudio no encontrado" }, 404);
      const { data: imgs } = await asUser.from("images").select("*").eq("study_id", study.id).order("created_at");
      if (!imgs?.length) return json({ error: "El estudio no tiene imágenes" }, 400);
      const { data: rep, error } = await admin.from("study_reports")
        .insert({ study_id: study.id, owner_id: study.owner_id, status: "processing", llm_backend: llm })
        .select().single();
      if (error) throw error;
      EdgeRuntime.waitUntil(runStudy(admin, imgs.slice(0, 8), rep.id, llm));
      return json({ study_report_id: rep.id }, 202);
    }

    const { data: img } = await asUser.from("images").select("*").eq("id", body.image_id).single();
    if (!img) return json({ error: "Imagen no encontrada" }, 404);
    const { data: an, error } = await admin.from("analyses")
      .insert({ image_id: img.id, owner_id: img.owner_id, status: "processing", llm_backend: llm })
      .select().single();
    if (error) throw error;
    EdgeRuntime.waitUntil(runImage(admin, img, an.id, llm, img.owner_id));
    return json({ analysis_id: an.id }, 202);
  } catch (e) {
    return json({ error: String((e as Error)?.message ?? e) }, 500);
  }
});
