// Supabase Edge Function: analyze
// La app de Lovable la invoca con:  supabase.functions.invoke('analyze', { body: { image_id, llm_backend } })
// 1) verifica al usuario, 2) crea la fila en `analyses`, 3) llama a la API de Python (MamoIA)
//    que procesa la imagen y escribe el resultado en la misma fila. La UI escucha por Realtime.
//
// Secrets necesarios (Supabase > Edge Functions > Secrets):
//   MAMOIA_API_URL   p.ej. https://<tu-space>.hf.space
//   MAMOIA_API_KEY   clave compartida con la API de Python
import { createClient } from "npm:@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const { image_id, llm_backend = "template" } = await req.json();
    if (!image_id) throw new Error("image_id requerido");
    if (!["template", "claude", "ollama"].includes(llm_backend)) throw new Error("llm_backend inválido");

    // cliente con el JWT del usuario: respeta RLS (sólo puede analizar SUS imágenes)
    const supa = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: req.headers.get("Authorization")! } },
    });
    const { data: img, error: e1 } = await supa.from("images").select("*").eq("id", image_id).single();
    if (e1 || !img) throw new Error("Imagen no encontrada o sin permiso");

    const { data: analysis, error: e2 } = await supa.from("analyses")
      .insert({ image_id, llm_backend, status: "pending" }).select().single();
    if (e2) throw e2;

    // dispara el procesamiento (la API responde 202 y trabaja en segundo plano)
    const r = await fetch(`${Deno.env.get("MAMOIA_API_URL")}/analyze/supabase`, {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": Deno.env.get("MAMOIA_API_KEY")! },
      body: JSON.stringify({
        analysis_id: analysis.id, storage_path: img.storage_path,
        laterality: img.laterality, projection: img.projection, llm_backend,
      }),
    });
    if (!r.ok) throw new Error(`API MamoIA respondió ${r.status}`);

    return new Response(JSON.stringify({ analysis_id: analysis.id }), {
      headers: { ...cors, "content-type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err?.message ?? err) }), {
      status: 400, headers: { ...cors, "content-type": "application/json" },
    });
  }
});
