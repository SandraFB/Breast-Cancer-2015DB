---
title: MammoAI API
emoji: 🩺
colorFrom: pink
colorTo: indigo
sdk: docker
app_port: 7860
pinned: false
short_description: API docente MamoIA (CNN + LSTM + LLM) para MammoAI Assistant
---

# MammoAI API

API de inferencia del proyecto docente MamoIA (TecNM / tesis CICATA-IPN 2015). Recibe mastografías
(DICOM/JPG/PNG) y devuelve probabilidad, Grad-CAM, descripción CNN-LSTM y borrador de reporte BI-RADS.

**Herramienta educativa y de investigación. No es un dispositivo médico.** Requiere el encabezado
`x-api-key`. Endpoints: `GET /health`, `POST /analyze`, `POST /analyze/study`.
