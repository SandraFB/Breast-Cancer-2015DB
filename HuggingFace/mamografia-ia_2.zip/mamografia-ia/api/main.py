"""API de inferencia MamoIA (FastAPI) — SIN ESTADO.

La API no guarda nada ni necesita credenciales de la base de datos: recibe la imagen, devuelve
JSON + imágenes (base64) y la Edge Function de Lovable Cloud es quien escribe en Storage y en las
tablas. Así las llaves de Supabase nunca salen de Lovable.

Endpoints
  GET  /health            estado, versión del modelo, umbral y métricas de validación cruzada
  POST /analyze           multipart: file (DICOM/JPG/PNG) [+ laterality, projection, llm_backend]
  POST /analyze/study     multipart: files[] (2-4 vistas del estudio) [+ llm_backend]
                          -> reporte BILATERAL (una categoría por estudio)

Encabezado obligatorio en producción:  x-api-key: <MAMOIA_API_KEY>

Variables de entorno
  MAMOIA_API_KEY                      clave compartida con la Edge Function
  CLASSIFIER_CKPT / CAPTIONER_CKPT    checkpoints (default checkpoints/*.pt)
  ANTHROPIC_API_KEY, CLAUDE_MODEL     backend claude (opcional)
  OLLAMA_HOST, OLLAMA_MODEL           backend ollama (opcional)

Ejecutar:  uvicorn api.main:app --host 0.0.0.0 --port 7860
"""
from __future__ import annotations

import base64
import json
import os
import tempfile
import threading
import time
from pathlib import Path

import cv2
import numpy as np
import torch
from fastapi import FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware

from mamoia.pipeline import MamoPipeline

torch.set_num_threads(max(1, os.cpu_count() or 1))
app = FastAPI(title="MamoIA API", version="0.2.0",
              description="Apoyo docente a la lectura de mamografías. No es un dispositivo médico.")
app.add_middleware(CORSMiddleware, allow_origins=os.environ.get("CORS_ORIGINS", "*").split(","),
                   allow_methods=["*"], allow_headers=["*"])

CLS = os.environ.get("CLASSIFIER_CKPT", "checkpoints/classifier.pt")
CAP = os.environ.get("CAPTIONER_CKPT", "checkpoints/captioner.pt")
PIPE = MamoPipeline.load(CLS, CAP)
CARD = json.loads(Path(CLS).with_name("model_card.json").read_text()) if Path(CLS).with_name("model_card.json").exists() else {}
API_KEY = os.environ.get("MAMOIA_API_KEY")
LOCK = threading.Lock()          # Grad-CAM usa gradientes: una inferencia a la vez
LLMS = {"template", "claude", "ollama"}
MAX_BYTES = 60 * 1024 * 1024


def _check_key(x_api_key: str | None):
    if API_KEY and x_api_key != API_KEY:
        raise HTTPException(401, "x-api-key inválida")


def _decode(data: bytes):
    """DICOM -> ruta temporal (para leer sus etiquetas de vista); JPG/PNG -> arreglo gris."""
    if len(data) > MAX_BYTES:
        raise HTTPException(413, "Archivo demasiado grande")
    if len(data) > 132 and data[128:132] == b"DICM":
        f = tempfile.NamedTemporaryFile(suffix=".dcm", delete=False)
        f.write(data)
        f.close()
        return f.name
    img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_UNCHANGED)
    if img is None:
        raise HTTPException(400, "No se pudo leer la imagen (DICOM, JPG o PNG)")
    if img.ndim == 3:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    if img.dtype != np.uint8:
        lo, hi = np.percentile(img, (0.5, 99.5))
        img = np.clip((img - lo) / max(hi - lo, 1) * 255, 0, 255).astype(np.uint8)
    return img


def _jpg_b64(img: np.ndarray, q: int = 88) -> str:
    ok, buf = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, q])
    return base64.b64encode(buf.tobytes()).decode()


def _cleanup(x):
    if isinstance(x, str) and x.endswith(".dcm"):
        try:
            os.unlink(x)
        except OSError:
            pass


def _llm(name: str) -> str:
    if name not in LLMS:
        raise HTTPException(400, f"llm_backend debe ser uno de {sorted(LLMS)}")
    return name


@app.get("/")
@app.get("/health")
def health():
    return {"status": "ok", "model_version": PIPE.model_version, "captioner": PIPE.captioner is not None,
            "threshold": PIPE.cfg["thresholds"]["malignancy_high"], "model_card": CARD,
            "llm_disponibles": ["template"] + (["claude"] if os.environ.get("ANTHROPIC_API_KEY") else [])
            + (["ollama"] if os.environ.get("OLLAMA_HOST") else []),
            "aviso": "Herramienta docente; no es un dispositivo médico."}


@app.post("/analyze")
async def analyze(file: UploadFile = File(...), laterality: str | None = Form(None),
                  projection: str | None = Form(None), llm_backend: str = Form("template"),
                  x_api_key: str | None = Header(None)):
    _check_key(x_api_key)
    src = _decode(await file.read())
    t0 = time.time()
    try:
        with LOCK:
            r = PIPE.analyze(src, laterality or None, projection or None, _llm(llm_backend), with_images=False)
    finally:
        _cleanup(src)
    images = {k: _jpg_b64(v) for k, v in r.pop("_images").items()}
    cls = r.get("clasificador") or {}
    rep = r["reporte"]
    # resumen plano: es lo que la Edge Function guarda en columnas
    r["resumen"] = {"laterality": r.get("laterality"), "projection": r.get("projection"),
                    "prob_malignancy": cls.get("prob_malignidad"),
                    "birads_suggested": rep["report"].get("birads_sugerido"),
                    "density_pred": rep["findings"].get("densidad_predicha"),
                    "caption_lstm": r.get("caption_lstm"), "report_md": rep["markdown"],
                    "llm_backend": rep["llm_backend"], "validation_issues": rep["validation_issues"],
                    "model_version": r["model_version"], "seconds": round(time.time() - t0, 2)}
    r["imagenes_jpg_b64"] = images
    return r


@app.post("/analyze/study")
async def analyze_study(files: list[UploadFile] = File(...), lateralities: str | None = Form(None),
                        projections: str | None = Form(None), llm_backend: str = Form("template"),
                        x_api_key: str | None = Header(None)):
    """lateralities/projections opcionales, separadas por coma en el mismo orden que files
    (p.ej. "L,R,L,R" y "CC,CC,MLO,MLO"); en DICOM se leen de las etiquetas."""
    _check_key(x_api_key)
    if not 1 <= len(files) <= 8:
        raise HTTPException(400, "Envíe entre 1 y 8 imágenes del mismo estudio")
    lats = (lateralities or "").split(",")
    projs = (projections or "").split(",")
    items = []
    for i, f in enumerate(files):
        src = _decode(await f.read())
        items.append((src, (lats[i] if i < len(lats) else "") or None, (projs[i] if i < len(projs) else "") or None))
    t0 = time.time()
    try:
        with LOCK:
            r = PIPE.analyze_study(items, llm=_llm(llm_backend))
    finally:
        for src, _, _ in items:
            _cleanup(src)
    r.pop("_images", None)
    rep = r["reporte"]
    por_mama = {k: {"prob_malignancy": (v.get("clasificador") or {}).get("prob_malignidad"),
                    "prob_por_vista": (v.get("clasificador") or {}).get("prob_por_vista"),
                    "localizacion": v.get("localizacion"), "caption_lstm": v.get("caption_lstm")}
                for k, v in r["por_mama"].items()}
    return {"resumen": {"birads_suggested": rep["report"].get("birads_sugerido"),
                        "worst_side": {"izquierda": "L", "derecha": "R"}.get(rep["findings"].get("mama_de_mayor_sospecha")),
                        "density_pred": rep["findings"].get("densidad_predicha"), "report_md": rep["markdown"],
                        "llm_backend": rep["llm_backend"], "validation_issues": rep["validation_issues"],
                        "model_version": PIPE.model_version, "seconds": round(time.time() - t0, 2)},
            "por_mama": por_mama, "reporte": rep,
            "vistas": [{"fuente": x.get("fuente"), "laterality": x.get("laterality"), "projection": x.get("projection"),
                        "prob_malignancy": (x.get("clasificador") or {}).get("prob_malignidad")} for x in r["por_imagen"]]}
