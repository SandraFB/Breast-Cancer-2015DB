"""Grad-CAM para la cabeza de malignidad + localización anatómica del pico de activación."""
from __future__ import annotations

import cv2
import numpy as np
import torch
import torch.nn.functional as F


def gradcam(model, x: torch.Tensor, target: str = "malignancy", class_idx: int | None = None) -> np.ndarray:
    """Devuelve un mapa 0-1 del tamaño de la imagen de entrada (H, W)."""
    model.eval()
    x = x.clone().requires_grad_(True)   # funciona aunque los pesos estén congelados
    fmap = model.features(x)
    fmap.retain_grad()
    z = model.pool(fmap)
    if target == "malignancy":
        score = model.head_malig(z).squeeze()
    else:
        logits = getattr(model, f"head_{target}")(z)
        score = logits[0, class_idx if class_idx is not None else logits.argmax(1).item()]
    model.zero_grad()
    score.backward()
    w = fmap.grad.mean(dim=(2, 3), keepdim=True)
    cam = F.relu((w * fmap).sum(1, keepdim=True))
    cam = F.interpolate(cam, size=x.shape[-2:], mode="bilinear", align_corners=False)[0, 0]
    cam = cam.detach().cpu().numpy()
    return (cam - cam.min()) / (cam.max() - cam.min() + 1e-8)


def attention_map(alpha: torch.Tensor, hw, out_hw) -> np.ndarray:
    """Promedia los pesos de atención del LSTM (T, N) y los lleva al tamaño de la imagen."""
    a = alpha.float().mean(0).reshape(*hw).cpu().numpy()
    a = cv2.resize(a, (out_hw[1], out_hw[0]), interpolation=cv2.INTER_CUBIC)
    return (a - a.min()) / (a.max() - a.min() + 1e-8)


def overlay(img: np.ndarray, heat: np.ndarray, alpha=0.4) -> np.ndarray:
    color = cv2.applyColorMap((heat * 255).astype(np.uint8), cv2.COLORMAP_JET)
    base = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    return cv2.addWeighted(base, 1 - alpha, color, alpha, 0)


def locate_peak(heat: np.ndarray, mask: np.ndarray, laterality: str | None, projection: str | None,
                n_zones: int = 3) -> dict:
    """Traduce el pico del mapa de calor a zona de profundidad y región anatómica.

    Imagen orientada con el tórax a la izquierda (x=0) y el pezón a la derecha.
    En CC la correspondencia arriba/abajo con externo/interno depende del equipo y del montaje,
    por eso se reporta como 'superior/central/inferior de la imagen' y la traducción a cuadrante
    queda a cargo del radiólogo (o de una regla que el equipo valide con sus propias placas).
    """
    h = heat * mask if mask is not None and mask.any() else heat
    y, x = np.unravel_index(np.argmax(h), h.shape)
    cols = np.where(mask.any(0))[0] if mask is not None and mask.any() else np.arange(h.shape[1])
    rows = np.where(mask.any(1))[0] if mask is not None and mask.any() else np.arange(h.shape[0])
    rel_x = (x - cols.min()) / max(1, cols.max() - cols.min())
    rel_y = (y - rows.min()) / max(1, rows.max() - rows.min())
    zone = ("posterior", "media", "anterior")[min(2, int(rel_x * n_zones))]
    vert = "superior" if rel_y < 1 / 3 else "central" if rel_y < 2 / 3 else "inferior"
    focal = float((h > 0.6).mean() / max(1e-6, (mask.mean() if mask is not None else 1)))
    return {"depth_zone": zone, "vertical_region": vert, "peak_xy": [int(x), int(y)],
            "activation_extent": round(focal, 3), "laterality": laterality, "projection": projection}
