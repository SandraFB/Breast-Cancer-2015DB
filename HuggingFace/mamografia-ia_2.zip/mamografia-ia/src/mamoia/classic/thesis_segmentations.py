"""Convierte los resultados de segmentación de la tesis (contornos verdes sobre la mamografía,
carpeta DB-segmentation-2015) en máscaras binarias y estadísticas por imagen.

Las máscaras sirven para:
  * comparar cualitativamente las ROIs de la tesis contra Grad-CAM de la CNN;
  * enseñar métricas de segmentación (Dice/IoU) entre la versión 2015 (MATLAB) y la
    reimplementación en Python (mamoia.classic.cade) sobre las mismas imágenes recortadas.
OJO: los contornos son detecciones del algoritmo (TP + FP), NO verdad de referencia.

Uso:
  python -m mamoia.classic.thesis_segmentations --seg data/raw/segmentation --out data/thesis_masks
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2
import numpy as np
from scipy import ndimage as ndi


def green_contour_mask(bgr: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Devuelve (máscara rellena de ROIs, imagen gris sin contornos)."""
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    contour = (hsv[..., 1] > 50) & (hsv[..., 0] > 40) & (hsv[..., 0] < 85)   # tono verde saturado
    # la compresión JPEG rompe los contornos: se cierran antes de rellenar
    contour = cv2.morphologyEx(contour.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8)) > 0
    filled = ndi.binary_fill_holes(contour)
    lab, n = ndi.label(filled)
    if n:
        sizes = ndi.sum(filled, lab, range(1, n + 1))
        filled = np.isin(lab, 1 + np.where(sizes >= 40)[0])
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    clean = cv2.inpaint(gray, contour.astype(np.uint8), 3, cv2.INPAINT_TELEA)
    return filled, clean


def dice(a: np.ndarray, b: np.ndarray) -> float:
    a, b = a.astype(bool), b.astype(bool)
    return float(2 * (a & b).sum() / max(1, a.sum() + b.sum()))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--seg", required=True)
    ap.add_argument("--out", default="data/thesis_masks")
    args = ap.parse_args()
    out = Path(args.out)
    (out / "mask").mkdir(parents=True, exist_ok=True)
    (out / "clean").mkdir(parents=True, exist_ok=True)
    stats = {}
    for p in sorted(Path(args.seg).glob("*.jp*g")):
        bgr = cv2.imread(str(p))
        m, clean = green_contour_mask(bgr)
        _, n = ndi.label(m)
        cv2.imwrite(str(out / "mask" / f"{p.stem}.png"), m.astype(np.uint8) * 255)
        cv2.imwrite(str(out / "clean" / f"{p.stem}.png"), clean)
        stats[p.stem] = {"n_rois": int(n), "roi_area_frac": round(float(m.mean()), 4)}
    (out / "stats.json").write_text(json.dumps(stats, indent=1))
    print(f"{len(stats)} segmentaciones -> {out}")


if __name__ == "__main__":
    main()
