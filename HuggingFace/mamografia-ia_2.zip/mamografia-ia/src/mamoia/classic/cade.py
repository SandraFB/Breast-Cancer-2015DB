"""Reimplementación en Python del CADe de la tesis (De la Fuente, CICATA-IPN, 2015).

  Realce por ZONAS DE PROFUNDIDAD (posterior / media / anterior):
    1. Transformada Top-Hat con disco cuyo radio depende de la longitud de la zona.
    2. CLAHE.
    3. Filtrado anisotrópico difuso (Perona-Malik, EDP).
  Segmentación:
    4. Umbral óptimo por entropía de Tsallis-Havrda-Charvát.
  Extracción de características (Cap. 5): área, circularidad, energía, ASM/homogeneidad,
  contraste, entropía (GLCM) y zona de profundidad.

Se usa como (a) baseline clásico para comparar con la CNN, (b) generador de candidatos/ROIs
y (c) fuente de características numéricas que alimentan el reporte del LLM.
Opera sobre la salida de mamoia.data.preprocess (mama orientada con el tórax a la izquierda).
"""
from __future__ import annotations

from dataclasses import asdict, dataclass

import cv2
import numpy as np
from skimage.feature import graycomatrix, graycoprops
from skimage.measure import label, regionprops

ZONES = ("posterior", "media", "anterior")   # desde el tórax hacia el pezón


@dataclass
class ROI:
    bbox: tuple[int, int, int, int]       # y0, x0, y1, x1
    centroid: tuple[float, float]
    area_px: int
    circularity: float
    mean_intensity: float
    contrast_vs_bg: float
    glcm_energy: float
    glcm_homogeneity: float
    glcm_contrast: float
    glcm_entropy: float
    depth_zone: str
    vertical_region: str                  # superior | central | inferior
    score: float                          # heurística de sospecha 0-1 (no es probabilidad clínica)

    def to_dict(self):
        return asdict(self)


def perona_malik(img: np.ndarray, n_iter=15, kappa=30.0, gamma=0.15) -> np.ndarray:
    """Difusión anisotrópica (Perona & Malik, 1990): suaviza ruido y preserva bordes."""
    u = img.astype(np.float32)
    for _ in range(n_iter):
        dn = np.roll(u, -1, 0) - u
        ds = np.roll(u, 1, 0) - u
        de = np.roll(u, -1, 1) - u
        dw = np.roll(u, 1, 1) - u
        c = lambda d: np.exp(-(d / kappa) ** 2)  # noqa: E731
        u += gamma * (c(dn) * dn + c(ds) * ds + c(de) * de + c(dw) * dw)
    return np.clip(u, 0, 255).astype(np.uint8)


def tsallis_threshold(img: np.ndarray, mask: np.ndarray | None = None, q: float = 0.8) -> int:
    """Umbral que maximiza la entropía de Tsallis (pseudo-aditiva) de fondo + objeto."""
    vals = img[mask] if mask is not None else img.ravel()
    p = np.bincount(vals.ravel(), minlength=256).astype(np.float64)
    p /= p.sum() + 1e-12
    P = np.cumsum(p)
    best_t, best = 0, -np.inf
    for t in range(1, 255):
        pa, pb = P[t], 1 - P[t]
        if pa < 1e-6 or pb < 1e-6:
            continue
        sa = (1 - np.sum((p[: t + 1] / pa) ** q)) / (q - 1)
        sb = (1 - np.sum((p[t + 1:] / pb) ** q)) / (q - 1)
        s = sa + sb + (1 - q) * sa * sb
        if s > best:
            best, best_t = s, t
    return best_t


def depth_zone_map(mask: np.ndarray, n_zones: int = 3) -> tuple[np.ndarray, int]:
    """Etiqueta cada píxel con su zona de profundidad según la distancia al tórax (x=0)."""
    cols = np.where(mask.any(0))[0]
    x0, x1 = (cols.min(), cols.max()) if len(cols) else (0, mask.shape[1] - 1)
    length = max(1, x1 - x0)
    xs = np.clip((np.arange(mask.shape[1]) - x0) / length, 0, 0.999)
    zone_row = (xs * n_zones).astype(int)
    return np.broadcast_to(zone_row, mask.shape).copy() * mask + (~mask) * -1, length


def enhance_by_zones(img, mask, n_zones=3, radius_frac=0.25, diff_iters=15, kappa=30):
    zones, length = depth_zone_map(mask, n_zones)
    zone_len = length / n_zones
    out = np.zeros_like(img)
    for z in range(n_zones):
        zm = zones == z
        if not zm.any():
            continue
        r = int(np.clip(zone_len * radius_frac, 3, 60))
        se = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * r + 1, 2 * r + 1))
        th = cv2.morphologyEx(img, cv2.MORPH_TOPHAT, se)
        th = cv2.createCLAHE(2.0, (8, 8)).apply(cv2.normalize(th, None, 0, 255, cv2.NORM_MINMAX))
        out[zm] = th[zm]
    return perona_malik(out, diff_iters, kappa), zones


def _glcm_feats(patch: np.ndarray) -> tuple[float, float, float, float]:
    q = (patch // 8).astype(np.uint8)  # 32 niveles
    g = graycomatrix(q, [1], [0, np.pi / 2], levels=32, symmetric=True, normed=True)
    pm = g.mean(axis=(2, 3))
    ent = float(-np.sum(pm * np.log2(pm + 1e-12)))
    return (float(graycoprops(g, "energy").mean()), float(graycoprops(g, "homogeneity").mean()),
            float(graycoprops(g, "contrast").mean()), ent)


def detect_rois(img: np.ndarray, mask: np.ndarray, n_zones=3, radius_frac=0.25, diffusion_iters=15,
                diffusion_kappa=30, tsallis_q=0.8, min_roi_area_px=60, max_rois=25, **_) -> dict:
    """Pipeline completo de la tesis. Devuelve ROIs ordenadas por score y mapas intermedios."""
    enh, zones = enhance_by_zones(img, mask, n_zones, radius_frac, diffusion_iters, diffusion_kappa)
    inner = cv2.erode(mask.astype(np.uint8), np.ones((15, 15), np.uint8)) > 0   # evita la piel
    t = tsallis_threshold(enh, inner, tsallis_q)
    bw = (enh > t) & inner
    bw = cv2.morphologyEx(bw.astype(np.uint8), cv2.MORPH_OPEN, np.ones((3, 3), np.uint8)) > 0
    lab = label(bw)
    bg_mean = float(img[mask].mean()) if mask.any() else 0.0
    H = img.shape[0]
    ys = np.where(mask.any(1))[0]
    ytop, ybot = (ys.min(), ys.max()) if len(ys) else (0, H)
    rois = []
    for rp in regionprops(lab, intensity_image=img):
        if rp.area < min_roi_area_px:
            continue
        y0, x0, y1, x1 = rp.bbox
        per = rp.perimeter or 1.0
        circ = float(min(1.0, 4 * np.pi * rp.area / per ** 2))
        e, h, c, ent = _glcm_feats(img[y0:y1, x0:x1])
        cy, cx = rp.centroid
        z = zones[int(cy), int(cx)]
        rel_y = (cy - ytop) / max(1, ybot - ytop)
        contrast = float(rp.intensity_mean - bg_mean)
        # score heurístico: regiones densas, compactas y de tamaño medio son más sospechosas
        size_term = np.exp(-((np.log(rp.area) - np.log(800)) ** 2) / 4)
        score = float(np.clip(0.45 * np.tanh(contrast / 40) + 0.35 * circ + 0.2 * size_term, 0, 1))
        rois.append(ROI((y0, x0, y1, x1), (float(cy), float(cx)), int(rp.area), circ,
                        float(rp.intensity_mean), contrast, e, h, c, ent,
                        ZONES[z] if 0 <= z < len(ZONES) else f"zona_{z}",
                        "superior" if rel_y < 1 / 3 else "central" if rel_y < 2 / 3 else "inferior", score))
    rois.sort(key=lambda r: r.score, reverse=True)
    return {"threshold": int(t), "rois": rois[:max_rois], "enhanced": enh, "binary": bw, "zones": zones}


def summarize_rois(rois: list[ROI], top_k: int = 3) -> dict:
    """Resumen compacto (JSON-serializable) para el reporte del LLM."""
    if not rois:
        return {"n_rois": 0, "top": []}
    by_zone = {}
    for r in rois:
        by_zone[r.depth_zone] = by_zone.get(r.depth_zone, 0) + 1
    top = [{k: (round(v, 3) if isinstance(v, float) else v) for k, v in r.to_dict().items()
            if k in ("area_px", "circularity", "contrast_vs_bg", "depth_zone", "vertical_region", "score")}
           for r in rois[:top_k]]
    return {"n_rois": len(rois), "rois_por_zona": by_zone, "top": top}


def draw_rois(img: np.ndarray, rois: list[ROI], top_k: int = 10) -> np.ndarray:
    vis = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    for i, r in enumerate(rois[:top_k]):
        y0, x0, y1, x1 = r.bbox
        color = (0, 0, 255) if i < 3 else (0, 200, 0)
        cv2.rectangle(vis, (x0, y0), (x1, y1), color, 2)
        cv2.putText(vis, f"{r.score:.2f}", (x0, max(10, y0 - 3)), cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1)
    return vis
