"""Carga de configuración YAML con variables de entorno y overrides por CLI."""
from __future__ import annotations

import copy
import os
import re
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_CONFIG = ROOT / "configs" / "default.yaml"
_ENV = re.compile(r"\$\{([A-Z0-9_]+):?([^}]*)\}")


def _expand(value: Any) -> Any:
    if isinstance(value, str):
        return _ENV.sub(lambda m: os.environ.get(m.group(1), m.group(2)), value)
    if isinstance(value, dict):
        return {k: _expand(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_expand(v) for v in value]
    return value


class Config(dict):
    """Diccionario con acceso por atributo: cfg.train.epochs."""

    def __getattr__(self, item):
        try:
            v = self[item]
        except KeyError as e:
            raise AttributeError(item) from e
        return Config(v) if isinstance(v, dict) else v

    def set(self, dotted: str, value: Any) -> None:
        node = self
        *parents, last = dotted.split(".")
        for p in parents:
            node = node.setdefault(p, {})
        node[last] = yaml.safe_load(str(value)) if isinstance(value, str) else value

    def path(self, key: str) -> Path:
        p = Path(self["paths"][key])
        return p if p.is_absolute() else ROOT / p


def load_config(path: str | Path | None = None, overrides: list[str] | None = None) -> Config:
    with open(path or DEFAULT_CONFIG, encoding="utf-8") as f:
        cfg = Config(_expand(yaml.safe_load(f)))
    for ov in overrides or []:
        k, v = ov.split("=", 1)
        cfg.set(k, v)
    return Config(copy.deepcopy(cfg))
