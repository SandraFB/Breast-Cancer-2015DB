"""Entrenamiento del clasificador benigno/maligno (+ BI-RADS y densidad).

Ejemplos:
  # 1) preentrenar con CBIS-DDSM
  python -m mamoia.train.train_classifier --source public --out checkpoints/cls_cbis.pt
  # 2) ajuste fino con la base local 2015 etiquetada
  python -m mamoia.train.train_classifier --source local --init checkpoints/cls_cbis.pt \
         --out checkpoints/cls_local.pt --set train.lr=1e-4 --set train.epochs=15
"""
from __future__ import annotations

import argparse
import time
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader, WeightedRandomSampler

from mamoia.config import load_config
from mamoia.data.dataset import MammoDataset
from mamoia.models.classifier import MammoClassifier, multitask_loss
from mamoia.train.common import (best_threshold, binary_metrics, build_dataframe, device,
                                 multiclass_metrics, save_json, seed_everything)


@torch.no_grad()
def predict(model, loader, dev, amp=False):
    model.eval()
    P, YB, LB, YD, LD, Y, ids = [], [], [], [], [], [], []
    for b in loader:
        with torch.autocast(dev.type, enabled=amp and dev.type == "cuda"):
            o = model(b["image"].to(dev))
        P += torch.sigmoid(o["malignancy"].float()).cpu().tolist()
        LB.append(o["birads"].float().cpu().numpy())
        LD.append(o["density"].float().cpu().numpy())
        Y += b["y_malig"].tolist()
        YB += b["y_birads"].tolist()
        YD += b["y_density"].tolist()
        ids += list(b["image_id"])
    return {"p": np.array(P), "y": np.array(Y), "birads_logits": np.concatenate(LB), "y_birads": np.array(YB),
            "density_logits": np.concatenate(LD), "y_density": np.array(YD), "ids": ids}


def evaluate(pred, thr=None):
    thr = thr if thr is not None else (best_threshold(pred["y"][pred["y"] >= 0], pred["p"][pred["y"] >= 0])
                                       if len(np.unique(pred["y"][pred["y"] >= 0])) > 1 else 0.5)
    return {"malignidad": binary_metrics(pred["y"], pred["p"], thr),
            "birads": multiclass_metrics(pred["y_birads"], pred["birads_logits"]),
            "densidad": multiclass_metrics(pred["y_density"], pred["density_logits"])}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--source", default="local", choices=["local", "public", "both", "csv"])
    ap.add_argument("--labels-csv", default=None, help="CSV por imagen (source=csv)")
    ap.add_argument("--n-folds", type=int, default=0, help="validación cruzada por paciente (p.ej. 5)")
    ap.add_argument("--fold", type=int, default=0)
    ap.add_argument("--config", default=None)
    ap.add_argument("--init", default=None, help="checkpoint para ajuste fino")
    ap.add_argument("--out", default="checkpoints/classifier.pt")
    ap.add_argument("--max-public", type=int, default=None)
    ap.add_argument("--set", action="append", default=[], help="override, p.ej. train.epochs=5")
    args = ap.parse_args(argv)
    cfg = load_config(args.config, args.set)
    seed_everything(cfg.train["seed"])
    dev = device()
    C, T = cfg["classifier"], cfg["train"]
    df = build_dataframe(cfg, args.source, args.max_public, args.labels_csv, args.n_folds, args.fold)
    print(df.groupby("split").agg(n=("image_id", "size"), malignos=("y_malig", lambda s: int((s == 1).sum())),
                                  benignos=("y_malig", lambda s: int((s == 0).sum()))))
    if "label_source" in df:
        print("Fuente de la etiqueta:", df.label_source.value_counts().to_dict())
    cache = str(Path(cfg.path("processed")) / "cache")
    tr, va = df[df.split == "train"], df[df.split == "val"]
    ds_tr = MammoDataset(tr, C["img_size"], train=True, cache_dir=cache, seed=T["seed"])
    ds_va = MammoDataset(va, C["img_size"], cache_dir=cache)
    # muestreo balanceado: los malignos suelen ser minoría
    yv = tr.y_malig.values
    w = np.where(yv == 1, 0.5 / max(1, (yv == 1).sum()), np.where(yv == 0, 0.5 / max(1, (yv == 0).sum()), 0.1 / len(yv)))
    sampler = WeightedRandomSampler(torch.tensor(w, dtype=torch.double), len(tr), replacement=True)
    dl_tr = DataLoader(ds_tr, T["batch_size"], sampler=sampler, num_workers=T["num_workers"], drop_last=len(tr) > T["batch_size"])
    dl_va = DataLoader(ds_va, T["batch_size"], num_workers=T["num_workers"])

    model_args = dict(backbone=C["backbone"], pretrained=C["pretrained"], n_birads=C["n_birads"],
                      n_density=C["n_density"], dropout=C["dropout"])
    model = MammoClassifier(**model_args).to(dev)
    if args.init:
        sd = torch.load(args.init, map_location=dev, weights_only=False)["state_dict"]
        print("init:", model.load_state_dict(sd, strict=False))
    opt = torch.optim.AdamW(model.parameters(), lr=T["lr"], weight_decay=T["weight_decay"])
    total = T["epochs"] * max(1, len(dl_tr))
    warm = max(1, int(0.05 * total))
    sched = torch.optim.lr_scheduler.LambdaLR(  # calentamiento lineal + coseno
        opt, lambda s: (s + 1) / warm if s < warm else 0.5 * (1 + np.cos(np.pi * min(1.0, (s - warm) / max(1, total - warm)))))
    use_amp = T["amp"] and dev.type == "cuda"
    scaler = torch.amp.GradScaler("cuda", enabled=use_amp)
    best, history, patience = -1, [], 0
    for ep in range(T["epochs"]):
        model.train()
        t0, run = time.time(), []
        for b in dl_tr:
            with torch.autocast(dev.type, enabled=use_amp):
                o = model(b["image"].to(dev))
                loss, parts = multitask_loss(o, b, T["loss_weights"])
            opt.zero_grad(set_to_none=True)
            scaler.scale(loss).backward()
            scaler.unscale_(opt)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 2.0)
            scaler.step(opt)
            scaler.update()
            sched.step()
            run.append(loss.item())
        pv = predict(model, dl_va, dev, use_amp)
        mv = evaluate(pv)
        # criterio de selección: AUC de malignidad; si no existe, exactitud BI-RADS
        auc = mv["malignidad"].get("auc") or (mv["birads"] or {}).get("accuracy") or 0.0
        history.append({"epoch": ep + 1, "loss": float(np.mean(run)), "val": mv})
        print(f"ép {ep + 1:02d} | loss {np.mean(run):.4f} | val AUC {mv['malignidad'].get('auc', float('nan')):.3f} "
              f"| sens {mv['malignidad'].get('sensibilidad', float('nan')):.2f} | {time.time() - t0:.0f}s")
        if auc > best:
            best, patience = auc, 0
            Path(args.out).parent.mkdir(parents=True, exist_ok=True)
            torch.save({"state_dict": model.state_dict(), "model_args": model_args, "img_size": C["img_size"],
                        "threshold": mv["malignidad"].get("threshold", 0.5), "val_metrics": mv,
                        "source": args.source, "epoch": ep + 1}, args.out)
        else:
            patience += 1
            if patience >= 6:
                print("early stopping")
                break
    save_json(history, Path(args.out).with_suffix(".history.json"))
    # evaluación final en test con el mejor modelo y su umbral de validación
    ck = torch.load(args.out, map_location=dev, weights_only=False)
    model.load_state_dict(ck["state_dict"])
    te = df[df.split == "test"]
    if len(te):
        pt = predict(model, DataLoader(MammoDataset(te, C["img_size"], cache_dir=cache), T["batch_size"]), dev, use_amp)
        mt = evaluate(pt, ck["threshold"])
        save_json(mt, Path(args.out).with_suffix(".test.json"))
        # predicciones fuera de muestra (para agregar por mama/paciente y juntar los folds)
        oof = te[[c for c in ("image_id", "patient_id", "breast_id", "laterality", "projection", "group_id",
                              "label_source") if c in te]].copy()
        oof["p_malig"], oof["y_malig"] = pt["p"], pt["y"]
        oof["y_birads"], oof["birads_pred"] = pt["y_birads"], pt["birads_logits"].argmax(1)
        oof["y_density"], oof["density_pred"] = pt["y_density"], pt["density_logits"].argmax(1)
        oof["threshold"], oof["fold"] = ck["threshold"], args.fold
        oof.to_csv(Path(args.out).with_suffix(".oof.csv"), index=False)
        print("TEST:", mt["malignidad"])
    print(f"mejor checkpoint -> {args.out}")


if __name__ == "__main__":
    main()
