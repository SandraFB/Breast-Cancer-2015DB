"""Utilidades compartidas de entrenamiento: semillas, datos, métricas."""
from __future__ import annotations

import json
import random
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import (cohen_kappa_score, confusion_matrix, f1_score, roc_auc_score,
                             roc_curve)

from mamoia.data.labels import kfold_split, load_local_labels, split_by_group
from mamoia.data.public_datasets import load_cbis_ddsm


def seed_everything(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def device():
    return torch.device("cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu")


def build_dataframe(cfg, source: str = "local", max_public: int | None = None, labels_csv: str | None = None,
                    n_folds: int = 0, fold: int = 0) -> pd.DataFrame:
    """source: local | public | both | csv. Devuelve df con columna `split`.
    csv: un CSV por imagen ya etiquetado (p.ej. DICOM + reportes) con img_path, group_id, y_*.
    n_folds > 1 activa la validación cruzada por paciente (fold = partición de test)."""
    if source == "csv":
        df = pd.read_csv(labels_csv, dtype={"group_id": str, "patient_id": str})
        df = df[(df.y_malig >= 0) | (df.y_birads >= 0) | (df.y_density >= 0)].reset_index(drop=True)
        if n_folds > 1:
            return kfold_split(df, n_folds, fold, cfg.train["val_frac"], cfg.train["seed"])
        return split_by_group(df, cfg.train["val_frac"], cfg.train["test_frac"], cfg.train["seed"])
    dfs = []
    if source in ("local", "both"):
        local = load_local_labels(cfg.path("labels_csv"), cfg.path("processed"))
        local = local[(local.y_malig >= 0) | (local.y_birads >= 0) | (local.y_density >= 0)]
        if len(local):
            dfs.append(split_by_group(local, cfg.train["val_frac"], cfg.train["test_frac"], cfg.train["seed"]))
    if source in ("public", "both"):
        pub = load_cbis_ddsm(cfg.path("public_root"), max_public)
        # respeta el split oficial de test; el train oficial se divide en train/val por paciente
        test = pub[pub.official_split == "test"].assign(split="test")
        tr = split_by_group(pub[pub.official_split == "train"], cfg.train["val_frac"], 0.0001, cfg.train["seed"])
        tr.loc[tr.split == "test", "split"] = "train"
        dfs.append(pd.concat([tr, test]))
    if not dfs:
        raise ValueError("No hay imágenes etiquetadas. Llenen data/labels/labels.csv o usen --source public.")
    df = pd.concat(dfs, ignore_index=True)
    return df


def best_threshold(y, p):
    """Umbral de Youden (max sensibilidad + especificidad - 1)."""
    fpr, tpr, thr = roc_curve(y, p)
    return float(thr[np.argmax(tpr - fpr)])


def binary_metrics(y, p, thr=0.5) -> dict:
    y, p = np.asarray(y), np.asarray(p)
    m = y >= 0
    y, p = y[m], p[m]
    if len(np.unique(y)) < 2:
        return {"n": int(len(y)), "nota": "una sola clase en este conjunto"}
    pred = (p >= thr).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    return {"n": int(len(y)), "auc": float(roc_auc_score(y, p)), "threshold": float(thr),
            "sensibilidad": float(tp / max(1, tp + fn)), "especificidad": float(tn / max(1, tn + fp)),
            "vpp": float(tp / max(1, tp + fp)), "vpn": float(tn / max(1, tn + fn)),
            "f1": float(f1_score(y, pred)), "tp": int(tp), "fp": int(fp), "tn": int(tn), "fn": int(fn)}


def multiclass_metrics(y, logits) -> dict:
    y = np.asarray(y)
    m = y >= 0
    if m.sum() == 0:
        return {}
    pred = np.asarray(logits)[m].argmax(1)
    return {"n": int(m.sum()), "accuracy": float((pred == y[m]).mean()),
            "kappa_ponderado": float(cohen_kappa_score(y[m], pred, weights="quadratic"))
            if len(np.unique(y[m])) > 1 else None}


def save_json(obj, path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(obj, indent=2, ensure_ascii=False, default=str))
