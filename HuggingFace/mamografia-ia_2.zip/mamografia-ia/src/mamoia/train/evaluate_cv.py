"""Evaluación de la validación cruzada: junta las predicciones fuera de muestra (*.oof.csv) de todos
los folds y reporta métricas a nivel IMAGEN, MAMA y PACIENTE con IC 95 % por bootstrap de pacientes.

  python -m mamoia.train.evaluate_cv "checkpoints/cv/fold*.oof.csv" --out outputs/cv
"""
from __future__ import annotations

import argparse
import glob
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score, roc_curve

from mamoia.train.common import binary_metrics, save_json


def aggregate(oof: pd.DataFrame, level: str, how: str = "mean") -> pd.DataFrame:
    """level: image | breast | patient. La probabilidad de la mama = promedio (o máx.) de CC y MLO;
    la de la paciente = máximo de sus dos mamas (basta una mama sospechosa)."""
    d = oof[oof.y_malig >= 0]
    if level == "image":
        return d.assign(unit=d.image_id)
    if level == "breast":
        g = d.groupby("breast_id").agg(p_malig=("p_malig", how), y_malig=("y_malig", "max"),
                                       patient_id=("patient_id", "first"), fold=("fold", "first"))
        return g.reset_index().rename(columns={"breast_id": "unit"})
    b = aggregate(oof, "breast", how)
    g = b.groupby("patient_id").agg(p_malig=("p_malig", "max"), y_malig=("y_malig", "max"), fold=("fold", "first"))
    return g.reset_index().assign(unit=lambda x: x.patient_id)


def bootstrap_auc(df: pd.DataFrame, n=2000, seed=0) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    pats = df.patient_id.unique()
    idx = {p: np.where(df.patient_id.values == p)[0] for p in pats}
    aucs = []
    for _ in range(n):
        sel = np.concatenate([idx[p] for p in rng.choice(pats, len(pats), replace=True)])
        y, p = df.y_malig.values[sel], df.p_malig.values[sel]
        if len(np.unique(y)) == 2:
            aucs.append(roc_auc_score(y, p))
    return float(np.percentile(aucs, 2.5)), float(np.percentile(aucs, 97.5))


def sens_at_spec(y, p, spec=0.8):
    fpr, tpr, _ = roc_curve(y, p)
    return float(np.interp(1 - spec, fpr, tpr))


def evaluate_oof(oof: pd.DataFrame, out_dir: str | Path | None = None) -> dict:
    res = {}
    curves = {}
    for level in ("image", "breast", "patient"):
        d = aggregate(oof, level)
        if d.y_malig.nunique() < 2:
            res[level] = {"nota": "una sola clase"}
            continue
        thr = float(oof.threshold.median()) if "threshold" in oof else 0.5
        m = binary_metrics(d.y_malig, d.p_malig, thr)
        m["auc_ic95"] = bootstrap_auc(d)
        m["sens_a_esp_0.80"] = sens_at_spec(d.y_malig, d.p_malig, 0.8)
        m["auc_por_fold"] = {int(f): float(roc_auc_score(g.y_malig, g.p_malig))
                             for f, g in d.groupby("fold") if g.y_malig.nunique() == 2}
        res[level] = m
        curves[level] = roc_curve(d.y_malig, d.p_malig)[:2]
    if out_dir:
        out = Path(out_dir)
        out.mkdir(parents=True, exist_ok=True)
        save_json(res, out / "metricas_cv.json")
        try:
            import matplotlib
            matplotlib.use("Agg")
            import matplotlib.pyplot as plt
            fig, ax = plt.subplots(figsize=(5, 5))
            for lvl, (fpr, tpr) in curves.items():
                ax.plot(fpr, tpr, label=f"{lvl} AUC={res[lvl]['auc']:.2f} {np.round(res[lvl]['auc_ic95'], 2)}")
            ax.plot([0, 1], [0, 1], "--", color="gray")
            ax.set_xlabel("1 - especificidad")
            ax.set_ylabel("sensibilidad")
            ax.legend(fontsize=8)
            ax.set_title("ROC fuera de muestra (validación cruzada)")
            fig.tight_layout()
            fig.savefig(out / "roc_cv.png", dpi=150)
            plt.close(fig)
        except Exception as e:  # noqa: BLE001
            print("sin gráfica:", e)
    return res


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("pattern")
    ap.add_argument("--out", default="outputs/cv")
    a = ap.parse_args()
    oof = pd.concat([pd.read_csv(f) for f in sorted(glob.glob(a.pattern))], ignore_index=True)
    res = evaluate_oof(oof, a.out)
    for lvl, m in res.items():
        print(lvl, {k: (round(v, 3) if isinstance(v, float) else v) for k, v in m.items() if k in
                    ("n", "auc", "auc_ic95", "sensibilidad", "especificidad", "sens_a_esp_0.80")})


if __name__ == "__main__":
    main()
