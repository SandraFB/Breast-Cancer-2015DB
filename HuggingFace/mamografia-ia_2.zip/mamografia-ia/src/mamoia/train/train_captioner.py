"""Entrenamiento del captioner CNN-LSTM (descripción textual de la mamografía).

Requiere un clasificador ya entrenado (su backbone es el encoder visual).
  python -m mamoia.train.train_captioner --classifier checkpoints/cls_local.pt \
         --source local --out checkpoints/captioner.pt
"""
from __future__ import annotations

import argparse
import math
import re
import time
from collections import Counter
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

from mamoia.config import load_config
from mamoia.data.dataset import CaptionDataset
from mamoia.models.captioner import LSTMCaptioner
from mamoia.models.classifier import load_classifier
from mamoia.text.report_templates import describe
from mamoia.text.vocab import Vocab, tokenize
from mamoia.train.common import build_dataframe, device, save_json, seed_everything


def bleu(refs: list[str], hyps: list[str], n_max=4) -> dict:
    """BLEU de corpus (Papineni 2002) sin dependencias externas."""
    out = {}
    R = [tokenize(r) for r in refs]
    H = [tokenize(h) for h in hyps]
    rl, hl = sum(map(len, R)), sum(map(len, H))
    bp = 1.0 if hl > rl else math.exp(1 - rl / max(1, hl))
    logs = []
    for n in range(1, n_max + 1):
        match = total = 0
        for r, h in zip(R, H):
            rc = Counter(tuple(r[i:i + n]) for i in range(len(r) - n + 1))
            hc = Counter(tuple(h[i:i + n]) for i in range(len(h) - n + 1))
            match += sum(min(c, rc[g]) for g, c in hc.items())
            total += max(0, len(h) - n + 1)
        logs.append(math.log(max(match, 1e-9) / max(total, 1)))
        out[f"bleu{n}"] = bp * math.exp(sum(logs) / n)
    return out


def clinical_agreement(refs, hyps) -> dict:
    """¿El texto generado conserva la categoría BI-RADS y el tipo de lesión de la referencia?"""
    def birads(s):
        m = re.search(r"bi-?rads\s*(\d)", s.lower())
        return m.group(1) if m else None

    def lesion(s):
        s = s.lower()
        for k in ("masa", "asimetría", "microcalcificaciones", "distorsión", "sin masas", "no se observan"):
            if k in s:
                return k
        return None
    pairs_b = [(birads(r), birads(h)) for r, h in zip(refs, hyps) if birads(r)]
    pairs_l = [(lesion(r), lesion(h)) for r, h in zip(refs, hyps) if lesion(r)]
    return {"birads_coincide": float(np.mean([a == b for a, b in pairs_b])) if pairs_b else None,
            "lesion_coincide": float(np.mean([a == b for a, b in pairs_l])) if pairs_l else None}


@torch.no_grad()
def generate_all(model, loader, vocab, dev, max_len, beam=1):
    model.eval()
    refs, hyps = [], []
    for b in loader:
        x = b["image"].to(dev)
        for i in range(x.size(0)):
            seqs, _, _, _ = model.generate(x[i:i + 1], vocab.bos, vocab.eos, max_len, beam)
            hyps.append(vocab.decode(seqs[0]))
        refs += list(b["reference"])
    return refs, hyps


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--classifier", required=True)
    ap.add_argument("--source", default="local", choices=["local", "public", "both", "csv"])
    ap.add_argument("--labels-csv", default=None)
    ap.add_argument("--n-folds", type=int, default=0)
    ap.add_argument("--fold", type=int, default=0)
    ap.add_argument("--config", default=None)
    ap.add_argument("--out", default="checkpoints/captioner.pt")
    ap.add_argument("--max-public", type=int, default=None)
    ap.add_argument("--set", action="append", default=[])
    args = ap.parse_args(argv)
    cfg = load_config(args.config, args.set)
    seed_everything(cfg.train["seed"])
    dev = device()
    K = cfg["captioner"]
    cls, ck = load_classifier(args.classifier, dev)
    img_size = ck["img_size"]
    df = build_dataframe(cfg, args.source, args.max_public, args.labels_csv, args.n_folds, args.fold)
    # vocabulario con referencias + paráfrasis para cubrir todas las variantes
    import random
    rng = random.Random(0)
    texts = [describe(r, include_view=False) for r in df.to_dict("records")] + \
            [describe(r, variant=True, rng=rng, include_view=False) for r in df.to_dict("records") for _ in range(4)]
    vocab = Vocab.build(texts, K["min_word_freq"])
    print(f"vocabulario: {len(vocab)} palabras | ejemplo: {texts[0]}")
    cache = str(Path(cfg.path("processed")) / "cache")
    mk = lambda d, tr: CaptionDataset(d, vocab, K["max_len"], img_size=img_size, train=tr, cache_dir=cache)  # noqa: E731
    dl_tr = DataLoader(mk(df[df.split == "train"], True), K["batch_size"], shuffle=True, num_workers=cfg.train["num_workers"])
    dl_va = DataLoader(mk(df[df.split == "val"], False), K["batch_size"], num_workers=cfg.train["num_workers"])
    model = LSTMCaptioner(cls, cls.n_features, len(vocab), cond_dim=1 + cls.head_birads.out_features + cls.head_density.out_features,
                          embed_dim=K["embed_dim"], hidden_dim=K["hidden_dim"], attn_dim=K["attn_dim"],
                          freeze_encoder=K["freeze_encoder"]).to(dev)
    params = [p for p in model.parameters() if p.requires_grad]
    opt = torch.optim.AdamW(params, lr=K["lr"], weight_decay=1e-5)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, K["epochs"])
    best, hist = -1.0, []
    for ep in range(K["epochs"]):
        model.train()
        if K["freeze_encoder"]:
            model.encoder.eval()
        t0, run = time.time(), []
        for b in dl_tr:
            tok = b["tokens"].to(dev)
            logits, alphas = model(b["image"].to(dev), tok)
            loss = LSTMCaptioner.loss(logits, tok, alphas, vocab.pad)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(params, 5.0)
            opt.step()
            run.append(loss.item())
        sched.step()
        refs, hyps = generate_all(model, dl_va, vocab, dev, K["max_len"])
        m = {**bleu(refs, hyps), **clinical_agreement(refs, hyps)}
        hist.append({"epoch": ep + 1, "loss": float(np.mean(run)), **m})
        print(f"ép {ep + 1:02d} | loss {np.mean(run):.3f} | BLEU-4 {m['bleu4']:.3f} | BI-RADS ok {m['birads_coincide']} "
              f"| {time.time() - t0:.0f}s\n   ref: {refs[0] if refs else ''}\n   gen: {hyps[0] if hyps else ''}")
        score = m["bleu4"] + (m["birads_coincide"] or 0)
        if score > best:
            best = score
            Path(args.out).parent.mkdir(parents=True, exist_ok=True)
            sd = {k: v for k, v in model.state_dict().items() if not (K["freeze_encoder"] and k.startswith("encoder."))}
            torch.save({"state_dict": sd, "vocab": vocab.itos, "classifier_ckpt": str(args.classifier),
                        "args": dict(embed_dim=K["embed_dim"], hidden_dim=K["hidden_dim"], attn_dim=K["attn_dim"]),
                        "max_len": K["max_len"], "val_metrics": m, "epoch": ep + 1}, args.out)
    save_json(hist, Path(args.out).with_suffix(".history.json"))
    print(f"mejor checkpoint -> {args.out}")


if __name__ == "__main__":
    main()
