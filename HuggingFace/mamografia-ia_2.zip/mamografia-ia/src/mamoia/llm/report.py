"""Construye los hallazgos estructurados, llama al LLM y VALIDA su salida."""
from __future__ import annotations

from mamoia.llm.backends import TemplateBackend, get_backend
from mamoia.llm.recommendations import recommendations, suggest_birads

DENS = "ABCD"
DISCLAIMER = ("BORRADOR GENERADO POR IA CON FINES DOCENTES Y DE INVESTIGACIÓN. No constituye un diagnóstico; "
              "debe ser revisado y firmado por un médico radiólogo.")


def build_findings(analysis: dict, thresholds: dict) -> dict:
    cls = analysis.get("clasificador") or {}
    p = cls.get("prob_malignidad")
    sug = suggest_birads(p, cls.get("prob_birads"), thresholds["malignancy_high"], thresholds["malignancy_low"])
    dens = cls.get("prob_densidad")
    f = {
        "lateralidad": analysis.get("laterality"),
        "proyeccion": analysis.get("projection"),
        "prob_malignidad": None if p is None else round(p, 3),
        "umbral_operativo": thresholds["malignancy_high"],
        "birads_cabeza": sug.get("birads_cabeza"),
        "birads_sugerido": sug["birads"],
        "razon_birads": sug["razon"],
        "densidad_predicha": DENS[max(range(4), key=lambda i: dens[i])] if dens else None,
        "descripcion_lstm": analysis.get("caption_lstm"),
        "localizacion_ia": analysis.get("localizacion"),
        "cade_clasico": analysis.get("cade_clasico"),
        "calidad": {"advertencias": analysis.get("preprocess", {}).get("warnings", [])},
        "modelo": analysis.get("model_version"),
    }
    f["recomendaciones"] = recommendations(f)
    return f


def validate(report: dict, findings: dict) -> tuple[dict, list[str]]:
    """Corrige y marca cualquier contradicción del LLM con las reglas."""
    issues = []
    req = ["hallazgos", "impresion", "birads_sugerido", "recomendaciones", "nivel_confianza", "limitaciones"]
    for k in req:
        if k not in report:
            issues.append(f"falta_{k}")
    if findings.get("birads_sugerido") is not None and report.get("birads_sugerido") != findings["birads_sugerido"]:
        issues.append(f"llm_cambio_birads_{report.get('birads_sugerido')}->{findings['birads_sugerido']}")
        report["birads_sugerido"] = findings["birads_sugerido"]
    if not isinstance(report.get("recomendaciones"), list) or not report["recomendaciones"]:
        report["recomendaciones"] = findings["recomendaciones"]
        issues.append("recomendaciones_reemplazadas_por_reglas")
    return report, issues


def to_markdown(r: dict) -> str:
    recs = "\n".join(f"- {x}" for x in r.get("recomendaciones", []))
    return (f"### Hallazgos\n{r.get('hallazgos', '')}\n\n### Impresión\n{r.get('impresion', '')}\n\n"
            f"**Categoría BI-RADS sugerida:** {r.get('birads_sugerido')}  ·  **Confianza del modelo:** "
            f"{r.get('nivel_confianza')}\n\n### Recomendaciones para el radiólogo\n{recs}\n\n"
            f"### Limitaciones\n{r.get('limitaciones', '')}\n\n> {DISCLAIMER}")


def write_report(analysis: dict, cfg: dict, backend: str | None = None) -> dict:
    findings = build_findings(analysis, cfg["thresholds"])
    name = backend or cfg["llm"]["backend"]
    used = name
    try:
        report = get_backend(name, cfg["llm"]).generate(findings)
    except Exception as e:  # sin red, sin clave o JSON inválido -> plantilla
        report = TemplateBackend().generate(findings)
        used = f"template (fallback: {type(e).__name__}: {str(e)[:120]})"
    report, issues = validate(report, findings)
    return {"findings": findings, "report": report, "markdown": to_markdown(report),
            "llm_backend": used, "validation_issues": issues, "disclaimer": DISCLAIMER}


def build_study_findings(breasts: dict, thresholds: dict) -> dict:
    """Hallazgos de un estudio bilateral: una entrada por mama + categoría global (la más alta)."""
    side_name = {"L": "izquierda", "R": "derecha"}
    mamas = {side_name[k]: build_findings(v, thresholds) for k, v in breasts.items()}
    cats = {k: v["birads_sugerido"] for k, v in mamas.items() if v["birads_sugerido"] is not None}
    worst = max(cats, key=cats.get) if cats else None
    dens = [v["densidad_predicha"] for v in mamas.values() if v["densidad_predicha"]]
    recs = []
    if worst:
        recs = [f"Mama {worst}: {r}" if i == 0 else r for i, r in enumerate(mamas[worst]["recomendaciones"])]
    for k, v in mamas.items():
        v.pop("recomendaciones", None)
    return {"tipo": "estudio_bilateral", "mamas": mamas, "birads_sugerido": cats.get(worst) if worst else None,
            "mama_de_mayor_sospecha": worst, "densidad_predicha": max(dens) if dens else None,
            "recomendaciones": recs}


def write_study_report(breasts: dict, cfg: dict, backend: str | None = None) -> dict:
    findings = build_study_findings(breasts, cfg["thresholds"])
    name = backend or cfg["llm"]["backend"]
    used = name
    try:
        report = get_backend(name, cfg["llm"]).generate(findings)
    except Exception as e:  # noqa: BLE001
        report = TemplateBackend().generate(findings)
        used = f"template (fallback: {type(e).__name__}: {str(e)[:120]})"
    report, issues = validate(report, findings)
    return {"findings": findings, "report": report, "markdown": to_markdown(report),
            "llm_backend": used, "validation_issues": issues, "disclaimer": DISCLAIMER}
