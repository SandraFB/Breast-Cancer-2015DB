"""Uso del LLM para PLN clínico sobre los reportes (texto ya anonimizado):

  1. extract_fields(): extracción estructurada (mismo esquema que el extractor por reglas), para
     comparar ambos métodos y revisar discrepancias con el radiólogo.
  2. summarize_breast(): resumen breve por mama (≤ 40 palabras, léxico BI-RADS) que sirve como texto
     objetivo REAL para entrenar el captioner CNN-LSTM (destilación reporte → descripción corta).

Backends: claude | ollama (mismo mecanismo que llm/backends.py). Sin LLM disponible, se usan las reglas.
"""
from __future__ import annotations

import json

from mamoia.llm.backends import _extract_json

EXTRACT_SYSTEM = """Eres un asistente de radiología mamaria. Lee un reporte de mastografía en español y
extrae datos SIN inventar. Si un dato no aparece, usa null. Responde SOLO un JSON con las claves:
{"birads": int|null, "birads_sub": "4a"|"4b"|"4c"|null, "density": "A"|"B"|"C"|"D"|null,
 "lesion_laterality": "L"|"R"|"B"|"U", "lesion_type": "masa"|"microcalcificaciones"|"asimetria"|"distorsion"|"ninguna",
 "lesion_quadrant": "CSE"|"CSI"|"CIE"|"CII"|"retroareolar"|"axilar"|"UCS"|"UCE"|null,
 "lesion_size_mm": number|null, "lesion_margin": "circunscrito"|"oscurecido"|"microlobulado"|"indistinto"|"espiculado"|null,
 "biopsy_result": "maligno"|"benigno"|"pendiente"|null, "palpable": bool, "prior_cancer_or_mastectomy": bool}
L = mama izquierda, R = derecha, B = ambas, U = no se puede determinar. La lateralidad se refiere al
hallazgo que motiva la categoría BI-RADS más alta."""

SUMMARY_SYSTEM = """Eres un radiólogo que resume reportes de mastografía. Para la mama indicada escribe UNA
descripción de máximo 40 palabras, en español, con léxico BI-RADS: densidad, hallazgo principal (tipo,
forma/márgenes, cuadrante, tamaño) y categoría. Si esa mama no tiene hallazgos sospechosos, escribe
"Sin hallazgos sospechosos en esta mama." No inventes datos. Responde SOLO {"resumen": "..."}"""


def _chat(system: str, user: str, backend: str, cfg_llm: dict | None = None) -> dict:
    cfg_llm = cfg_llm or {}
    if backend == "claude":
        import os

        import anthropic
        client = anthropic.Anthropic()
        msg = client.messages.create(model=cfg_llm.get("claude_model") or os.environ.get("CLAUDE_MODEL", "claude-sonnet-5-5"),
                                     max_tokens=600, system=system, messages=[{"role": "user", "content": user}])
        return _extract_json("".join(b.text for b in msg.content if getattr(b, "type", "") == "text"))
    if backend == "ollama":
        import os

        import httpx
        host = (cfg_llm.get("ollama_host") or os.environ.get("OLLAMA_HOST", "http://localhost:11434")).rstrip("/")
        r = httpx.post(f"{host}/api/chat", timeout=180, json={
            "model": cfg_llm.get("ollama_model") or os.environ.get("OLLAMA_MODEL", "qwen2.5:7b-instruct"),
            "stream": False, "format": "json", "options": {"temperature": 0},
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]})
        r.raise_for_status()
        return _extract_json(r.json()["message"]["content"])
    raise ValueError(backend)


def extract_fields(report_anon: str, backend="claude", cfg_llm=None) -> dict:
    return _chat(EXTRACT_SYSTEM, f"REPORTE:\n{report_anon}", backend, cfg_llm)


def summarize_breast(report_anon: str, side: str, backend="claude", cfg_llm=None) -> str:
    lado = {"L": "IZQUIERDA", "R": "DERECHA"}[side]
    out = _chat(SUMMARY_SYSTEM, f"Mama: {lado}\nREPORTE:\n{report_anon}", backend, cfg_llm)
    return str(out.get("resumen", "")).strip()


def compare(rules, llm, fields=("birads", "density", "lesion_laterality", "lesion_type", "lesion_quadrant",
                                "biopsy_result")) -> dict:
    """Concordancia reglas vs. LLM por campo (sobre pacientes con ambos valores no nulos)."""
    import pandas as pd
    m = rules.merge(llm, on="patient_id", suffixes=("_reglas", "_llm"))
    out = {}
    for f in fields:
        a, b = m[f"{f}_reglas"].astype(str), m[f"{f}_llm"].astype(str)
        ok = ~a.isin(["None", "nan"]) & ~b.isin(["None", "nan"])
        out[f] = {"n": int(ok.sum()), "concordancia": float((a[ok] == b[ok]).mean()) if ok.any() else None}
    return out


def cache_json(path, fn, *args, **kw):
    """Llama fn sólo si no existe el resultado en disco (evita pagar dos veces la API)."""
    from pathlib import Path
    p = Path(path)
    if p.exists():
        return json.loads(p.read_text())
    res = fn(*args, **kw)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(res, ensure_ascii=False))
    return res
