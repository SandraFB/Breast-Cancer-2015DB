"""Backends intercambiables para redactar el reporte.

  template : sin LLM, reglas + plantillas (gratis, determinista; ideal para pruebas)
  claude   : API de Anthropic (variable ANTHROPIC_API_KEY; modelo en CLAUDE_MODEL)
  ollama   : modelo abierto local o en servidor propio (OLLAMA_HOST, OLLAMA_MODEL)
"""
from __future__ import annotations

import json
import os
import re

import httpx

from mamoia.llm.prompts import SYSTEM_PROMPT, USER_TEMPLATE


def _extract_json(text: str) -> dict:
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        raise ValueError("La respuesta del LLM no contiene JSON")
    return json.loads(m.group(0))


class TemplateBackend:
    name = "template"

    def generate(self, findings: dict) -> dict:
        if "mamas" in findings:                       # estudio bilateral
            partes, conf = [], "moderado"
            for lado, f in findings["mamas"].items():
                sub = self.generate({**f, "recomendaciones": []})
                partes.append(f"**Mama {lado}.** {sub['hallazgos']}")
            b = findings.get("birads_sugerido")
            worst = findings.get("mama_de_mayor_sospecha")
            return {"hallazgos": "\n\n".join(partes),
                    "impresion": f"Estudio bilateral: categoría sugerida BI-RADS {b}, a expensas de la mama {worst} "
                                 "(borrador generado por IA)." if b is not None else "Sin categoría sugerida.",
                    "birads_sugerido": b, "recomendaciones": findings.get("recomendaciones", []),
                    "nivel_confianza": conf,
                    "limitaciones": "Modelo experimental con fines docentes; requiere validación por radiólogo."}
        p = findings.get("prob_malignidad")
        b = findings.get("birads_sugerido")
        lat = {"L": "izquierda", "R": "derecha"}.get(findings.get("lateralidad"), "")
        partes = []
        vista = " ".join(x for x in (findings.get("proyeccion"), f"mama {lat}" if lat else "") if x)
        if vista:
            partes.append(f"Proyección {vista}.")
        if findings.get("descripcion_lstm"):
            partes.append(f"Descripción automática (LSTM): {findings['descripcion_lstm']}")
        if p is not None:
            partes.append(f"El clasificador estima una probabilidad de malignidad de {p:.0%}.")
        loc = findings.get("localizacion_ia")
        if loc:
            tercio = {"media": "medio"}.get(loc["depth_zone"], loc["depth_zone"])
            partes.append(f"La mayor activación del modelo se ubica en el tercio {tercio}, "
                          f"región {loc['vertical_region']} de la imagen.")
        roi = findings.get("cade_clasico") or {}
        if roi.get("n_rois"):
            partes.append(f"El CADe clásico (tesis 2015) marcó {roi['n_rois']} regiones candidatas.")
        conf = "alto" if p is not None and (p > 0.85 or p < 0.05) else "moderado" if p is not None else "bajo"
        return {
            "hallazgos": " ".join(partes) or "Sin hallazgos estructurados.",
            "impresion": f"Mama {lat}: categoría sugerida BI-RADS {b} (borrador generado por IA)." if b is not None
            else "Sin categoría sugerida.",
            "birads_sugerido": b,
            "recomendaciones": findings.get("recomendaciones", []),
            "nivel_confianza": conf,
            "limitaciones": "Modelo experimental con fines docentes; requiere validación por radiólogo.",
        }


class ClaudeBackend:
    name = "claude"

    def __init__(self, model: str | None = None, temperature=0.2, max_tokens=900):
        import anthropic  # pip install anthropic
        self.client = anthropic.Anthropic()        # lee ANTHROPIC_API_KEY
        self.model = model or os.environ.get("CLAUDE_MODEL", "claude-sonnet-5-5")
        self.temperature, self.max_tokens = temperature, max_tokens

    def generate(self, findings: dict) -> dict:
        msg = self.client.messages.create(
            model=self.model, max_tokens=self.max_tokens, system=SYSTEM_PROMPT,   # SDK >= 1.x: sin `temperature`
            messages=[{"role": "user", "content": USER_TEMPLATE.format(
                findings_json=json.dumps(findings, ensure_ascii=False, indent=1))}])
        return _extract_json("".join(b.text for b in msg.content if getattr(b, "type", "") == "text"))


class OllamaBackend:
    name = "ollama"

    def __init__(self, model: str | None = None, host: str | None = None, temperature=0.2, max_tokens=900):
        self.model = model or os.environ.get("OLLAMA_MODEL", "qwen2.5:7b-instruct")
        self.host = (host or os.environ.get("OLLAMA_HOST", "http://localhost:11434")).rstrip("/")
        self.temperature, self.max_tokens = temperature, max_tokens

    def generate(self, findings: dict) -> dict:
        r = httpx.post(f"{self.host}/api/chat", timeout=180, json={
            "model": self.model, "stream": False, "format": "json",
            "options": {"temperature": self.temperature, "num_predict": self.max_tokens},
            "messages": [{"role": "system", "content": SYSTEM_PROMPT},
                         {"role": "user", "content": USER_TEMPLATE.format(
                             findings_json=json.dumps(findings, ensure_ascii=False, indent=1))}]})
        r.raise_for_status()
        return _extract_json(r.json()["message"]["content"])


def get_backend(name: str, cfg_llm: dict | None = None):
    c = cfg_llm or {}
    if name == "claude":
        return ClaudeBackend(c.get("claude_model"), c.get("temperature", 0.2), c.get("max_tokens", 900))
    if name == "ollama":
        return OllamaBackend(c.get("ollama_model"), c.get("ollama_host"), c.get("temperature", 0.2), c.get("max_tokens", 900))
    return TemplateBackend()
