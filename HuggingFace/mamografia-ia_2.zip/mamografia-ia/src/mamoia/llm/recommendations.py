"""Reglas DETERMINISTAS de categoría y recomendación (ACR BI-RADS 5.ª ed. y NOM-041-SSA2-2011).

Principio de diseño: el LLM NO decide la conducta clínica. La categoría sugerida y la
recomendación se calculan aquí con reglas auditables; el LLM sólo redacta. Así se puede
verificar (y calificar) que el texto final no contradiga a las reglas.
"""
from __future__ import annotations

MANEJO = {
    0: "Evaluación de imagen adicional (proyecciones complementarias, magnificación y/o ultrasonido) "
       "o comparación con estudios previos.",
    1: "Tamizaje de rutina (mastografía cada 2 años en mujeres de 40 a 69 años, NOM-041).",
    2: "Tamizaje de rutina (mastografía cada 2 años en mujeres de 40 a 69 años, NOM-041).",
    3: "Seguimiento a corto plazo: mastografía unilateral a los 6 meses y luego a los 12 y 24 meses.",
    4: "Diagnóstico tisular: biopsia guiada por imagen.",
    5: "Diagnóstico tisular: biopsia guiada por imagen y referencia a la unidad de patología mamaria.",
    6: "Escisión quirúrgica / manejo oncológico según corresponda.",
}


def suggest_birads(p_malig: float | None, birads_probs: list[float] | None, thr_high: float, thr_low: float) -> dict:
    """Combina la probabilidad de malignidad con la cabeza BI-RADS para una categoría sugerida."""
    from_head = None
    if birads_probs:
        from_head = int(max(range(len(birads_probs)), key=lambda i: birads_probs[i]))
    if p_malig is None:
        return {"birads": from_head, "razon": "solo cabeza BI-RADS"}
    if p_malig >= max(thr_high, 0.8):
        cat, why = 5, "probabilidad de malignidad muy alta"
    elif p_malig >= thr_high:
        cat, why = 4, "probabilidad de malignidad por encima del umbral operativo"
    elif p_malig >= thr_low:
        cat, why = 3, "probabilidad intermedia"
    else:
        cat, why = 2 if (from_head or 1) >= 2 else 1, "probabilidad baja"
    if from_head is not None and from_head == 0:
        cat, why = 0, "el modelo sugiere estudio incompleto"
    return {"birads": cat, "birads_cabeza": from_head, "razon": why}


def recommendations(findings: dict) -> list[str]:
    """Lista de recomendaciones para el radiólogo, a partir de los hallazgos estructurados."""
    recs = []
    b = findings.get("birads_sugerido")
    if b is not None:
        recs.append(f"Conducta sugerida para BI-RADS {b}: {MANEJO[b]}")
    dens = findings.get("densidad_predicha")
    if dens in ("C", "D"):
        recs.append("Mama densa (ACR C/D): la sensibilidad de la mastografía disminuye; considerar "
                    "ultrasonido complementario según criterio del radiólogo.")
    loc = findings.get("localizacion_ia") or {}
    if b is not None and b >= 3 and loc:
        recs.append(f"Revisar con atención la zona {loc.get('depth_zone', '')} / región "
                    f"{loc.get('vertical_region', '')} de la imagen (máxima activación del modelo).")
    p = findings.get("prob_malignidad")
    hb = findings.get("birads_cabeza")
    if p is not None and hb is not None and ((p >= 0.5 and hb <= 2) or (p < 0.15 and hb >= 4)):
        recs.append("Discordancia interna entre las salidas del modelo: interpretar con especial cautela.")
    if findings.get("calidad", {}).get("advertencias"):
        recs.append("Calidad de imagen/segmentación limitada: verificar la placa original.")
    recs.append("Correlacionar con la proyección contralateral/ortogonal, estudios previos y la clínica.")
    return recs
