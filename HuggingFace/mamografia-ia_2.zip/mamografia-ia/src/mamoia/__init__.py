"""MamoIA: pipeline docente para detección temprana de cáncer de mama.

Etapas:
  1. data      -> inventario, etiquetas, preprocesamiento y anonimización
  2. classic   -> reimplementación del CADe de la tesis (Top-Hat, CLAHE, difusión, Tsallis)
  3. models    -> clasificador CNN (benigno/maligno, BI-RADS, densidad) y captioner CNN-LSTM
  4. llm       -> redacción del reporte para el radiólogo (Claude, Ollama o plantilla)
  5. pipeline  -> inferencia de extremo a extremo (usado por la API y la app web)

AVISO: herramienta educativa y de investigación. No es un dispositivo médico.
"""
__version__ = "0.1.0"
