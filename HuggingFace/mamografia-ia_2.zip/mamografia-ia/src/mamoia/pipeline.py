"""Inferencia de extremo a extremo: imagen -> preprocesamiento -> CADe clásico -> CNN -> Grad-CAM
-> LSTM -> reporte LLM. Es lo que usa la API (api/main.py) y el notebook 04.

  from mamoia.pipeline import MamoPipeline
  pipe = MamoPipeline.load("checkpoints/cls_local.pt", "checkpoints/captioner.pt")
  res = pipe.analyze("data/raw/prueba/0011.jpg", laterality="L", projection="CC")
  print(res["reporte"]["markdown"])

Sin checkpoints funciona en "modo demostración": sólo CADe clásico + reporte por plantilla.
CLI:
  python -m mamoia.pipeline imagen.jpg --classifier ... --captioner ... --llm template|claude|ollama
"""
from __future__ import annotations

import argparse
import base64
import json
from pathlib import Path

import cv2
import numpy as np
import torch

from mamoia.classic.cade import detect_rois, draw_rois, summarize_rois
from mamoia.config import load_config
from mamoia.data.dataset import to_tensor
from mamoia.data.dicom_io import is_dicom, read_dicom
from mamoia.data.preprocess import preprocess, read_gray
from mamoia.explain.gradcam import attention_map, gradcam, locate_peak, overlay
from mamoia.llm.report import write_report, write_study_report
from mamoia.models.captioner import LSTMCaptioner
from mamoia.models.classifier import load_classifier
from mamoia.text.vocab import Vocab


def _png_b64(img: np.ndarray) -> str:
    ok, buf = cv2.imencode(".png", img)
    return base64.b64encode(buf.tobytes()).decode()


class MamoPipeline:
    def __init__(self, cfg=None, classifier=None, cls_ckpt=None, captioner=None, vocab=None, device=None):
        self.cfg = cfg or load_config()
        self.dev = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.classifier, self.cls_ckpt = classifier, cls_ckpt or {}
        self.captioner, self.vocab = captioner, vocab
        self.img_size = tuple(self.cls_ckpt.get("img_size", (self.cfg["preprocess"]["out_height"],
                                                              self.cfg["preprocess"]["out_width"])))
        if self.cls_ckpt.get("threshold") is not None:
            self.cfg["thresholds"]["malignancy_high"] = float(self.cls_ckpt["threshold"])

    @classmethod
    def load(cls, classifier_ckpt=None, captioner_ckpt=None, cfg=None, device=None):
        cfg = cfg or load_config()
        dev = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
        model = ck = cap = vocab = None
        if classifier_ckpt and Path(classifier_ckpt).exists():
            model, ck = load_classifier(classifier_ckpt, dev)
            model.to(dev)
        if model is not None and captioner_ckpt and Path(captioner_ckpt).exists():
            cc = torch.load(captioner_ckpt, map_location=dev, weights_only=False)
            vocab = Vocab(cc["vocab"])
            cap = LSTMCaptioner(model, model.n_features, len(vocab),
                                cond_dim=1 + model.head_birads.out_features + model.head_density.out_features,
                                **cc["args"]).to(dev)
            cap.load_state_dict(cc["state_dict"], strict=False)
            cap.eval()
        return cls(cfg, model, ck, cap, vocab, dev)

    @property
    def model_version(self):
        if self.classifier is None:
            return "demo-sin-modelo"
        return f"{self.classifier.backbone_name}-ep{self.cls_ckpt.get('epoch')}-{self.cls_ckpt.get('source')}"

    def analyze(self, image, laterality=None, projection=None, llm=None, with_images=True, beam_size=None,
                report=True) -> dict:
        P = self.cfg["preprocess"]
        invert = P["invert_if_negative"]
        dicom_meta = {}
        if isinstance(image, (str, Path)) and is_dicom(Path(image)):
            raw, dicom_meta = read_dicom(image)              # ya en positivo (MONOCHROME1 invertido)
            invert = False
            laterality = laterality or (dicom_meta["laterality"] if dicom_meta["laterality"] != "U" else None)
            projection = projection or (dicom_meta["projection"] if dicom_meta["projection"] != "U" else None)
        else:
            raw = read_gray(image) if isinstance(image, (str, Path)) else image
        img, mask, meta = preprocess(raw, out_hw=self.img_size, invert_if_negative=invert,
                                     flip_to_left=P["flip_to_left"], clahe_clip=P["clahe_clip"], clahe_tiles=P["clahe_tiles"])
        res = {"laterality": laterality, "projection": projection, "model_version": self.model_version,
               "preprocess": {"inverted": meta.inverted, "flipped": meta.flipped, "warnings": meta.warnings,
                              "breast_area_frac": round(meta.breast_area_frac, 3)}}
        # 1) CADe clásico (tesis)
        C = self.cfg["classic"]
        cade = detect_rois(img, mask, n_zones=C["depth_zones"], radius_frac=C["tophat_radius_frac"],
                           diffusion_iters=C["diffusion_iters"], diffusion_kappa=C["diffusion_kappa"],
                           tsallis_q=C["tsallis_q"], min_roi_area_px=C["min_roi_area_px"])
        res["cade_clasico"] = summarize_rois(cade["rois"])
        images = {"preprocesada": img, "cade": draw_rois(img, cade["rois"])}
        # 2) Clasificador + Grad-CAM
        if self.classifier is not None:
            x = to_tensor(img).unsqueeze(0).to(self.dev)
            with torch.no_grad():
                o = self.classifier(x)
            res["clasificador"] = {
                "prob_malignidad": float(torch.sigmoid(o["malignancy"])[0]),
                "prob_birads": [round(float(v), 4) for v in torch.softmax(o["birads"], 1)[0]],
                "prob_densidad": [round(float(v), 4) for v in torch.softmax(o["density"], 1)[0]],
                "umbral": self.cfg["thresholds"]["malignancy_high"]}
            with torch.enable_grad():
                heat = gradcam(self.classifier, x)
            res["localizacion"] = locate_peak(heat, mask, laterality, projection, C["depth_zones"])
            images["gradcam"] = overlay(img, heat)
            # 3) LSTM
            if self.captioner is not None:
                K = self.cfg["captioner"]
                seqs, alphas, hw, _ = self.captioner.generate(x, self.vocab.bos, self.vocab.eos, K["max_len"],
                                                              beam_size or K["beam_size"])
                res["caption_lstm"] = self.vocab.decode(seqs[0])
                if len(alphas[0]):
                    images["atencion_lstm"] = overlay(img, attention_map(alphas[0], hw, img.shape))
        if dicom_meta:
            res["dicom"] = {k: dicom_meta.get(k) for k in ("Manufacturer", "lat_source", "proj_source", "is_standard_view")}
        # 4) Reporte LLM
        if report:
            res["reporte"] = write_report(res, self.cfg, llm)
        if with_images:
            res["imagenes_png_b64"] = {k: _png_b64(v) for k, v in images.items()}
        res["_images"] = images
        return res


    def analyze_study(self, images, llm=None, how="mean") -> dict:
        """Analiza un estudio completo (lista de rutas DICOM/JPG o tuplas (ruta, lat, proy)) y redacta UN
        reporte bilateral. La probabilidad por mama es el promedio (o máx.) de sus vistas."""
        per_img = []
        for it in images:
            path, lat, proj = (it, None, None) if not isinstance(it, (tuple, list)) else (list(it) + [None, None])[:3]
            r = self.analyze(path, lat, proj, with_images=False, report=False)
            r["fuente"] = Path(path).name if isinstance(path, (str, Path)) else f"imagen_{len(per_img) + 1}"
            per_img.append(r)
        breasts = {}
        for side in ("L", "R"):
            views = [r for r in per_img if r.get("laterality") == side]
            if not views:
                continue
            probs = [r["clasificador"]["prob_malignidad"] for r in views if r.get("clasificador")]
            best = max(views, key=lambda r: (r.get("clasificador") or {}).get("prob_malignidad", 0))
            agg = dict(best)
            if probs:
                agg["clasificador"] = dict(best["clasificador"])
                agg["clasificador"]["prob_malignidad"] = float(np.mean(probs) if how == "mean" else np.max(probs))
                agg["clasificador"]["prob_por_vista"] = {r.get("projection") or r["fuente"]:
                                                         round(r["clasificador"]["prob_malignidad"], 3) for r in views}
            breasts[side] = agg
        rep = write_study_report(breasts, self.cfg, llm)
        return {"por_imagen": [{k: v for k, v in r.items() if k != "_images"} for r in per_img],
                "por_mama": {k: {kk: vv for kk, vv in v.items() if kk not in ("_images", "reporte")} for k, v in breasts.items()},
                "reporte": rep, "_images": {f"{r.get('laterality')}{r.get('projection')}_{r['fuente']}": r["_images"]
                                            for r in per_img}}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("image")
    ap.add_argument("--classifier", default="checkpoints/classifier.pt")
    ap.add_argument("--captioner", default="checkpoints/captioner.pt")
    ap.add_argument("--llm", default=None, choices=["template", "claude", "ollama"])
    ap.add_argument("--laterality", default=None)
    ap.add_argument("--projection", default=None)
    ap.add_argument("--out", default="outputs")
    args = ap.parse_args()
    pipe = MamoPipeline.load(args.classifier, args.captioner)
    r = pipe.analyze(args.image, args.laterality, args.projection, args.llm, with_images=False)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    stem = Path(args.image).stem
    for k, v in r.pop("_images").items():
        cv2.imwrite(str(out / f"{stem}_{k}.png"), v)
    (out / f"{stem}.json").write_text(json.dumps(r, indent=2, ensure_ascii=False))
    print(r["reporte"]["markdown"])


if __name__ == "__main__":
    main()
