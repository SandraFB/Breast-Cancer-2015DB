"""Generación de descripciones (en español, léxico BI-RADS) a partir de etiquetas estructuradas.

¿Para qué? El captioner CNN-LSTM necesita pares (imagen, texto). Si el radiólogo no dejó
reporte libre (`report_text`), se construye una descripción a partir de los campos de la
plantilla de etiquetas (o de CBIS-DDSM). Con `variant=True` se generan paráfrasis para que
el LSTM no memorice una sola frase.
"""
from __future__ import annotations

import random

LAT = {"L": "izquierda", "R": "derecha", "I": "izquierda", "D": "derecha"}
DENSITY = {
    "A": "mama predominantemente grasa (ACR A)",
    "B": "densidades fibroglandulares dispersas (ACR B)",
    "C": "mama heterogéneamente densa (ACR C)",
    "D": "mama extremadamente densa (ACR D)",
}
LESION = {
    "masa": "masa", "asimetria": "asimetría focal", "microcalcificaciones": "microcalcificaciones",
    "distorsion": "distorsión de la arquitectura", "ganglio": "ganglio linfático intramamario",
}
BIRADS_TXT = {
    0: "estudio incompleto, requiere evaluación adicional",
    1: "estudio negativo",
    2: "hallazgo benigno",
    3: "hallazgo probablemente benigno",
    4: "hallazgo sospechoso de malignidad",
    5: "hallazgo altamente sugestivo de malignidad",
    6: "malignidad conocida comprobada por biopsia",
}
TERCIO = {"anterior": "anterior", "media": "medio", "medio": "medio", "posterior": "posterior"}
QUAD = {"CSE": "cuadrante superior externo", "CSI": "cuadrante superior interno",
        "CIE": "cuadrante inferior externo", "CII": "cuadrante inferior interno",
        "UCS": "unión de cuadrantes superiores", "UCE": "unión de cuadrantes externos",
        "retroareolar": "región retroareolar", "axilar": "prolongación axilar"}


def _get(row, k):
    v = row.get(k)
    if v is None:
        return None
    s = str(v).strip()
    return None if s in ("", "nan", "None") else s


def describe(row: dict, variant: bool = False, rng: random.Random | None = None, include_view: bool = True) -> str:
    """Convierte una fila de etiquetas en una descripción radiológica breve.
    include_view=False omite lateralidad/proyección: el captioner no puede "verlas" (la imagen se
    normaliza en orientación) y se añaden después desde los metadatos DICOM."""
    if txt := _get(row, "report_text"):   # el reporte real del radiólogo siempre tiene prioridad
        return txt
    rng = rng or random.Random()
    pick = (lambda opts: rng.choice(opts)) if variant else (lambda opts: opts[0])
    parts = []
    lat, proj = _get(row, "laterality"), _get(row, "projection")
    if include_view and (lat or proj):
        parts.append(pick(["Mama {l}, proyección {p}.", "Proyección {p} de mama {l}."]).format(
            l=LAT.get(lat, "no especificada"), p=proj or "no especificada"))
    if d := _get(row, "density"):
        parts.append(pick(["Patrón de {d}.", "Se observa {d}."]).format(d=DENSITY.get(d.upper(), d)))
    lt = _get(row, "lesion_type")
    if lt and lt != "ninguna":
        desc = LESION.get(lt, lt)
        if sh := _get(row, "lesion_shape"):
            desc += f" de forma {sh}"
        if mg := _get(row, "lesion_margin"):
            desc += f" y márgenes {mg}s" if not mg.endswith("s") else f" y márgenes {mg}"
        loc = []
        if q := _get(row, "lesion_quadrant"):
            loc.append(QUAD.get(q, q))
        if z := _get(row, "depth_zone"):
            loc.append(f"tercio {TERCIO.get(z, z)}")
        where = f" en {', '.join(loc)}" if loc else ""
        size = f" de aproximadamente {_get(row, 'lesion_size_mm')} mm" if _get(row, "lesion_size_mm") else ""
        parts.append(pick(["Se identifica {d}{s}{w}.", "Presenta {d}{s}{w}.", "Hallazgo: {d}{s}{w}."]).format(
            d=desc, s=size, w=where))
    elif lt == "ninguna" or _get(row, "pathology") == "normal":
        parts.append(pick(["Sin masas, asimetrías ni microcalcificaciones sospechosas.",
                           "No se observan lesiones sospechosas."]))
    b = _get(row, "birads")
    if b is not None and b.replace(".0", "").isdigit() and int(float(b)) >= 0:
        bi = int(float(b))
        parts.append(pick(["Impresión: {t}. BI-RADS {b}.", "BI-RADS {b}: {t}."]).format(t=BIRADS_TXT.get(bi, ""), b=bi))
    path = _get(row, "pathology")
    if path in ("benigno", "maligno") and _get(row, "biopsy_confirmed") in ("1", "1.0", "True"):
        parts.append(f"Correlación histopatológica: {path}.")
    return " ".join(parts) if parts else "Sin información estructurada disponible."
