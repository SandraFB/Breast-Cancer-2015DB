"""Tokenizador y vocabulario mínimos (palabra a palabra) para el decodificador LSTM."""
from __future__ import annotations

import json
import re
from collections import Counter
from pathlib import Path

PAD, BOS, EOS, UNK = "<pad>", "<bos>", "<eos>", "<unk>"
_TOK = re.compile(r"[a-záéíóúüñ0-9]+(?:[-/][a-z0-9]+)?|[.,:;()]", re.I)


def tokenize(text: str) -> list[str]:
    return _TOK.findall(text.lower())


def detokenize(tokens: list[str]) -> str:
    s = " ".join(tokens)
    s = re.sub(r"\s+([.,:;)])", r"\1", s).replace("( ", "(")
    # mayúscula al inicio de cada oración y en siglas conocidas
    s = re.sub(r"(^|[.:]\s+)([a-záéíóúñ])", lambda m: m.group(1) + m.group(2).upper(), s)
    for sig in ("bi-rads", "acr", "cc", "mlo", "cse", "csi", "cie", "cii"):
        s = re.sub(rf"\b{sig}\b", sig.upper(), s, flags=re.I)
    s = re.sub(r"\(ACR ([abcd])\)", lambda m: f"(ACR {m.group(1).upper()})", s)
    return s


class Vocab:
    def __init__(self, itos: list[str]):
        self.itos = itos
        self.stoi = {t: i for i, t in enumerate(itos)}

    @classmethod
    def build(cls, texts: list[str], min_freq: int = 1) -> "Vocab":
        c = Counter(t for s in texts for t in tokenize(s))
        return cls([PAD, BOS, EOS, UNK] + sorted(t for t, n in c.items() if n >= min_freq))

    def __len__(self):
        return len(self.itos)

    @property
    def pad(self):
        return self.stoi[PAD]

    @property
    def bos(self):
        return self.stoi[BOS]

    @property
    def eos(self):
        return self.stoi[EOS]

    def encode(self, text: str, max_len: int) -> list[int]:
        ids = [self.bos] + [self.stoi.get(t, self.stoi[UNK]) for t in tokenize(text)][: max_len - 2] + [self.eos]
        return ids + [self.pad] * (max_len - len(ids))

    def decode(self, ids) -> str:
        out = []
        for i in ids:
            t = self.itos[int(i)]
            if t == EOS:
                break
            if t not in (PAD, BOS):
                out.append(t)
        return detokenize(out)

    def save(self, path):
        Path(path).write_text(json.dumps(self.itos, ensure_ascii=False))

    @classmethod
    def load(cls, path):
        return cls(json.loads(Path(path).read_text()))
