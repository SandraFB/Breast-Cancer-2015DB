"""Extracción de etiquetas estructuradas a partir de los REPORTES de mastografía (texto libre).

Entrada: los Excel `PX_*_B3-B4-B5.xlsx` (columnas: Paciente, Resultado, [Interpretación clínica],
[Conducta a seguir], ..., Interpretación del radiólogo).

Salida por paciente: BI-RADS (+ subcategoría 4a/4b/4c), densidad ACR, lateralidad del hallazgo
principal, tipos de lesión (con detección simple de NEGACIONES), cuadrante, tamaño, márgenes,
resultado de biopsia cuando el addendum lo reporta, banderas clínicas (palpable, mastectomía),
la impresión/conclusión y el texto ANONIMIZADO (sin nombres de médicos ni fechas).

Después `expand_to_breasts` crea una fila por mama (L/R) con etiquetas "débiles":
  * mama con el hallazgo           -> BI-RADS del reporte
  * mama contralateral (si el hallazgo es claramente unilateral) -> "sin hallazgo sospechoso"

Es un extractor por reglas (transparente y evaluable). El notebook incluye además la extracción con
un LLM y la comparación de ambos: ¡buen ejercicio de PLN clínico!

  python -m mamoia.text.report_parser PX_1-15.xlsx PX_16-53.xlsx ... --out data/labels/reportes.csv
"""
from __future__ import annotations

import argparse
import re
import unicodedata
from pathlib import Path

import pandas as pd

# ----------------------------------------------------------------------------- utilidades


def norm(s: str) -> str:
    """minúsculas, sin acentos, espacios normalizados (para buscar patrones)."""
    s = unicodedata.normalize("NFKD", str(s)).encode("ascii", "ignore").decode()
    return re.sub(r"\s+", " ", s.lower().replace("\xa0", " ")).strip()


def clean_spaces(s: str) -> str:
    return re.sub(r"\s+", " ", str(s).replace("\xa0", " ")).strip()


# nombres tras Dr./Dra./Dr, (hasta 3 palabras; preferimos borrar de más que dejar un nombre)
_DOCTOR = re.compile(r"(?i)\b(dra?|doctora?)\b[.,]*\s+[a-záéíóúñ]+(\s+(?!y\b|con\b|se\b|en\b)[a-záéíóúñ]+){0,2}")
_INITIALS = re.compile(r"\((?:[A-Z]{2,4})\)|\b[rR]\d\s*[mM]\s*[iI1]\s*[gG]?\.?(?=\W)|\bRGyO\b|\bRMIg\b")
_RESIDENT = re.compile(r"(?i)/+\s*r\d?\s*(m\s*i\s*g|gyo|mig)[^/<=]{0,30}")
_ELABORADO = re.compile(r"(?i)<?=*\s*addendum\s*=*>?\s*|elaborado por\s*:?.*?(hrs\.?|horas)|<?=\s*(=\s*){3,}>?")
_DATE = re.compile(r"(?i)\b\d{1,2}\s*[/-]\s*\d{1,2}\s*[/-]\s*\d{2,4}\b|\b\d{1,2}\s+de\s+[a-z]+\s+(de|del)\s+\d{4}\b|"
                   r"\b(lunes|martes|mi[eé]rcoles|jueves|viernes|s[aá]bado|domingo)\b")


def anonymize(text: str) -> str:
    """Quita nombres de médicos/residentes, encabezados de addendum y fechas exactas."""
    t = _ELABORADO.sub(" ", str(text))
    t = _RESIDENT.sub(" ", t)
    t = _DOCTOR.sub("[MÉDICO]", t)
    t = _INITIALS.sub(" ", t)
    t = re.sub(r"\[MÉDICO\][\s.,/]*(?:[A-ZÁÉÍÓÚÑ]{3,}\b[\s.,]*){1,3}", "[MÉDICO] ", t)   # firmas en mayúsculas
    t = _DATE.sub("[FECHA]", t)
    return clean_spaces(t)


NEG = re.compile(r"\b(sin|no|ni|niega|negativ[oa]s?|ausencia de|libre de|descartan?)\b")


def _sentences(t: str) -> list[str]:
    return [s.strip() for s in re.split(r"(?<=[.;:])\s+|\s-\s|\n", t) if s.strip()]


def _positive(sentence: str, pattern: str) -> bool:
    """True si el patrón aparece y NO está precedido por una negación cercana (≈ NegEx)."""
    for m in re.finditer(pattern, sentence):
        window = sentence[max(0, m.start() - 45): m.start()]
        if not NEG.search(window):
            return True
    return False


# ----------------------------------------------------------------------------- campos

LESIONS = {
    "masa": r"\b(nodul\w*|masa\w*|tumor\w*|lesion (ovalada|redonda|nodular|irregular|espiculada))",
    "microcalcificaciones": r"\b(micro)?calcificaciones (pleomorf\w*|agrupad\w*|finas|amorf\w*|lineal\w*|segmentari\w*|heterogene\w*|sospech\w*)"
                            r"|\bmicrocalcificaciones\b",
    "asimetria": r"\basimetri\w* (focal|en la densidad|de la densidad|en desarrollo)|densidad asimetrica|radiodensidad asimetrica|asimetria focal",
    "distorsion": r"\bdistorsi\w* (de la )?arquitect\w*",
    "retraccion_pezon": r"\bretracci\w* (del? )?(pezon|pezones)",
    "engrosamiento_piel": r"\bengrosamiento (de la )?piel|piel engrosada|engrosamiento cutaneo|ulcer\w*",
    "adenopatia_sospechosa": r"adenomegalia\w*|ganglio\w* [^.]{0,40}(alta densidad|sin hilio|perdida del hilio|sospech|infiltra)",
}
QUAD = [("CSE", r"\b(cse|cuadrante supero ?externo|cuadrante superior externo|superoexterno)\b"),
        ("CSI", r"\b(csi|cuadrante supero ?interno|cuadrante superior interno|superointerno)\b"),
        ("CIE", r"\b(cie|cuadrante infero ?externo|cuadrante inferior externo|inferoexterno)\b"),
        ("CII", r"\b(cii|cuadrante infero ?interno|cuadrante inferior interno|inferointerno)\b"),
        ("UCS", r"\bunion de (los )?cuadrantes superiores\b"),
        ("UCE", r"\bunion de (los )?cuadrantes externos\b"),
        ("retroareolar", r"\b(retroareolar|subareolar|retro ?areolar)\b"),
        ("axilar", r"\b(cola de spence|prolongacion axilar)\b")]
LEFT = r"\b(izquierd\w*|izq\.?|mi)\b|\b(cs[ei]|ci[ei])\s*mi\b|\bmi\b"
RIGHT = r"\b(derech\w*|der\.?|md)\b|\b(cs[ei]|ci[ei])\s*md\b"
SUSP = r"(nodul|masa|tumor|espicul|pleomorf|agrupad|distorsi|asimetri|sospech|birads ?-? ?[45]|bi-rads ?[45]|malign|carcinoma|retracci|adenomegal|ulcer|biopsia|baaf)"


def parse_density(t: str) -> str | None:
    """Densidad ACR (A-D). Primero letras/números explícitos, luego descriptores."""
    pats = [r"tipo\s*[\"“(']\s*([abcd])\s*[\"”)']",                 # tipo "D", tipo (b)
            r"\btipo\s+([bcd])\b",
            r"\btipo\s+a\b(?!\s+(expensas|nivel|predominio))",
            r"\bacr\s*[:\-]?\s*([abcd])\b",
            r"\b([abcd])\s+(del|de la)\s+(acr|colegio)"]
    for pat in pats:
        if m := re.search(pat, t):
            g = m.group(1) if m.lastindex else "a"
            return (g or "a").upper()
    m = re.search(r"tipo\s*[\"“(]?\s*(1|2|3|4|iv|i{1,3})\b[^.]{0,30}(acr|colegio)", t) or re.search(r"\b[abcd]\s*-\s*(iv|i{1,3})\b", t)
    if m:
        return {"1": "A", "i": "A", "2": "B", "ii": "B", "3": "C", "iii": "C", "4": "D", "iv": "D"}[m.group(1)]
    for pat, d in ((r"extremadamente dens|muy densa", "D"),
                   (r"heterogene\w* dens|fibro-?glandular (denso|heterogene)|mixto,? (denso|de predominio fibroglandular)|patron mamario mixto denso", "C"),
                   (r"fibroglandular disperso|densidades? (fibroglandulares )?dispers|mixto,? de predominio graso", "B"),
                   (r"predominantemente grasa|predominio graso|tipo graso|mamas? grasa", "A")):
        if re.search(pat, t):
            return d
    return None


def parse_laterality(t: str) -> tuple[str, dict]:
    """Lateralidad del hallazgo principal: L, R, B (bilateral) o U (no determinada)."""
    score = {"L": 0.0, "R": 0.0}
    conc_start = max([m.start() for m in re.finditer(r"conclusi|comentario|impresion|diagnostico", t)] or [len(t)])
    for s in _sentences(t):
        if not _positive(s, SUSP):
            continue
        w = 2.0 if t.find(s) >= conc_start else 1.0
        score["L"] += w * len(re.findall(LEFT, s))
        score["R"] += w * len(re.findall(RIGHT, s))
    if re.search(r"mama unica (derecha|izquierda)", t):
        side = "R" if "unica derecha" in t else "L"
        return side, score
    l, r = score["L"], score["R"]
    if l == r == 0:
        return "U", score
    if min(l, r) > 0 and min(l, r) / max(l, r) >= 0.5:
        return "B", score
    return ("L" if l > r else "R"), score


def parse_biopsy(t: str) -> tuple[str | None, str | None]:
    """(resultado, lado) de biopsia/histopatología mencionada en el reporte o su addendum."""
    bx = r"(biops\w*|\bbx\b|histopatol\w*)"
    res = r"(reporta\w*|resultado\w*|report\w*|histopatolog\w*|\bdx\b|diagnostic\w*)"
    rules = [("maligno", rf"{bx}[^.:]{{0,80}}{res}[^.:]{{0,80}}(carcinoma|cancer|malign\w* positiv|positiv\w* (a|para) (ca|malign))"),
             ("maligno", r"(idx:? ?cancer|en tratamiento por (carcinoma|cancer|ca\b)[^.]*)"),
             ("benigno", rf"{bx}[^.:]{{0,80}}{res}[^.:]{{0,80}}(fibroadenoma|fibroquist|mastopatia|negativo a malignidad|benign)"),
             ("pendiente", rf"{bx}[^.]{{0,60}}(espera|pendiente)")]
    for label, pat in rules:
        if m := re.search(pat, t):
            frag = t[max(0, m.start() - 15): m.end()]
            side = "L" if re.search(LEFT, frag) and not re.search(RIGHT, frag) else \
                   "R" if re.search(RIGHT, frag) and not re.search(LEFT, frag) else None
            return label, side
    return None, None


def extract_impression(raw: str) -> str:
    t = clean_spaces(raw)
    starts = [m.end() for m in re.finditer(r"(?i)(conclusi[oó]n|comentario|impresi[oó]n diagn[oó]stica|impresi[oó]n|diagn[oó]stico)\s*[:.]?", t)]
    if not starts:
        return ""
    seg = t[starts[-1]:]
    seg = re.split(r"(?i)consideraciones generales|nota:|<?=+\s*addendum|recomendaci[oó]n", seg)[0]
    return anonymize(seg)[:600]


def parse_report(patient_id: str, resultado: str, raw: str, conducta: str | None = None) -> dict:
    t = norm(anonymize(raw))
    br = re.search(r"([0-6])", str(resultado))
    sub = re.search(r"bi-? ?rads\s*[-:]?\s*(?:categoria\s*)?4\s*-?\s*([abc])\b", t)
    lesions = {k: any(_positive(s, p) for s in _sentences(t)) for k, p in LESIONS.items()}
    side, score = parse_laterality(t)
    quad = None
    for s in _sentences(t):
        if _positive(s, SUSP):
            for q, p in QUAD:
                if re.search(p, s):
                    quad = q
                    break
        if quad:
            break
    sizes = []
    for s in _sentences(t):
        if _positive(s, SUSP):
            for v, u in re.findall(r"(\d+(?:[.,]\d+)?)\s*(mm|cm|cms)\b", s):
                x = float(v.replace(",", "."))
                sizes.append(x * 10 if u.startswith("cm") else x)
    margin = None
    for pat, mg in ((r"espicul", "espiculado"), (r"microlobul", "microlobulado"),
                    (r"(bordes|margenes|contornos) (mal definidos|irregulares|indistintos)", "indistinto"),
                    (r"(bordes|margenes|contornos) (bien definidos|circunscritos|regulares)", "circunscrito")):
        if re.search(pat, t):
            margin = mg
            break
    bx_res, bx_side = parse_biopsy(t)
    main = next((k for k in ("masa", "microcalcificaciones", "distorsion", "asimetria") if lesions[k]), "ninguna")
    return {
        "patient_id": patient_id,
        "birads": int(br.group(1)) if br else None,
        "birads_sub": f"4{sub.group(1)}" if sub else None,
        "density": parse_density(t),
        "lesion_laterality": side,
        "lat_score_L": score["L"], "lat_score_R": score["R"],
        "lesion_type": main,
        **{f"has_{k}": v for k, v in lesions.items()},
        "lesion_quadrant": quad,
        "lesion_size_mm": max(sizes) if sizes else None,
        "lesion_margin": margin if main == "masa" else None,
        "biopsy_result": bx_res,
        "biopsy_side": bx_side,
        "palpable": bool(re.search(r"palpable|sintomatica|tumoracion|tumor (en|de) mama", t)),
        "prior_cancer_or_mastectomy": bool(re.search(r"mastectom|mama unica|antecedente de ca|ca(ncer)?\.? de mama (\w+ )?(hace|en \d)|post ?tratamiento", t)),
        "unilateral_study": bool(re.search(r"mastografia unilateral|mama unica", t)),
        "conducta": clean_spaces(conducta) if conducta else None,
        "impresion": extract_impression(raw),
        "report_anon": anonymize(raw),
    }


# ----------------------------------------------------------------------------- Excel


def load_excel_reports(paths) -> pd.DataFrame:
    """Lee los Excel (formatos de 3 y 6 columnas) -> patient_id, resultado, conducta, raw."""
    rows = []
    for p in paths:
        df = pd.read_excel(p, dtype=str).fillna("")
        cols = list(df.columns)
        text_col = cols[-1] if len(cols) > 3 else cols[2]       # última "Interpretación" = radiólogo
        cond_col = next((c for c in cols if "conducta" in c.lower()), None)
        for _, r in df.iterrows():
            pid = str(r[cols[0]]).strip()
            if not pid.lower().startswith("paciente"):
                continue
            rows.append({"patient_id": pid, "resultado": r[cols[1]], "raw": r[text_col],
                         "conducta": r[cond_col] if cond_col else None, "source_file": Path(p).name})
    out = pd.DataFrame(rows).drop_duplicates("patient_id")
    out["pid_num"] = out.patient_id.str.extract(r"(\d+)").astype(int)
    return out.sort_values("pid_num").reset_index(drop=True)


def parse_all(paths) -> pd.DataFrame:
    rep = load_excel_reports(paths)
    parsed = [parse_report(r.patient_id, r.resultado, r.raw, r.conducta) for r in rep.itertuples()]
    return pd.DataFrame(parsed).merge(rep[["patient_id", "pid_num", "source_file"]], on="patient_id")


# ----------------------------------------------------------------------------- por mama


def expand_to_breasts(rep: pd.DataFrame, contralateral_as_negative: bool = True) -> pd.DataFrame:
    """Una fila por mama con su etiqueta. Ver docstring del módulo."""
    rows = []
    for r in rep.to_dict("records"):
        side = r["lesion_laterality"]
        for lat in ("L", "R"):
            row = {"patient_id": r["patient_id"], "laterality": lat, "density": r["density"],
                   "report_birads": r["birads"], "birads_sub": r["birads_sub"], "biopsy_result": r["biopsy_result"]}
            affected = side in ("B", "U") or side == lat
            if affected:
                row.update(birads=r["birads"], lesion_type=r["lesion_type"], lesion_quadrant=r["lesion_quadrant"],
                           lesion_size_mm=r["lesion_size_mm"], lesion_margin=r["lesion_margin"],
                           breast_label_source="hallazgo" if side == lat else ("bilateral" if side == "B" else "paciente"),
                           pathology="", biopsy_confirmed=0)
            elif contralateral_as_negative and not r["prior_cancer_or_mastectomy"]:
                row.update(birads=None, lesion_type="ninguna", pathology="", biopsy_confirmed=0,
                           breast_label_source="contralateral")
            else:
                row.update(birads=None, lesion_type=None, pathology="", breast_label_source="excluida")
            # la biopsia se asigna a su lado si el texto lo dice; si no, a la mama del hallazgo
            bs = r.get("biopsy_side")
            bx_side = bs if isinstance(bs, str) else (side if side in ("L", "R") else None)
            if r["biopsy_result"] in ("maligno", "benigno") and bx_side == lat:
                row.update(pathology=r["biopsy_result"], biopsy_confirmed=1,
                           breast_label_source=row.get("breast_label_source") if row.get("breast_label_source") != "contralateral" else "biopsia")
                if row.get("birads") is None:
                    row["birads"] = 6 if r["biopsy_result"] == "maligno" else None
            rows.append(row)
    return pd.DataFrame(rows)


def breast_targets(br: pd.DataFrame, target: str = "b5_vs_resto") -> pd.DataFrame:
    """Define y_malig por mama.
    target:
      'b5_vs_resto'    1 = BI-RADS 5 (o biopsia maligna);   0 = BI-RADS 3-4, contralateral o biopsia benigna
      'b45_vs_resto'   1 = BI-RADS 4-5 (o biopsia maligna); 0 = BI-RADS 3, contralateral o biopsia benigna
      'hallazgo_vs_contralateral'  1 = mama con hallazgo (B3-5);  0 = contralateral (detección)
    """
    br = br.copy()
    b = pd.to_numeric(br.birads, errors="coerce")
    src = br.breast_label_source
    if target == "b5_vs_resto":
        y = (b >= 5).astype(float)
    elif target == "b45_vs_resto":
        y = (b >= 4).astype(float)
    elif target == "hallazgo_vs_contralateral":
        y = b.notna().astype(float)
    else:
        raise ValueError(target)
    y[src == "contralateral"] = 0
    y[src == "excluida"] = -1
    if target != "hallazgo_vs_contralateral":
        y[br.pathology == "maligno"] = 1
        y[(br.pathology == "benigno") & (src != "contralateral")] = 0
    br["y_malig"] = y.fillna(-1).astype(int)
    br["label_source"] = src.where(br.pathology == "", "biopsia")
    br["y_birads"] = b.fillna(-1).astype(int)
    br["y_density"] = br.density.map({"A": 0, "B": 1, "C": 2, "D": 3}).fillna(-1).astype(int)
    return br


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("xlsx", nargs="+")
    ap.add_argument("--out", default="data/labels/reportes_extraidos.csv")
    a = ap.parse_args()
    df = parse_all(a.xlsx)
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(a.out, index=False, encoding="utf-8-sig")
    print(df[["birads", "density", "lesion_laterality", "lesion_type", "biopsy_result"]].describe(include="all").T)
    print(f"-> {a.out}")


if __name__ == "__main__":
    main()
