"""Captioner CNN-LSTM con atención ("Show, Attend and Tell", Xu et al. 2015) condicionado
clínicamente.

  imagen ─► encoder CNN (backbone del clasificador, congelado) ─► F (B, N=h·w, C)
                                                                   │
  probs del clasificador (malignidad, BI-RADS, densidad) ──► h0, c0 │
                                                                   ▼
  <bos> ─► [Embedding] ─► LSTMCell ◄── contexto = Σ α_i F_i  (atención de Bahdanau)
                              │
                              └─► Linear ─► softmax sobre el vocabulario ─► palabra t

Los pesos de atención α se pueden visualizar sobre la mamografía: muestran qué región "mira"
el modelo al escribir cada palabra (útil para discutir interpretabilidad en clase).
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class Attention(nn.Module):
    def __init__(self, enc_dim, hid_dim, attn_dim):
        super().__init__()
        self.enc = nn.Linear(enc_dim, attn_dim)
        self.hid = nn.Linear(hid_dim, attn_dim)
        self.v = nn.Linear(attn_dim, 1)

    def forward(self, feats, h):                       # feats B,N,E ; h B,H
        e = self.v(torch.tanh(self.enc(feats) + self.hid(h).unsqueeze(1))).squeeze(2)
        alpha = F.softmax(e, dim=1)
        return (feats * alpha.unsqueeze(2)).sum(1), alpha


class LSTMCaptioner(nn.Module):
    def __init__(self, encoder: nn.Module, enc_dim: int, vocab_size: int, cond_dim: int = 12,
                 embed_dim=256, hidden_dim=512, attn_dim=256, dropout=0.3, freeze_encoder=True):
        super().__init__()
        self.encoder = encoder                         # MammoClassifier
        self.freeze_encoder = freeze_encoder
        if freeze_encoder:
            for p in self.encoder.parameters():
                p.requires_grad = False
        self.proj = nn.Linear(enc_dim, hidden_dim)
        self.attn = Attention(hidden_dim, hidden_dim, attn_dim)
        self.embed = nn.Embedding(vocab_size, embed_dim)
        self.lstm = nn.LSTMCell(embed_dim + hidden_dim, hidden_dim)
        self.init_h = nn.Linear(hidden_dim + cond_dim, hidden_dim)
        self.init_c = nn.Linear(hidden_dim + cond_dim, hidden_dim)
        self.gate = nn.Linear(hidden_dim, hidden_dim)
        self.drop = nn.Dropout(dropout)
        self.out = nn.Linear(hidden_dim, vocab_size)
        self.hidden_dim, self.vocab_size = hidden_dim, vocab_size

    def encode(self, images):
        ctx = torch.no_grad() if self.freeze_encoder else torch.enable_grad()
        with ctx:
            if self.freeze_encoder:
                self.encoder.eval()
            o = self.encoder(images, return_features=True)
        fmap = o["fmap"].float()
        B, C, h, w = fmap.shape
        feats = self.proj(fmap.flatten(2).transpose(1, 2))          # B, N, H
        cond = torch.cat([torch.sigmoid(o["malignancy"]).unsqueeze(1).float(),
                          F.softmax(o["birads"].float(), 1), F.softmax(o["density"].float(), 1)], 1)
        return feats, cond, (h, w), o

    def init_state(self, feats, cond):
        z = torch.cat([feats.mean(1), cond], 1)
        return torch.tanh(self.init_h(z)), torch.tanh(self.init_c(z))

    def step(self, tok, h, c, feats):
        ctx, alpha = self.attn(feats, h)
        ctx = torch.sigmoid(self.gate(h)) * ctx
        h, c = self.lstm(torch.cat([self.embed(tok), ctx], 1), (h, c))
        return self.out(self.drop(h)), h, c, alpha

    def forward(self, images, tokens):
        """Teacher forcing. tokens: B, T (incluye <bos> ... <eos> <pad>)."""
        feats, cond, _, _ = self.encode(images)
        h, c = self.init_state(feats, cond)
        T = tokens.size(1) - 1
        logits, alphas = [], []
        for t in range(T):
            lg, h, c, a = self.step(tokens[:, t], h, c, feats)
            logits.append(lg)
            alphas.append(a)
        return torch.stack(logits, 1), torch.stack(alphas, 1)

    @staticmethod
    def loss(logits, tokens, alphas, pad_idx, alpha_c=1.0):
        ce = F.cross_entropy(logits.reshape(-1, logits.size(-1)), tokens[:, 1:].reshape(-1), ignore_index=pad_idx)
        # regularización "doblemente estocástica": cada región recibe atención total ≈ 1
        reg = alpha_c * ((1.0 - alphas.sum(1)) ** 2).mean()
        return ce + reg

    @torch.no_grad()
    def generate(self, images, bos, eos, max_len=60, beam_size=1):
        feats, cond, hw, o = self.encode(images)
        if beam_size > 1 and images.size(0) == 1:
            seq, alphas = self._beam(feats, cond, bos, eos, max_len, beam_size)
            return [seq], [alphas], hw, o
        h, c = self.init_state(feats, cond)
        tok = torch.full((images.size(0),), bos, dtype=torch.long, device=images.device)
        seqs, als = [], []
        for _ in range(max_len):
            lg, h, c, a = self.step(tok, h, c, feats)
            tok = lg.argmax(1)
            seqs.append(tok)
            als.append(a)
            if (tok == eos).all():
                break
        seqs = torch.stack(seqs, 1).tolist()
        als = torch.stack(als, 1)
        return seqs, [als[i] for i in range(len(seqs))], hw, o

    def _beam(self, feats, cond, bos, eos, max_len, k):
        h, c = self.init_state(feats, cond)
        beams = [([bos], 0.0, h, c, [])]
        done = []
        for _ in range(max_len):
            cand = []
            for seq, score, h, c, al in beams:
                if seq[-1] == eos:
                    done.append((seq, score, al))
                    continue
                lg, h2, c2, a = self.step(torch.tensor([seq[-1]], device=feats.device), h, c, feats)
                lp = F.log_softmax(lg, 1)[0]
                top = lp.topk(k)
                for v, i in zip(top.values.tolist(), top.indices.tolist()):
                    cand.append((seq + [i], score + v, h2, c2, al + [a[0]]))
            if not cand:
                break
            beams = sorted(cand, key=lambda b: b[1] / len(b[0]) ** 0.7, reverse=True)[:k]
        done += [(s, sc, al) for s, sc, _, _, al in beams]
        best = max(done, key=lambda d: d[1] / len(d[0]) ** 0.7)
        return best[0][1:], torch.stack(best[2]) if best[2] else torch.zeros(1, feats.size(1))
