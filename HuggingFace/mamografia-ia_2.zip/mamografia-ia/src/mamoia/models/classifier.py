"""Clasificador multitarea de mamografías.

  backbone CNN (timm, preentrenado en ImageNet, 1 canal)
      └── mapa de características F (B, C, h, w)  ──► (lo reutiliza el captioner LSTM y Grad-CAM)
             └── GeM pooling
                   ├── cabeza malignidad  (1 logit)      -> benigno / maligno
                   ├── cabeza BI-RADS     (7 logits)     -> categoría 0..6
                   └── cabeza densidad    (4 logits)     -> ACR A..D
"""
from __future__ import annotations

import timm
import torch
import torch.nn as nn
import torch.nn.functional as F


class GeM(nn.Module):
    """Generalized-mean pooling: entre average (p=1) y max pooling (p→∞). Útil para lesiones pequeñas."""

    def __init__(self, p=3.0, eps=1e-6):
        super().__init__()
        self.p = nn.Parameter(torch.ones(1) * p)
        self.eps = eps

    def forward(self, x):
        return F.adaptive_avg_pool2d(x.clamp(min=self.eps).pow(self.p), 1).pow(1.0 / self.p).flatten(1)


class MammoClassifier(nn.Module):
    def __init__(self, backbone="efficientnet_b0", pretrained=True, n_birads=7, n_density=4, dropout=0.3):
        super().__init__()
        self.backbone_name = backbone
        self.backbone = timm.create_model(backbone, pretrained=pretrained, in_chans=1, num_classes=0, global_pool="")
        self.n_features = self.backbone.num_features
        self.pool = GeM()
        self.drop = nn.Dropout(dropout)
        self.head_malig = nn.Linear(self.n_features, 1)
        self.head_birads = nn.Linear(self.n_features, n_birads)
        self.head_density = nn.Linear(self.n_features, n_density)

    def features(self, x):
        return self.backbone.forward_features(x)

    def forward(self, x, return_features=False):
        fmap = self.features(x)
        z = self.drop(self.pool(fmap))
        out = {"malignancy": self.head_malig(z).squeeze(1), "birads": self.head_birads(z),
               "density": self.head_density(z)}
        if return_features:
            out["fmap"] = fmap
        return out


def multitask_loss(out, batch, weights: dict, pos_weight: float = 1.0):
    """Pérdida enmascarada: ignora las etiquetas desconocidas (-1)."""
    losses = {}
    y = batch["y_malig"].to(out["malignancy"].device)
    m = y >= 0
    if m.any():
        losses["malignancy"] = F.binary_cross_entropy_with_logits(
            out["malignancy"][m], y[m], pos_weight=torch.tensor(pos_weight, device=y.device))
    for k, key in (("birads", "y_birads"), ("density", "y_density")):
        t = batch[key].to(out[k].device)
        if (t >= 0).any():
            losses[k] = F.cross_entropy(out[k], t, ignore_index=-1)
    total = sum(weights.get(k, 1.0) * v for k, v in losses.items()) if losses else out["malignancy"].sum() * 0
    return total, {k: float(v.detach()) for k, v in losses.items()}


def load_classifier(ckpt_path, map_location="cpu") -> tuple[MammoClassifier, dict]:
    ck = torch.load(ckpt_path, map_location=map_location, weights_only=False)
    a = ck["model_args"]
    model = MammoClassifier(**{**a, "pretrained": False})
    model.load_state_dict(ck["state_dict"])
    model.eval()
    return model, ck
