"""Inventario de la base de mamografías 2015 y generación de la plantilla de etiquetas.

Convenciones de nombre detectadas en DB-2015-IMG (carpeta `prueba/`):
  PPPV.jpg         paciente PPP, vista V (1..4)          ej. 0011.jpg
  PPPeSV.jpeg      paciente PPP, estudio S, vista V      ej. 208e53.jpeg
  'PPPV (2).jpg'   copias duplicadas                     -> se marcan con is_duplicate
Convenciones en DB-segmentation-2015 (resultados de la tesis):
  Paciente_PPPVV.jpeg, PPb3lcc6.jpeg (b3 = BI-RADS 3, l/r = lado, cc/mlo = proyección)

Uso:
  python -m mamoia.data.inventory --images data/raw/prueba --out data/labels/labels_template.csv
"""
from __future__ import annotations

import argparse
import hashlib
import re
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image

IMG_EXT = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp"}

RE_STUDY = re.compile(r"^(?P<pat>\d{3})e(?P<study>\d)(?P<view>[1-4])$")
RE_SIMPLE = re.compile(r"^(?P<pat>\d{3})(?P<view>[1-4])$")
RE_SEG_BIRADS = re.compile(r"^(?P<pat>\d+)b(?P<birads>\d)(?:e\d)?(?P<side>[lr])(?P<proj>cc|mlo)\d+$", re.I)

LABEL_COLUMNS = [
    # --- llenar por el equipo con el reporte del radiólogo / biopsia ---
    "birads",            # 0-6 (categoría final del radiólogo)
    "pathology",         # normal | benigno | maligno  (biopsia si existe)
    "biopsy_confirmed",  # 1 si la patología viene de biopsia, 0 si es inferida del BI-RADS
    "density",           # A | B | C | D (ACR)
    "lesion_type",       # masa | asimetria | microcalcificaciones | distorsion | ganglio | ninguna
    "lesion_shape",      # redonda | oval | irregular
    "lesion_margin",     # circunscrito | oscurecido | microlobulado | indistinto | espiculado
    "lesion_quadrant",   # CSE | CSI | CIE | CII | retroareolar | axilar
    "depth_zone",        # anterior | media | posterior (zonas de profundidad de la tesis)
    "lesion_size_mm",
    "report_text",       # texto libre del radiólogo (opcional, mejora el captioner)
    "notes",
]


def parse_name(stem: str, view_map: dict | None = None) -> dict:
    clean = re.sub(r"\s*\(\d+\)$", "", stem.replace(".jpg", ""))
    out = {"patient_id": None, "study_n": None, "view_code": None, "laterality": None,
           "projection": None, "birads_from_name": None, "name_pattern": "desconocido"}
    if m := RE_STUDY.match(clean):
        out.update(patient_id=m["pat"], study_n=int(m["study"]), view_code=m["view"], name_pattern="PPPeSV")
    elif m := RE_SIMPLE.match(clean):
        out.update(patient_id=m["pat"], study_n=1, view_code=m["view"], name_pattern="PPPV")
    elif m := RE_SEG_BIRADS.match(clean):
        out.update(patient_id=m["pat"].zfill(3), laterality=m["side"].upper(),
                   projection=m["proj"].upper(), birads_from_name=int(m["birads"]), name_pattern="PPbBsideproj")
    if out["view_code"] and view_map:
        v = view_map.get(out["view_code"], {})
        out["laterality"], out["projection"] = v.get("laterality"), v.get("projection")
    return out


def file_md5(path: Path, chunk: int = 1 << 20) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        while b := f.read(chunk):
            h.update(b)
    return h.hexdigest()


def average_hash(img: Image.Image, size: int = 16) -> str:
    g = img.convert("L").resize((size, size), Image.BILINEAR)
    px = np.asarray(g, dtype=np.float32).ravel()
    bits = "".join("1" if p > px.mean() else "0" for p in px)
    return f"{int(bits, 2):0{size * size // 4}x}"


def build_inventory(images_dir: str | Path, view_map: dict | None = None) -> pd.DataFrame:
    images_dir = Path(images_dir)
    rows = []
    for p in sorted(images_dir.rglob("*")):
        if p.suffix.lower() not in IMG_EXT or p.name.startswith("."):
            continue
        with Image.open(p) as im:
            w, h = im.size
            mode = im.mode
            ahash = average_hash(im)
        info = parse_name(p.stem, view_map)
        rows.append({"image_id": p.stem.replace(" ", "_"), "filename": str(p.relative_to(images_dir)),
                     "width": w, "height": h, "mode": mode, "md5": file_md5(p), "ahash": ahash, **info})
    df = pd.DataFrame(rows)
    # image_id único (p.ej. existen 0173.jpg y 0173.jpeg)
    dup_id = df.duplicated("image_id", keep="first")
    df.loc[dup_id, "image_id"] = df.loc[dup_id, "image_id"] + "_" + df.loc[dup_id, "filename"].str.rsplit(".", n=1).str[-1]
    # duplicados exactos (md5) o casi exactos (mismo hash perceptual)
    df["is_duplicate"] = df.duplicated("md5", keep="first") | df.duplicated("ahash", keep="first")
    df["dup_of"] = None
    first_by_hash = df.drop_duplicates("ahash").set_index("ahash")["image_id"]
    df.loc[df.is_duplicate, "dup_of"] = df.loc[df.is_duplicate, "ahash"].map(first_by_hash)
    # agrupación para separar train/val/test SIN fuga de paciente.
    # Si un estudio está duplicado bajo otro ID de paciente (p.ej. 131e* == 127e*), se fusionan grupos.
    df["group_id"] = df["patient_id"].fillna(df["image_id"])
    for i in df.index[df.is_duplicate]:
        target = df.loc[df.image_id == df.at[i, "dup_of"], "group_id"].iloc[0]
        df.loc[df.group_id == df.at[i, "group_id"], "group_id"] = target
    return df


def make_label_template(inv: pd.DataFrame) -> pd.DataFrame:
    tpl = inv[["image_id", "filename", "patient_id", "study_n", "view_code", "laterality",
               "projection", "is_duplicate", "group_id"]].copy()
    for c in LABEL_COLUMNS:
        tpl[c] = ""
    if "birads_from_name" in inv:
        tpl.loc[inv.birads_from_name.notna(), "birads"] = inv.birads_from_name.dropna().astype(int).astype(str)
    return tpl


def main():
    from mamoia.config import load_config
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--images", required=True)
    ap.add_argument("--out", default="data/labels/labels_template.csv")
    ap.add_argument("--inventory-out", default="data/labels/inventory.csv")
    args = ap.parse_args()
    cfg = load_config()
    inv = build_inventory(args.images, cfg["views"])
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    inv.to_csv(args.inventory_out, index=False)
    make_label_template(inv).to_csv(args.out, index=False, encoding="utf-8-sig")
    print(f"{len(inv)} imágenes | {inv.patient_id.nunique()} pacientes | "
          f"{int(inv.is_duplicate.sum())} duplicados | patrones: {inv.name_pattern.value_counts().to_dict()}")
    print(f"Plantilla -> {args.out}")


if __name__ == "__main__":
    main()
