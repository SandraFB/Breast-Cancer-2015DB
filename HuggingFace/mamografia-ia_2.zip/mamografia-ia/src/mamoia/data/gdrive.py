"""Descarga recursiva de una carpeta de Google Drive (incluida una carpeta COMPARTIDA contigo) desde
Colab, usando la API de Drive con tu propia sesión de Google.

  from mamoia.data.gdrive import colab_auth, download_folder
  colab_auth()
  download_folder("1V7nw-jPS-Exgji956VLryd_3kqeKzMk_", "data/dicom")

Alternativa sin API: en drive.google.com, clic derecho en la carpeta compartida → Organizar →
"Agregar acceso directo" a Mi unidad; tras drive.mount() aparecerá en /content/drive/MyDrive/...
"""
from __future__ import annotations

import io
import time
from pathlib import Path

FOLDER = "application/vnd.google-apps.folder"


def colab_auth():
    from google.colab import auth  # type: ignore
    auth.authenticate_user()


def _service():
    from googleapiclient.discovery import build  # preinstalado en Colab
    return build("drive", "v3", cache_discovery=False)


def list_children(svc, folder_id: str) -> list[dict]:
    out, token = [], None
    while True:
        r = svc.files().list(q=f"'{folder_id}' in parents and trashed = false", pageSize=1000, pageToken=token,
                             fields="nextPageToken, files(id, name, mimeType, size)",
                             supportsAllDrives=True, includeItemsFromAllDrives=True).execute()
        out += r.get("files", [])
        token = r.get("nextPageToken")
        if not token:
            return out


def download_folder(folder_id: str, dest: str | Path, max_files: int | None = None, verbose=True) -> int:
    """Replica la carpeta en `dest`. Omite archivos ya descargados con el mismo tamaño (reanudable)."""
    from googleapiclient.http import MediaIoBaseDownload
    svc, dest, n = _service(), Path(dest), 0
    stack = [(folder_id, dest)]
    while stack:
        fid, d = stack.pop()
        d.mkdir(parents=True, exist_ok=True)
        for f in sorted(list_children(svc, fid), key=lambda x: x["name"]):
            target = d / f["name"]
            if f["mimeType"] == FOLDER:
                stack.append((f["id"], target))
                continue
            if f["mimeType"].startswith("application/vnd.google-apps"):
                continue                                   # Docs/Sheets nativos: no son imágenes
            if target.exists() and str(target.stat().st_size) == f.get("size"):
                n += 1
                continue
            for attempt in range(4):
                try:
                    buf = io.BytesIO()
                    dl = MediaIoBaseDownload(buf, svc.files().get_media(fileId=f["id"], supportsAllDrives=True))
                    done = False
                    while not done:
                        _, done = dl.next_chunk()
                    target.write_bytes(buf.getvalue())
                    break
                except Exception as e:  # cuota/red: reintento con espera
                    if attempt == 3:
                        print("  ✗", target, e)
                    time.sleep(2 ** attempt)
            n += 1
            if verbose and n % 50 == 0:
                print(f"  {n} archivos…")
            if max_files and n >= max_files:
                return n
    if verbose:
        print(f"{n} archivos en {dest}")
    return n
