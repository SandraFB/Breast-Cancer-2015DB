"""Datasets de PyTorch para clasificación y para captioning."""
from __future__ import annotations

import hashlib
import random
from pathlib import Path

import cv2
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset

from mamoia.data.preprocess import preprocess, read_gray
from mamoia.text.report_templates import describe


def load_image(row, img_size, cache_dir: str | Path | None = None) -> np.ndarray:
    """Lee la imagen preprocesada; si viene cruda (dataset público) la preprocesa y la cachea."""
    H, W = img_size
    if str(row.get("preprocessed", "")) in ("True", "true", "1") or row.get("preprocessed") is True:
        img = cv2.imread(row["img_path"], cv2.IMREAD_GRAYSCALE)
        if img is None:
            raise FileNotFoundError(row["img_path"])
        if img.shape != (H, W):
            img = cv2.resize(img, (W, H), interpolation=cv2.INTER_AREA)
        return img
    if cache_dir:
        key = hashlib.md5(f"{row['img_path']}{H}{W}".encode()).hexdigest()
        cp = Path(cache_dir) / f"{key}.png"
        if cp.exists():
            return cv2.imread(str(cp), cv2.IMREAD_GRAYSCALE)
    img, _, _ = preprocess(read_gray(row["img_path"]), out_hw=(H, W))
    if cache_dir:
        Path(cache_dir).mkdir(parents=True, exist_ok=True)
        cv2.imwrite(str(cp), img)
    return img


def augment(img: np.ndarray, rng: random.Random) -> np.ndarray:
    """Aumentos suaves y anatómicamente plausibles (no se voltea horizontal: la orientación ya
    está normalizada)."""
    H, W = img.shape
    if rng.random() < 0.5:
        img = img[::-1].copy()                                # volteo vertical (CC/MLO lo toleran)
    ang, sc = rng.uniform(-10, 10), rng.uniform(0.9, 1.1)
    M = cv2.getRotationMatrix2D((W * 0.1, H / 2), ang, sc)
    img = cv2.warpAffine(img, M, (W, H), borderValue=0)
    if rng.random() < 0.8:
        g = rng.uniform(0.8, 1.25)                            # gamma: simula distintos equipos
        img = np.clip(255 * (img / 255.0) ** g, 0, 255).astype(np.uint8)
    if rng.random() < 0.3:
        img = cv2.GaussianBlur(img, (3, 3), 0)
    return img


def to_tensor(img: np.ndarray) -> torch.Tensor:
    t = torch.from_numpy(np.ascontiguousarray(img)).float().div(255.0)
    return ((t - 0.5) / 0.25).unsqueeze(0)   # 1 x H x W


class MammoDataset(Dataset):
    def __init__(self, df: pd.DataFrame, img_size=(1024, 512), train=False, cache_dir=None, seed=0):
        self.df = df.reset_index(drop=True)
        self.img_size = tuple(img_size)
        self.train = train
        self.cache_dir = cache_dir
        self.rng = random.Random(seed)

    def __len__(self):
        return len(self.df)

    def _img(self, i):
        row = self.df.iloc[i].to_dict()
        img = load_image(row, self.img_size, self.cache_dir)
        if self.train:
            img = augment(img, self.rng)
        return to_tensor(img), row

    def __getitem__(self, i):
        x, row = self._img(i)
        return {"image": x, "y_malig": torch.tensor(float(row.get("y_malig", -1))),
                "y_birads": torch.tensor(int(row.get("y_birads", -1))),
                "y_density": torch.tensor(int(row.get("y_density", -1))),
                "image_id": row["image_id"]}


class CaptionDataset(MammoDataset):
    """Devuelve imagen + secuencia de tokens del reporte (real o generado por plantilla)."""

    def __init__(self, df, vocab, max_len=60, paraphrase=True, **kw):
        super().__init__(df, **kw)
        self.vocab, self.max_len, self.paraphrase = vocab, max_len, paraphrase

    def text(self, i, variant=None):
        row = self.df.iloc[i].to_dict()
        v = (self.train and self.paraphrase) if variant is None else variant
        return describe(row, variant=v, rng=self.rng, include_view=False)

    def __getitem__(self, i):
        item = super().__getitem__(i)
        item["tokens"] = torch.tensor(self.vocab.encode(self.text(i), self.max_len))
        item["reference"] = self.text(i, variant=False)
        return item
