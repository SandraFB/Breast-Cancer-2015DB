"""Lectura de mastografías DICOM, extracción de vista (lateralidad/proyección) y conversión a PNG
anonimizado, listo para el pipeline.

  python -m mamoia.data.dicom_io --root data/dicom --out data/dicom_proc --inventory data/labels/inventory_dicom.csv

Estructura esperada (la de la carpeta de Drive):  root/Paciente_008/00000001 (sin extensión), ...
Detalles importantes de DICOM en mastografía:
  * PhotometricInterpretation MONOCHROME1 = blanco es "vacío" -> se invierte para que el tejido denso
    sea claro (convención del pipeline).
  * Se aplican Modality LUT y VOI LUT/ventana del equipo; si no existen, ventana por percentiles.
  * Lateralidad: (0020,0062) ImageLaterality o (0020,0060) Laterality o texto de la serie.
  * Proyección: (0018,5101) ViewPosition, ViewCodeSequence o texto ("RCC", "L MLO", "OML"...).
  * Magnificaciones / conos de compresión se marcan como no estándar (is_standard_view=False).
PRIVACIDAD: nunca se copian nombre, ID, fecha de nacimiento ni institución; sólo una lista blanca de
metadatos técnicos. Los PNG sólo contienen la mama (el preprocesamiento borra los rótulos).
"""
from __future__ import annotations

import argparse
import re
from pathlib import Path

import cv2
import numpy as np
import pandas as pd

SAFE_TAGS = ["Modality", "Manufacturer", "ManufacturerModelName", "PhotometricInterpretation", "BitsStored",
             "Rows", "Columns", "PixelSpacing", "ImagerPixelSpacing", "ViewPosition", "ImageLaterality",
             "Laterality", "PresentationIntentType", "BodyPartExamined", "SeriesDescription", "ProtocolName",
             "ImageType", "ViewCodeSequence", "ViewModifierCodeSequence"]
_PROJ_WORDS = [("MLO", r"\b(mlo|oml|oblicu\w*|medio ?lateral ?obl\w*|medio-?lateral oblique)\b"),
               ("CC", r"\b(cc|cranio-?caudal|craneo-?caudal|cefalo-?caudal)\b"),
               ("ML", r"\b(ml|medio-?lateral|lateral)\b"),
               ("LM", r"\b(lm|latero-?medial)\b"),
               ("XCCL", r"\bxccl\b")]
_NONSTD = r"(mag|magnif|spot|cono|compresion focal|rotad|rolled|implant|eklund|\bid\b)"


def is_dicom(path: Path) -> bool:
    try:
        with open(path, "rb") as f:
            f.seek(128)
            return f.read(4) == b"DICM"
    except OSError:
        return False


def _text_tags(ds) -> str:
    parts = []
    for k in ("SeriesDescription", "ProtocolName", "ImageComments", "AcquisitionDeviceProcessingDescription",
              "StudyDescription"):
        v = ds.get(k)
        if v:
            parts.append(str(v))
    for seq in ("ViewCodeSequence", "ViewModifierCodeSequence"):
        for it in ds.get(seq, []) or []:
            parts.append(str(it.get("CodeMeaning", "")))
    return " ".join(parts).lower()


def view_from_tags(ds) -> dict:
    txt = _text_tags(ds)
    lat = str(ds.get("ImageLaterality", "") or ds.get("Laterality", "") or "").upper()
    lat_src = "tag" if lat in ("L", "R") else None
    if not lat_src:
        m = re.search(r"\b([lr])\s*-?\s*(cc|mlo|ml|lm|xccl)\b", txt) or re.search(r"\b(left|right|izq\w*|der\w*)\b", txt)
        if m:
            g = m.group(1)
            lat = "L" if g.startswith(("l", "i")) else "R"
            lat_src = "texto"
    proj = str(ds.get("ViewPosition", "") or "").upper().strip()
    proj_src = "tag" if proj else None
    if not proj and (m := re.search(r"\b[lr]\s*-?\s*(cc|mlo|ml|lm|xccl)\b", txt)):
        proj, proj_src = m.group(1).upper(), "texto"
    if not proj:
        for name, pat in _PROJ_WORDS:
            if re.search(pat, txt.replace("_", " ")):
                proj, proj_src = name, "texto"
                break
    if proj in ("ML", "LM", "XCCL"):
        std = False
    else:
        std = proj in ("CC", "MLO") and not re.search(_NONSTD, txt)
    return {"laterality": lat if lat in ("L", "R") else "U", "lat_source": lat_src or "desconocida",
            "projection": proj if proj in ("CC", "MLO", "ML", "LM", "XCCL") else "U",
            "proj_source": proj_src or "desconocida", "is_standard_view": bool(std), "view_text": txt[:120]}


def dicom_to_uint8(ds) -> np.ndarray:
    try:                                                       # pydicom >= 3
        from pydicom.pixels import apply_modality_lut, apply_voi_lut
    except ImportError:                                        # pydicom 2.x
        from pydicom.pixel_data_handlers.util import apply_modality_lut, apply_voi_lut
    arr = ds.pixel_array
    if arr.ndim == 3 and arr.shape[-1] in (3, 4):            # captura secundaria en color
        arr = cv2.cvtColor(arr.astype(np.uint8), cv2.COLOR_RGB2GRAY)
    elif arr.ndim == 3:                                       # multi-frame (tomosíntesis): frame central
        arr = arr[arr.shape[0] // 2]
    arr = apply_modality_lut(arr, ds)
    has_voi = ("WindowCenter" in ds and "WindowWidth" in ds) or "VOILUTSequence" in ds
    if has_voi:
        try:
            arr = apply_voi_lut(arr, ds, index=0)
        except Exception:
            has_voi = False
    arr = arr.astype(np.float32)
    lo, hi = (arr.min(), arr.max()) if has_voi else np.percentile(arr, (0.5, 99.8))
    img = np.clip((arr - lo) / max(hi - lo, 1e-6), 0, 1)
    if str(ds.get("PhotometricInterpretation", "")).upper() == "MONOCHROME1":
        img = 1.0 - img
    return (img * 255).astype(np.uint8)


def read_dicom(path) -> tuple[np.ndarray, dict]:
    import pydicom
    ds = pydicom.dcmread(str(path), force=True)
    if "PixelData" not in ds:
        raise ValueError("sin PixelData (¿reporte estructurado o DICOMDIR?)")
    img = dicom_to_uint8(ds)
    meta = {k: (str(ds.get(k)) if ds.get(k) is not None else None) for k in SAFE_TAGS
            if k not in ("ViewCodeSequence", "ViewModifierCodeSequence")}
    meta.update(view_from_tags(ds))
    if str(ds.get("Modality", "MG")).upper() in ("US", "OT", "SC", "SR", "PR"):
        meta["is_standard_view"] = False                       # ultrasonido / capturas: no son mastografías
        meta["no_mamografia"] = True
    return img, meta


def projection_features(img: np.ndarray, m: np.ndarray) -> list[float]:
    rows, cols = np.where(m.any(1))[0], np.where(m.any(0))[0]
    y0, y1 = rows.min(), rows.max()
    h, W = max(1, y1 - y0), cols.max() - cols.min() + 1
    w = lambda a, b: m[y0 + int(a * h): y0 + int(b * h)].sum(1).mean()  # noqa: E731
    body = img[m].astype(float)
    c, cm = img[y0:y0 + h // 5, :max(2, W // 5)], m[y0:y0 + h // 5, :max(2, W // 5)]
    yy, xx = np.nonzero(m)
    far = yy[xx >= np.percentile(xx, 98)].mean()
    return [w(0.05, 0.2) / max(1, w(0.8, 0.95)), c[cm].mean() / body.mean() if cm.any() else 0.0,
            cm.mean(), (yy.mean() - y0) / h, (far - y0) / h, W / h]


# regresión logística ajustada con 500 imágenes de la base 2015 con vista conocida (exactitud CV ≈ 0.91)
_PROJ_COEF = np.array([0.199, 7.551, 3.036, -1.013, 1.279, -0.56])
_PROJ_B = -11.943


def guess_projection(img_pre: np.ndarray, mask: np.ndarray) -> tuple[str, float]:
    """Heurística para imágenes sin etiqueta de vista (imagen ya orientada con el tórax a la izq.):
    el músculo pectoral brillante arriba y la forma asimétrica de la mama delatan la MLO.
    Devuelve (proyección, probabilidad de MLO). Revisar manualmente los casos dudosos."""
    if not mask.any():
        return "U", 0.5
    z = float(np.dot(_PROJ_COEF, projection_features(img_pre, mask)) + _PROJ_B)
    p = 1 / (1 + np.exp(-z))
    return ("MLO" if p >= 0.5 else "CC"), p


def find_patient_id(path: Path, root: Path) -> str:
    for part in path.relative_to(root).parts:
        if m := re.match(r"(?i)paciente[_\s-]*(\d+)", part):
            return f"Paciente_{int(m.group(1)):03d}"
    return path.relative_to(root).parts[0]


def ingest_dicom_tree(root, out_dir, cfg_pre: dict | None = None, guess_missing_projection=True,
                      verbose=True) -> pd.DataFrame:
    """Convierte todos los DICOM de `root` a PNG preprocesados + inventario (una fila por imagen)."""
    from tqdm.auto import tqdm

    from mamoia.data.preprocess import preprocess
    root, out_dir = Path(root), Path(out_dir)
    cfg_pre = cfg_pre or {"out_height": 1024, "out_width": 512, "clahe_clip": 2.0, "clahe_tiles": 8}
    for sub in ("img", "mask", "thumb"):
        (out_dir / sub).mkdir(parents=True, exist_ok=True)
    files = [p for p in sorted(root.rglob("*")) if p.is_file() and p.name.upper() != "DICOMDIR"
             and (is_dicom(p) or p.suffix.lower() in (".dcm", ".dicom"))]
    rows, errors = [], []
    for p in tqdm(files, desc="DICOM", disable=not verbose):
        try:
            raw, meta = read_dicom(p)
        except Exception as e:
            errors.append({"file": str(p.relative_to(root)), "error": f"{type(e).__name__}: {e}"[:200]})
            continue
        pid = find_patient_id(p, root)
        # el DICOM ya viene en positivo (MONOCHROME1 se invirtió): no invertir de nuevo
        img, mask, pm = preprocess(raw, out_hw=(cfg_pre["out_height"], cfg_pre["out_width"]),
                                   invert_if_negative=False, flip_to_left=True,
                                   clahe_clip=cfg_pre["clahe_clip"], clahe_tiles=cfg_pre["clahe_tiles"])
        if meta["projection"] == "U" and guess_missing_projection:
            proj, p_mlo = guess_projection(img, mask)
            meta.update(projection=proj, proj_source=f"heuristica(p_mlo={p_mlo:.2f})",
                        is_standard_view=not meta.get("no_mamografia", False))
        iid = f"{pid}_{meta['laterality']}{meta['projection']}_{p.stem}"
        cv2.imwrite(str(out_dir / "img" / f"{iid}.png"), img)
        cv2.imwrite(str(out_dir / "mask" / f"{iid}.png"), mask.astype(np.uint8) * 255)
        cv2.imwrite(str(out_dir / "thumb" / f"{iid}.jpg"), cv2.resize(img, (128, 256)))
        rows.append({"image_id": iid, "patient_id": pid, "group_id": pid, "dicom_file": str(p.relative_to(root)),
                     "img_path": str(out_dir / "img" / f"{iid}.png"), "preprocessed": True,
                     "flipped": pm.flipped, "breast_area_frac": round(pm.breast_area_frac, 3),
                     "warnings": ";".join(pm.warnings), **meta})
    inv = pd.DataFrame(rows)
    if len(inv):
        inv["view_rank"] = inv.groupby(["patient_id", "laterality", "projection"]).cumcount()
    if errors:
        pd.DataFrame(errors).to_csv(out_dir / "errores_dicom.csv", index=False)
        if verbose:
            print(f"{len(errors)} archivos no se pudieron leer -> {out_dir / 'errores_dicom.csv'}")
    return inv


def fill_missing_views(inv: pd.DataFrame) -> pd.DataFrame:
    """Si a una paciente le falta exactamente una vista estándar y tiene una imagen sin lateralidad de
    esa proyección, se asigna por eliminación (lat_source='eliminacion')."""
    inv = inv.copy()
    # 1) Lateralidad por orientación: dentro de un mismo equipo, la mama izquierda y la derecha se
    #    adquieren con el tórax en lados opuestos de la imagen. Si en las imágenes CON etiqueta la
    #    relación 'volteada <-> lateralidad' se cumple en ≥ 95 %, se aplica a las que no tienen etiqueta.
    known = inv[inv.laterality.isin(["L", "R"]) & (inv.lat_source == "tag")]
    if len(known) >= 8 and (inv.laterality == "U").any():
        for manu, g in inv.groupby(inv.get("Manufacturer", pd.Series("?", index=inv.index)).fillna("?")):
            k = known[known.index.isin(g.index)]
            if len(k) < 8:
                continue
            agree = ((k.flipped.astype(bool)) == (k.laterality == "R")).mean()
            if max(agree, 1 - agree) >= 0.95:
                r_when_flipped = agree >= 0.5
                for i in g.index[g.laterality == "U"]:
                    lat = "R" if bool(inv.at[i, "flipped"]) == r_when_flipped else "L"
                    inv.loc[i, ["laterality", "lat_source"]] = [lat, f"orientacion({max(agree, 1 - agree):.2f})"]
                    inv.loc[i, "image_id"] = inv.loc[i, "image_id"].replace("_U", f"_{lat}", 1)
    std = {("L", "CC"), ("R", "CC"), ("L", "MLO"), ("R", "MLO")}
    for pid, g in inv.groupby("patient_id"):
        unk = g[g.laterality == "U"]
        if len(unk) != 1:
            continue
        have = set(zip(g.laterality, g.projection)) & std
        missing = [v for v in std - have if v[1] == unk.projection.iloc[0]]
        if len(missing) == 1:
            i = unk.index[0]
            inv.loc[i, ["laterality", "lat_source"]] = [missing[0][0], "eliminacion"]
            inv.loc[i, "image_id"] = inv.loc[i, "image_id"].replace("_U", f"_{missing[0][0]}", 1)
    return inv


def main():
    from mamoia.config import load_config
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--root", required=True)
    ap.add_argument("--out", default="data/dicom_proc")
    ap.add_argument("--inventory", default="data/labels/inventory_dicom.csv")
    a = ap.parse_args()
    inv = fill_missing_views(ingest_dicom_tree(a.root, a.out, load_config()["preprocess"]))
    Path(a.inventory).parent.mkdir(parents=True, exist_ok=True)
    inv.to_csv(a.inventory, index=False)
    print(inv.groupby(["laterality", "projection"]).size())
    print(f"{len(inv)} imágenes de {inv.patient_id.nunique()} pacientes -> {a.inventory}")


if __name__ == "__main__":
    main()
