"""Preprocesamiento y ANONIMIZACIÓN de mamografías.

Pasos (inspirados en el Capítulo 4 de la tesis):
  1. Lectura en escala de grises (8 o 16 bits).
  2. Detección de negativo e inversión (la base 2015 tiene fondo blanco).
  3. Segmentación de la mama = componente conexa de mayor área (recorta etiquetas,
     marcadores y NOMBRES de paciente impresos en la placa -> anonimización).
  4. Orientación: todas las mamas con el tórax a la izquierda (se registra si se volteó).
  5. CLAHE (ecualización adaptativa del histograma).
  6. Redimensionado con relleno para conservar la proporción.

Uso:
  python -m mamoia.data.preprocess --images data/raw/prueba --out data/processed
"""
from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass, field
from pathlib import Path

import cv2
import numpy as np
from scipy import ndimage as ndi


@dataclass
class PreprocessMeta:
    inverted: bool = False
    flipped: bool = False
    bbox: tuple[int, int, int, int] = (0, 0, 0, 0)   # y0, y1, x0, x1 en la imagen original
    orig_shape: tuple[int, int] = (0, 0)
    scale: float = 1.0
    pad: tuple[int, int] = (0, 0)                    # pad_y, pad_x tras escalar
    breast_area_frac: float = 0.0
    warnings: list[str] = field(default_factory=list)


def read_gray(path: str | Path) -> np.ndarray:
    img = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    if img is None:
        raise FileNotFoundError(path)
    if img.ndim == 3:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    if img.dtype != np.uint8:  # 16 bits -> 8 bits con ventana de percentiles
        lo, hi = np.percentile(img, (0.5, 99.5))
        img = np.clip((img - lo) / max(hi - lo, 1) * 255, 0, 255).astype(np.uint8)
    return img


def is_negative(img: np.ndarray) -> bool:
    """Una mamografía 'normal' tiene fondo negro. Si el borde es claro, está en negativo."""
    h, w = img.shape
    b = max(4, min(h, w) // 50)
    border = np.concatenate([img[:b].ravel(), img[-b:].ravel(), img[:, :b].ravel(), img[:, -b:].ravel()])
    return np.median(border) > 127


def breast_mask(img: np.ndarray) -> np.ndarray:
    """Máscara binaria de la mama: Otsu + componente conexa más grande + relleno de huecos."""
    small_scale = 512 / max(img.shape)
    small = cv2.resize(img, None, fx=small_scale, fy=small_scale, interpolation=cv2.INTER_AREA)
    blur = cv2.GaussianBlur(small, (5, 5), 0)
    # umbral relativo al fondo: moda del histograma (fondo) + 10 % del rango dinámico.
    # Es más permisivo que Otsu y conserva piel/grasa en mamas poco contrastadas.
    hist = np.bincount(blur.ravel(), minlength=256)
    bg = int(np.argmax(hist[:128]))
    thr = bg + 0.10 * (np.percentile(blur, 99) - bg)
    bw = (blur > max(thr, bg + 6)).astype(np.uint8)
    bw = cv2.morphologyEx(bw, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    # los marcos de la placa tocan 3-4 bordes; se elimina una franja muy delgada del contorno
    # superior/inferior y del lado del pezón para separarlos de la mama
    b = max(2, round(0.015 * max(bw.shape)))
    bw[:b], bw[-b:] = 0, 0
    n, lab, stats, _ = cv2.connectedComponentsWithStats(bw, 8)
    if n <= 1:
        return np.ones_like(img, dtype=bool)
    H, W = bw.shape
    areas = stats[1:, cv2.CC_STAT_AREA].astype(float)
    spans_all = (stats[1:, cv2.CC_STAT_WIDTH] > 0.97 * W) & (stats[1:, cv2.CC_STAT_HEIGHT] > 0.95 * H)
    fill = areas / (stats[1:, cv2.CC_STAT_WIDTH] * stats[1:, cv2.CC_STAT_HEIGHT])
    areas[spans_all & (fill < 0.5)] *= 0.01        # marco hueco -> descartado
    k = 1 + int(np.argmax(areas))
    m = ndi.binary_fill_holes(lab == k)
    m = cv2.resize(m.astype(np.uint8), (img.shape[1], img.shape[0]), interpolation=cv2.INTER_NEAREST)
    return m.astype(bool)


def chest_on_left(mask: np.ndarray) -> bool:
    h, w = mask.shape
    return mask[:, : w // 2].sum() >= mask[:, w // 2:].sum()


def apply_clahe(img: np.ndarray, clip: float = 2.0, tiles: int = 8) -> np.ndarray:
    return cv2.createCLAHE(clipLimit=clip, tileGridSize=(tiles, tiles)).apply(img)


def resize_pad(img: np.ndarray, out_hw: tuple[int, int], interp=cv2.INTER_AREA):
    H, W = out_hw
    h, w = img.shape[:2]
    s = min(H / h, W / w)
    nh, nw = max(1, round(h * s)), max(1, round(w * s))
    r = cv2.resize(img, (nw, nh), interpolation=interp)
    out = np.zeros((H, W), dtype=img.dtype)
    py, px = (H - nh) // 2, 0  # pegado a la izquierda (tórax)
    out[py:py + nh, px:px + nw] = r
    return out, s, (py, px)


def preprocess(img: np.ndarray, out_hw=(1024, 512), invert_if_negative=True, flip_to_left=True,
               clahe_clip=2.0, clahe_tiles=8) -> tuple[np.ndarray, np.ndarray, PreprocessMeta]:
    meta = PreprocessMeta(orig_shape=img.shape)
    if invert_if_negative and is_negative(img):
        img = 255 - img
        meta.inverted = True
    mask = breast_mask(img)
    meta.breast_area_frac = float(mask.mean())
    if meta.breast_area_frac < 0.05:
        meta.warnings.append("mama_muy_pequena_o_segmentacion_fallida")
    ys, xs = np.where(mask)
    y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
    meta.bbox = (int(y0), int(y1), int(x0), int(x1))
    crop = np.where(mask, img, 0)[y0:y1, x0:x1]          # anonimiza: todo fuera de la mama = 0
    cmask = mask[y0:y1, x0:x1]
    if flip_to_left and not chest_on_left(cmask):
        crop, cmask = crop[:, ::-1], cmask[:, ::-1]
        meta.flipped = True
    crop = apply_clahe(np.ascontiguousarray(crop), clahe_clip, clahe_tiles)
    crop[~cmask] = 0
    out, s, pad = resize_pad(crop, out_hw)
    mout, _, _ = resize_pad(cmask.astype(np.uint8) * 255, out_hw, cv2.INTER_NEAREST)
    out[mout == 0] = 0                                    # garantiza que nada fuera de la mama sobreviva
    meta.scale, meta.pad = float(s), (int(pad[0]), int(pad[1]))
    return out, mout > 0, meta


def preprocess_file(path, cfg_pre: dict):
    return preprocess(read_gray(path), out_hw=(cfg_pre["out_height"], cfg_pre["out_width"]),
                      invert_if_negative=cfg_pre["invert_if_negative"], flip_to_left=cfg_pre["flip_to_left"],
                      clahe_clip=cfg_pre["clahe_clip"], clahe_tiles=cfg_pre["clahe_tiles"])


def main():
    from tqdm import tqdm

    from mamoia.config import load_config
    from mamoia.data.inventory import IMG_EXT
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--images", required=True)
    ap.add_argument("--out", default="data/processed")
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()
    cfg = load_config()
    out = Path(args.out)
    (out / "img").mkdir(parents=True, exist_ok=True)
    (out / "mask").mkdir(parents=True, exist_ok=True)
    files = sorted(p for p in Path(args.images).rglob("*") if p.suffix.lower() in IMG_EXT)
    if args.limit:
        files = files[: args.limit]
    metas = {}
    seen = set()
    for p in tqdm(files, desc="preprocesando", mininterval=5):
        iid = p.stem.replace(" ", "_")
        if iid in seen:
            iid = f"{iid}_{p.suffix.lstrip('.')}"
        seen.add(iid)
        img, mask, meta = preprocess_file(p, cfg["preprocess"])
        cv2.imwrite(str(out / "img" / f"{iid}.png"), img)
        cv2.imwrite(str(out / "mask" / f"{iid}.png"), mask.astype(np.uint8) * 255)
        metas[iid] = asdict(meta)
    (out / "preprocess_meta.json").write_text(json.dumps(metas, indent=1))
    print(f"{len(metas)} imágenes -> {out}")


if __name__ == "__main__":
    main()
