"""Adaptadores para datasets públicos con patología confirmada (para preentrenar).

CBIS-DDSM (versión JPEG de Kaggle: `awsaf49/cbis-ddsm-breast-cancer-image-dataset`)
  En Colab:
      import kagglehub
      root = kagglehub.dataset_download("awsaf49/cbis-ddsm-breast-cancer-image-dataset")
  Estructura esperada:
      root/csv/mass_case_description_{train,test}_set.csv
      root/csv/calc_case_description_{train,test}_set.csv
      root/jpeg/<SeriesInstanceUID>/*.jpg
Otros (requieren registro): VinDr-Mammo (PhysioNet, BI-RADS + densidad), INbreast, CMMD.
"""
from __future__ import annotations

from pathlib import Path

import pandas as pd

from mamoia.data.labels import build_targets

SHAPE = {"ROUND": "redonda", "OVAL": "oval", "IRREGULAR": "irregular", "LOBULATED": "oval",
         "ARCHITECTURAL_DISTORTION": "irregular"}
MARGIN = {"CIRCUMSCRIBED": "circunscrito", "OBSCURED": "oscurecido", "MICROLOBULATED": "microlobulado",
          "ILL_DEFINED": "indistinto", "SPICULATED": "espiculado"}


def _first(v: str, table: dict):
    if not isinstance(v, str):
        return ""
    for k in v.split("-"):
        if k in table:
            return table[k]
    return ""


def load_cbis_ddsm(root: str | Path, max_images: int | None = None) -> pd.DataFrame:
    root = Path(root)
    csv_dir = root / "csv"
    jpeg_dir = root / "jpeg"
    # índice: carpeta (SeriesInstanceUID) -> jpg más grande (= mamografía completa)
    series = {}
    for d in jpeg_dir.iterdir():
        if d.is_dir():
            jpgs = sorted(d.glob("*.jpg"), key=lambda p: p.stat().st_size, reverse=True)
            if jpgs:
                series[d.name] = jpgs[0]
    rows = []
    for kind in ("mass", "calc"):
        for part in ("train", "test"):
            f = csv_dir / f"{kind}_case_description_{part}_set.csv"
            if not f.exists():
                continue
            df = pd.read_csv(f)
            for _, r in df.iterrows():
                uid = str(r["image file path"]).strip().split("/")[-2]
                if uid not in series:
                    continue
                rows.append({
                    "image_id": f"cbis_{r['patient_id']}_{r['left or right breast']}_{r['image view']}",
                    "img_path": str(series[uid]), "preprocessed": False, "source": "cbis_ddsm",
                    "group_id": r["patient_id"], "official_split": part,
                    "laterality": "L" if r["left or right breast"] == "LEFT" else "R",
                    "projection": r["image view"],
                    "density": str(r.get("breast density", r.get("breast_density", ""))),
                    "birads": str(r["assessment"]),
                    "pathology": "maligno" if r["pathology"] == "MALIGNANT" else "benigno",
                    "biopsy_confirmed": "1",
                    "lesion_type": "masa" if kind == "mass" else "microcalcificaciones",
                    "lesion_shape": _first(r.get("mass shape", ""), SHAPE) if kind == "mass" else "",
                    "lesion_margin": _first(r.get("mass margins", ""), MARGIN) if kind == "mass" else "",
                    "subtlety": r.get("subtlety", ""),
                })
    out = pd.DataFrame(rows)
    if out.empty:
        raise FileNotFoundError(f"No se encontraron imágenes CBIS-DDSM en {root}")
    # una mamografía puede tener varias lesiones: nos quedamos con la más grave por imagen
    out["_rank"] = out.pathology.eq("maligno").astype(int) * 10 + pd.to_numeric(out.birads, errors="coerce").fillna(0)
    out = out.sort_values("_rank", ascending=False).drop_duplicates("image_id").drop(columns="_rank")
    if max_images:
        out = out.sample(min(max_images, len(out)), random_state=0)
    return build_targets(out.reset_index(drop=True))
