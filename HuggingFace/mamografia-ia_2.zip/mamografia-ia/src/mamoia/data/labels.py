"""Lectura de etiquetas y construcción de objetivos de entrenamiento.

Objetivos (todos opcionales por imagen; -1 = desconocido, se enmascara en la pérdida):
  y_malig   : 1 maligno / 0 benigno o normal
  y_birads  : 0..6
  y_density : 0..3 (A..D)

Regla de etiqueta para benigno/maligno (columna `label_source`):
  * 'biopsia'  -> pathology con biopsy_confirmed=1                     (mejor evidencia)
  * 'patologia'-> pathology sin confirmación por biopsia
  * 'birads'   -> proxy: BI-RADS 4-6 => 1 ; BI-RADS 1-2 => 0 ; BI-RADS 3 => 0 si birads3_as_benign
Documenten SIEMPRE en el reporte del proyecto qué proporción viene de cada fuente.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedGroupKFold

DENS = {"A": 0, "B": 1, "C": 2, "D": 3, "1": 0, "2": 1, "3": 2, "4": 3}


def _num(x):
    try:
        return int(float(x))
    except (TypeError, ValueError):
        return -1


def build_targets(df: pd.DataFrame, birads3_as_benign: bool = True) -> pd.DataFrame:
    df = df.copy()
    path = df.get("pathology", pd.Series([""] * len(df))).fillna("").astype(str).str.lower().str.strip()
    biopsy = df.get("biopsy_confirmed", pd.Series([""] * len(df))).fillna("").astype(str).isin(["1", "1.0", "True", "true"])
    birads = df.get("birads", pd.Series([np.nan] * len(df))).map(_num)
    y = np.full(len(df), -1)
    src = np.array([""] * len(df), dtype=object)
    pm = path.map({"maligno": 1, "malignant": 1, "benigno": 0, "benign": 0, "benign_without_callback": 0,
                   "normal": 0}).fillna(-1).astype(int).values
    has_p = pm >= 0
    y[has_p] = pm[has_p]
    src[has_p] = np.where(biopsy[has_p], "biopsia", "patologia")
    b = birads.values
    proxy = (~has_p) & (b >= 0)
    y[proxy & (b >= 4)] = 1
    y[proxy & np.isin(b, [1, 2])] = 0
    if birads3_as_benign:
        y[proxy & (b == 3)] = 0
    src[proxy & (y >= 0)] = "birads"
    df["y_malig"] = y
    df["label_source"] = src
    df["y_birads"] = np.where((b >= 0) & (b <= 6), b, -1)
    dens = df.get("density", pd.Series([""] * len(df))).fillna("").astype(str).str.upper().str.strip()
    df["y_density"] = dens.map(DENS).fillna(-1).astype(int)
    return df


def split_by_group(df: pd.DataFrame, val_frac=0.15, test_frac=0.15, seed=42, group_col="group_id",
                   strat_col="y_malig") -> pd.DataFrame:
    """Divide train/val/test SIN que un mismo paciente aparezca en dos particiones."""
    df = df.copy()
    df["split"] = "train"
    n_folds = max(2, round(1 / max(test_frac, 1e-3)))
    strat = df[strat_col].astype(str) if strat_col in df else pd.Series("0", index=df.index)
    groups = df[group_col].astype(str)
    sgkf = StratifiedGroupKFold(n_splits=n_folds, shuffle=True, random_state=seed)
    _, test_idx = next(sgkf.split(df, strat, groups))
    df.iloc[test_idx, df.columns.get_loc("split")] = "test"
    rest = df[df.split == "train"]
    n_folds_v = max(2, round((1 - test_frac) / max(val_frac, 1e-3)))
    sgkf = StratifiedGroupKFold(n_splits=n_folds_v, shuffle=True, random_state=seed + 1)
    _, val_idx = next(sgkf.split(rest, strat[rest.index], groups[rest.index]))
    df.loc[rest.index[val_idx], "split"] = "val"
    return df


def load_local_labels(labels_csv, processed_dir, drop_duplicates=True) -> pd.DataFrame:
    """Une la plantilla llenada con las imágenes preprocesadas."""
    from pathlib import Path
    df = pd.read_csv(labels_csv, dtype=str, encoding="utf-8-sig").fillna("")
    if drop_duplicates and "is_duplicate" in df:
        df = df[~df.is_duplicate.isin(["True", "true", "1"])]
    df["img_path"] = [str(Path(processed_dir) / "img" / f"{i}.png") for i in df.image_id]
    df["preprocessed"] = True
    df["source"] = "local_2015"
    return build_targets(df)


def kfold_split(df: pd.DataFrame, n_folds: int, fold: int, val_frac=0.15, seed=42,
                group_col="group_id", strat_col="y_malig") -> pd.DataFrame:
    """Validación cruzada por PACIENTE: fold k = test; del resto se aparta `val_frac` para validación
    (selección de época y umbral). Con 119 pacientes es preferible a una sola partición."""
    df = df.copy()
    strat = df[strat_col].astype(str) if strat_col in df else pd.Series("0", index=df.index)
    groups = df[group_col].astype(str)
    sgkf = StratifiedGroupKFold(n_splits=n_folds, shuffle=True, random_state=seed)
    _, test_idx = list(sgkf.split(df, strat, groups))[fold]
    df["split"] = "train"
    df.iloc[test_idx, df.columns.get_loc("split")] = "test"
    rest = df[df.split == "train"]
    nv = max(2, round(1 / max(val_frac, 1e-3)))
    sg2 = StratifiedGroupKFold(n_splits=nv, shuffle=True, random_state=seed + 100 + fold)
    _, val_idx = next(sg2.split(rest, strat[rest.index], groups[rest.index]))
    df.loc[rest.index[val_idx], "split"] = "val"
    df["fold"] = fold
    return df


def build_image_labels(inv: pd.DataFrame, breasts: pd.DataFrame, standard_only=True) -> pd.DataFrame:
    """Une el inventario DICOM (una fila por imagen) con las etiquetas por mama de los reportes."""
    inv = inv.copy()
    if standard_only and "is_standard_view" in inv:
        inv = inv[inv.is_standard_view.astype(str).isin(["True", "true", "1"])]
    keep = [c for c in breasts.columns if c not in ("density",)] + ["density"]
    m = inv.merge(breasts[keep], on=["patient_id", "laterality"], how="left")
    # imágenes sin lateralidad: sólo si ambas mamas de la paciente tienen la misma etiqueta
    unk = inv[inv.laterality == "U"]
    if len(unk):
        same = breasts.groupby("patient_id").y_malig.nunique() == 1
        lab = breasts.drop_duplicates("patient_id").set_index("patient_id")
        for i, r in unk.iterrows():
            if same.get(r.patient_id, False):
                row = lab.loc[r.patient_id]
                m.loc[m.image_id == r.image_id, ["y_malig", "y_birads", "y_density", "label_source"]] = \
                    [row.y_malig, -1, row.y_density, "paciente(U)"]
    for c in ("y_malig", "y_birads", "y_density"):
        m[c] = pd.to_numeric(m[c], errors="coerce").fillna(-1).astype(int)
    m["breast_id"] = m.patient_id + "_" + m.laterality
    return m
