Copie aquí classifier.pt y captioner.pt entrenados (no se suben a git).
