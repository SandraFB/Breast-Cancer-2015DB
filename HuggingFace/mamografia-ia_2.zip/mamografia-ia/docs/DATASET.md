# Base de datos de mamografías 2015 (tesis De la Fuente, CICATA-IPN)

## Lo que contienen los ZIP

| Archivo | Contenido | Uso en el pipeline |
|---|---|---|
| `DB-2015-IMG.zip` → `prueba/` | 981 mamografías JPEG (205 IDs de paciente), en **negativo** (fondo blanco), resoluciones de 880×1196 a 3540×4740 | Imágenes de entrada |
| `DB-segmentation-2015.zip` → `segmentation/` | 101 imágenes con las ROIs del CADe de la tesis dibujadas como **contornos verdes** | Comparación con el CADe en Python y con Grad-CAM. **No son verdad de referencia**: incluyen falsos positivos |

**No incluyen etiquetas** benigno/maligno ni los reportes de los radiólogos. La tesis menciona que la
base original (1500 imágenes, BI-RADS 3-5, Hospital General de Salamanca y UNEME-DEDICAM Querétaro)
registró ubicación, extensión y diagnóstico de las lesiones. Ese registro es lo que se debe capturar en
`data/labels/labels.csv`.

## Convención de nombres (verificada con los marcadores impresos en las placas)

| Patrón | Ejemplo | Significado |
|---|---|---|
| `PPPV.jpg` | `0253.jpg` | paciente 025, vista 3 |
| `PPPeSV.jpeg` | `208e54.jpeg` | paciente 208, estudio 5, vista 4 |

| Vista V | Lateralidad | Proyección |
|---|---|---|
| 1 | Izquierda (L) | CC |
| 2 | Derecha (R) | CC |
| 3 | Izquierda (L) | MLO |
| 4 | Derecha (R) | MLO |

En `segmentation/` hay además `PPb3lcc6.jpeg` → paciente PP, **BI-RADS 3**, mama izquierda, CC.

## Hallazgos de calidad del inventario (`python -m mamoia.data.inventory`)

- 20 duplicados detectados por hash perceptual:
  - el estudio `131e*` es idéntico a `127e*` y `187e*` a `163e*` (mismas 8 imágenes con otro ID de paciente);
  - `0112 (2).jpg` es en realidad la imagen `0042`;
  - `0173`, `0192`, `0194` existen en `.jpg` y `.jpeg` (misma placa, distinta resolución).
  El inventario marca `is_duplicate` y **fusiona sus grupos de paciente**, para que un duplicado nunca
  quede en train y su gemelo en test (fuga de datos).
- `ccNaN.jpg` y `mloNaN.jpg` no siguen la convención: revisar manualmente.
- `1091-1094` ya están en positivo (fondo negro); el preprocesamiento lo detecta automáticamente.
- **Privacidad**: algunas placas tienen el **apellido de la paciente impreso**. El preprocesamiento
  conserva sólo la mama (todo lo demás se pone en negro). Nunca suban las imágenes originales a
  repositorios públicos ni al LLM; el LLM sólo recibe datos numéricos/textuales.

## Cómo llenar `labels.csv`

Copien `labels_template.csv` a `labels.csv` y llenen por imagen (vacío = desconocido; el modelo lo ignora):

| Columna | Valores |
|---|---|
| `birads` | 0-6 |
| `pathology` | `normal`, `benigno`, `maligno` |
| `biopsy_confirmed` | 1 si la patología viene de biopsia |
| `density` | A, B, C, D |
| `lesion_type` | `masa`, `asimetria`, `microcalcificaciones`, `distorsion`, `ganglio`, `ninguna` |
| `lesion_shape` | `redonda`, `oval`, `irregular` |
| `lesion_margin` | `circunscrito`, `oscurecido`, `microlobulado`, `indistinto`, `espiculado` |
| `lesion_quadrant` | `CSE`, `CSI`, `CIE`, `CII`, `retroareolar`, `axilar` |
| `depth_zone` | `anterior`, `media`, `posterior` (zonas de profundidad de la tesis) |
| `lesion_size_mm` | número |
| `report_text` | texto libre del radiólogo (si existe, el LSTM aprende de él) |

Si sólo hay BI-RADS, la etiqueta benigno/maligno se deriva así: BI-RADS 4-6 → maligno (proxy),
1-2 → benigno, 3 → benigno (configurable). Reporten en su trabajo cuántas etiquetas vienen de biopsia
y cuántas del proxy BI-RADS: no es lo mismo.

---

# Estudios DICOM + reportes de radiología (Paciente_001 … Paciente_119)

| Fuente | Contenido |
|---|---|
| Carpeta compartida de Drive | Una carpeta por paciente (`Paciente_008/00000001…00000004`), archivos DICOM sin extensión |
| `PX_1-15_B3-B4-B5.xlsx` | 15 reportes: 5 BI-RADS 3, 5 BI-RADS 4, 5 BI-RADS 5 |
| `PX_16-53_B3-B4-B5.xlsx` | 38 reportes BI-RADS 5 |
| `PX_54-119_B3-B4-B5.xlsx` | 66 reportes BI-RADS 4 (+ "Conducta a seguir": 62 biopsia, 3 ultrasonido, 1 anual) |

Lo que el extractor por reglas (`mamoia.text.report_parser`) obtiene de los 119 reportes:

| Campo | Resultado |
|---|---|
| BI-RADS | 3: 5 · 4: 71 · 5: 43 (subcategoría 4a: 20, 4b: 30, 4c: 12) |
| Densidad ACR | A 14 · B 40 · C 48 · D 6 · sin dato 11 |
| Lateralidad del hallazgo | izquierda 49 · derecha 42 · bilateral 13 · no determinada 15 |
| Lesión principal | masa/nódulo 80 · microcalcificaciones 17 · asimetría 6 · distorsión 2 · ninguna 14 |
| Biopsia en el addendum | maligna 3 (pac. 020, 029, 072) · benigna 3 (054, 060, 097) · pendiente 9 |

Puntos a cuidar:

- **No hay controles BI-RADS 1-2.** Los negativos salen de la mama contralateral cuando el hallazgo es
  unilateral (etiqueta débil). La etiqueta "maligno" es la categoría del radiólogo, salvo las 6 biopsias.
- Los reportes traen **nombres de médicos y fechas** en los addenda: `anonymize()` los elimina antes de
  guardar el texto o enviarlo a un LLM.
- Pacientes 034, 041 y 046 tienen antecedente de cáncer o mastectomía (mama única): se excluye la
  contralateral como negativo.
- Revisen `reportes_extraidos_revision.xlsx` con el radiólogo: lateralidad y tipo de lesión son los
  campos más propensos a error del extractor.
