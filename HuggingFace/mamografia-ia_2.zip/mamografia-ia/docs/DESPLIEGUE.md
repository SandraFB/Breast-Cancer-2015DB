# Despliegue: Colab → Hugging Face → Lovable (MammoAI Assistant)

```
 MammoAI Assistant (Lovable, TanStack Start)
   ├─ Lovable Cloud: Auth · tablas · RLS · buckets mamografias/resultados · Realtime
   └─ funciones de servidor (src/lib/mamoia.functions.ts)  ──x-api-key──►  API MamoIA
                                                                           Hugging Face Space
                                                                           QSandradelaf/mammoai-api
                                                                           (classifier.pt + captioner.pt)
```

1. **Modelos** — `MamoIA_Colab_DICOM.ipynb` deja `classifier.pt`, `captioner.pt` y `model_card.json` en
   `MyDrive/MamoIA/export_api`.
2. **API** — `MamoIA_Deploy_HF.ipynb` (CPU basta): necesita el secreto de Colab `HF_TOKEN` (Write) y,
   opcional, `ANTHROPIC_API_KEY`. Crea el Space `QSandradelaf/mammoai-api`, sube código + modelos,
   genera la clave `MAMOIA_API_KEY` (guardada en `export_api/mamoia_api_key.txt`) y prueba la API con un
   DICOM real. URL: `https://qsandradelaf-mammoai-api.hf.space`.
3. **Lovable** — en el proyecto *MammoAI Assistant* → Settings → Secrets: `MAMOIA_API_KEY` = la clave que
   imprime el notebook (`MAMOIA_API_URL` ya está guardado).
4. **Roles** — regístrate en la app y pide a Claude (o ejecuta en Cloud → SQL) que te asigne `docente`:
   `insert into user_roles (user_id, role) select id, 'docente' from auth.users where email = '<tu correo>';`
5. **GitHub** — en Lovable: GitHub → Connect → crea el repositorio `mammoai-assistant` (sincronización
   bidireccional). El código de IA vive en este repo (`mamografia-ia`).
6. **Actualizar el modelo** — reentrena en Colab y vuelve a ejecutar `MamoIA_Deploy_HF.ipynb`; la app
   no cambia.

Notas
- El Space gratuito se duerme tras inactividad: la primera petición puede tardar 1-2 min (la app lo
  avisa y reintenta).
- La API no guarda imágenes ni tiene credenciales de la base de datos; sólo la app escribe en Cloud.
- Exporta las revisiones (`/tablero` → CSV) para reentrenar con etiquetas validadas por el radiólogo.
