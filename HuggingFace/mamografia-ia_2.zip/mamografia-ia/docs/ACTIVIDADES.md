# Actividades sugeridas para los equipos

| Semana | Entregable | Notebook | Criterio de evaluación |
|---|---|---|---|
| 1 | Inventario, limpieza de duplicados y 100+ imágenes etiquetadas con su radiólogo/docente | 01 | Calidad y trazabilidad de las etiquetas (fuente: biopsia vs. BI-RADS) |
| 2 | CADe clásico de la tesis: comparar ROIs Python vs. contornos 2015 (Dice) | 01 | Explicar cada etapa (Top-Hat, CLAHE, Perona-Malik, Tsallis) |
| 3-4 | Clasificador: preentreno CBIS-DDSM + ajuste local | 02 | AUC con IC 95 % (bootstrap), sensibilidad a especificidad 0.80, split por paciente |
| 5 | Grad-CAM vs. ROIs del CADe vs. ubicación anotada | 02 | Análisis crítico de errores (5 FP y 5 FN comentados) |
| 6-7 | CNN-LSTM con atención | 03 | BLEU-4 y coincidencia clínica (BI-RADS/lesión) en validación |
| 8 | Reporte con LLM: template vs. Claude vs. Ollama | 04 | % de reportes sin `validation_issues`; evaluación ciega por el radiólogo (escala 1-5) |
| 9-10 | App web Lovable + Supabase desplegada | 05 | Flujo completo subir → analizar → revisar → exportar |

## Experimentos para subir la nota

1. Backbone: `efficientnet_b0` vs. `convnext_tiny` vs. `resnet50` (`--set classifier.backbone=...`).
2. Resolución: 512×256 vs. 1024×512 (lesiones pequeñas y microcalcificaciones).
3. Fusión de vistas: promediar CC + MLO de la misma mama antes de decidir.
4. Reemplazar el LSTM por un decodificador Transformer y comparar.
5. Prompting: pedir al LLM una sección de "diagnósticos diferenciales" y medir alucinaciones.
6. Calibración (Platt / temperature scaling) y curva de fiabilidad.

## Ética y protección de datos (obligatorio en el informe)

- Base anonimizada: sólo códigos, nada de nombres; recorte que elimina rótulos impresos.
- Ninguna imagen de paciente en GitHub, Colab público ni prompts de LLM.
- Consentimiento/convenio de uso de datos con las unidades médicas (como en la tesis original).
- Declarar que es un borrador de apoyo y que la decisión es del radiólogo.
