# Prompt para construir la app web en Lovable

Antes de pegar el prompt:

1. En Lovable, crea el proyecto y conecta **Supabase** (botón *Supabase* → tu proyecto).
2. En Supabase → *SQL Editor*, ejecuta `supabase/migrations/0001_mamoia_init.sql`
   (o pídele a Lovable que aplique esa migración).
3. Despliega la Edge Function `supabase/functions/analyze` (Lovable puede crearla si le pegas el código)
   y define sus *secrets*: `MAMOIA_API_URL` y `MAMOIA_API_KEY`.
4. Conecta **GitHub** desde Lovable (*GitHub → Connect*): Lovable sincroniza el frontend en su propio
   repositorio. Este repo (`mamografia-ia`) queda para la parte de Python/IA.

---

## Prompt (copiar y pegar en Lovable)

```
Construye "MamoIA", una aplicación web en español para docencia en inteligencia artificial aplicada a
mastografía. Usa React + Tailwind + shadcn/ui y el Supabase ya conectado (las tablas existen:
profiles, studies, images, analyses, reviews, vista labeled_for_training; buckets privados
"mamografias" y "resultados"). No crees tablas nuevas sin preguntarme.

AVISO PERMANENTE (banner en todas las páginas, no se puede cerrar):
"Herramienta educativa y de investigación. No es un dispositivo médico. Los resultados son
borradores que debe validar un médico radiólogo."

AUTENTICACIÓN
- Supabase Auth con correo y contraseña. Al registrarse se crea su fila en `profiles` con rol
  'estudiante'. Muestra el rol del usuario en el menú. Sólo 'docente' o 'radiologo' ven el módulo
  de Revisión.

PÁGINAS
1. /estudios — tabla de estudios del usuario (code, fecha, nº de imágenes, último estado de análisis).
   Botón "Nuevo estudio": pide un CÓDIGO seudónimo (ej. EST-0208) y valida que no parezca un nombre
   propio (advierte si contiene dos palabras con mayúscula). Nunca pedir nombre, CURP ni fecha de nacimiento.
2. /estudios/:id — cuatro tarjetas para las vistas estándar: CC izquierda, CC derecha, MLO izquierda,
   MLO derecha. Cada tarjeta permite subir una imagen JPG/PNG (máx. 30 MB) a
   storage "mamografias" en la ruta `{auth.uid()}/{study_id}/{uuid}.{ext}` y crea la fila en `images`
   con laterality ('L'|'R') y projection ('CC'|'MLO').
   Botón "Analizar" por imagen con un selector de redactor: "Plantilla (sin LLM)", "Claude", "Ollama (local)".
   Al pulsar: `supabase.functions.invoke('analyze', { body: { image_id, llm_backend } })`.
   Muestra el estado (pending → processing → done/error) escuchando cambios en `analyses` con Supabase
   Realtime filtrando por image_id.
3. /analisis/:id — visor de resultados:
   - Izquierda: la mamografía con pestañas "Original", "Grad-CAM (CNN)", "Atención LSTM", "CADe tesis 2015".
     Las imágenes de resultado están en el bucket "resultados" (heatmap_path, attention_path, cade_path);
     usa createSignedUrl. Permite zoom y paneo.
   - Derecha:
     * Indicador de probabilidad de malignidad (prob_malignancy) como barra 0-100 % con el umbral marcado.
     * Categoría BI-RADS sugerida (birads_suggested) en una insignia con color: 1-2 verde, 3 ámbar,
       4-5 rojo, 0 gris.
     * Densidad predicha (density_pred).
     * "Descripción generada por la red LSTM" (caption_lstm) en un bloque citado.
     * "Borrador de reporte" (report_md renderizado como Markdown).
     * Lista de recomendaciones (report.recomendaciones).
     * Si validation_issues no está vacío, mostrar alerta "El LLM intentó contradecir las reglas; se corrigió".
     * Pie: model_version, llm_backend, fecha.
4. /revision (sólo docente/radiologo) — cola de análisis con status 'done' sin revisión. Formulario que
   inserta en `reviews`: ¿de acuerdo? (sí/no), BI-RADS final (0-6), patología (normal/benigno/maligno),
   ¿confirmado por biopsia?, densidad (A-D), tipo de lesión, reporte corregido (texto), comentarios.
5. /tablero — métricas para clase: nº de análisis, distribución de BI-RADS sugerido vs final, tasa de
   acuerdo IA-radiólogo, y una tabla de concordancia (matriz de confusión) a partir de la vista
   labeled_for_training. Botón "Exportar CSV" de esa vista.

DISEÑO
- Sobrio, clínico, modo claro y oscuro, tipografía legible, accesible (contraste AA).
- Visor de imagen con fondo negro. Textos de la IA siempre etiquetados como "Generado por IA".
- Manejo de errores visible (si status = 'error', mostrar analyses.error).
```

## Prompts de seguimiento útiles

- "Añade en /estudios/:id un botón 'Analizar las 4 vistas' que invoque la función para cada imagen."
- "En el visor, permite comparar lado a lado la mama izquierda y derecha (misma proyección)."
- "En /tablero, agrega la curva de concordancia por backend de LLM (template vs claude vs ollama)."
