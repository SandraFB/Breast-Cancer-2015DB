# MamoIA — detección temprana de cáncer de mama con CNN, LSTM y LLM

Proyecto docente de inteligencia artificial basado en la tesis
*"Asistente computarizado para la detección de masas y asimetrías en mamografías: estudio por zonas de
profundidad"* (S. L. de la Fuente Bermúdez, CICATA-IPN Querétaro, 2015) y en su base de datos.

> **Aviso.** Herramienta educativa y de investigación. No es un dispositivo médico ni sustituye la
> interpretación de un radiólogo.

## ¿Qué hace?

```
mamografía ─► 1. Preprocesamiento + anonimización (recorte de la mama, negativo→positivo, CLAHE)
           ├─► 2. CADe clásico de la tesis (Top-Hat por zonas, difusión anisotrópica, Tsallis)  → ROIs
           ├─► 3. CNN multitarea (EfficientNet)  → P(maligno), BI-RADS, densidad  + Grad-CAM
           ├─► 4. CNN-LSTM con atención           → descripción en texto ("Se identifica masa…")
           └─► 5. Reglas BI-RADS + LLM (Claude / Ollama / plantilla) → borrador de reporte y
                  recomendaciones para el radiólogo, validado contra las reglas
```

El LLM **no ve la imagen ni datos personales**: recibe un JSON con las salidas de 2-4 y redacta. La
categoría y la conducta se calculan con reglas auditables (`llm/recommendations.py`); si el LLM las
contradice, el validador lo corrige y lo registra.

## Estructura

```
configs/default.yaml           hiperparámetros y rutas
src/mamoia/
  data/       inventory.py (nombres, duplicados, plantilla de etiquetas) · preprocess.py ·
              labels.py (objetivos, splits por paciente) · dataset.py · public_datasets.py (CBIS-DDSM)
  classic/    cade.py (tesis en Python) · thesis_segmentations.py (contornos verdes → máscaras)
  models/     classifier.py (CNN multitarea) · captioner.py (CNN-LSTM con atención, beam search)
  explain/    gradcam.py
  text/       report_templates.py (etiquetas → texto) · vocab.py
  llm/        recommendations.py · prompts.py · backends.py · report.py
  train/      train_classifier.py · train_captioner.py · common.py (métricas)
  pipeline.py inferencia de extremo a extremo
api/          FastAPI + Dockerfile (la usa la app web)
supabase/     migración SQL (tablas, RLS, storage) y Edge Function `analyze`
notebooks/    01-05 para Google Colab (en orden)
docs/         DATASET.md · LOVABLE_PROMPT.md · ACTIVIDADES.md
data/labels/  inventory.csv · labels_template.csv (981 imágenes listas para etiquetar)
```

## Notebook principal con DICOM + reportes

`notebooks/MamoIA_Colab_DICOM.ipynb` implementa todo el pipeline con los estudios DICOM de la carpeta de
Drive y los reportes en Excel: descarga → DICOM a PNG anonimizado → etiquetas desde los reportes →
validación cruzada por paciente → Grad-CAM/CADe → CNN-LSTM → reporte bilateral con LLM → exportación.

## Inicio rápido (Colab)

Abran `notebooks/01_datos_y_preprocesamiento.ipynb` en Colab (Entorno → GPU T4) y sigan en orden.
Localmente:

```bash
pip install -e ".[llm,api,dev]"
# 1. datos
python -m mamoia.data.inventory  --images data/raw/prueba --out data/labels/labels_template.csv
cp data/labels/labels_template.csv data/labels/labels.csv   # ...y llenarla
python -m mamoia.data.preprocess --images data/raw/prueba --out data/processed
# 2. clasificador: preentrenar con CBIS-DDSM y ajustar con la base local
python -m mamoia.train.train_classifier --source public --out checkpoints/cls_cbis.pt
python -m mamoia.train.train_classifier --source local --init checkpoints/cls_cbis.pt \
       --out checkpoints/classifier.pt --set train.lr=1e-4 --set train.epochs=15
# 3. captioner LSTM
python -m mamoia.train.train_captioner --classifier checkpoints/classifier.pt --source both
# 4. reporte
python -m mamoia.pipeline data/raw/prueba/0253.jpg --llm template   # o claude / ollama
```

## LLM

| Backend | Configuración | Cuándo |
|---|---|---|
| `template` | nada | pruebas, sin costo, determinista |
| `claude` | `ANTHROPIC_API_KEY`, opcional `CLAUDE_MODEL` (default `claude-sonnet-5-5`; económico: `claude-haiku-4-5`) | mejor redacción |
| `ollama` | `OLLAMA_HOST`, `OLLAMA_MODEL` (default `qwen2.5:7b-instruct`) | gratis, datos sin salir del servidor |

Revisen los modelos disponibles en <https://docs.claude.com/en/docs/about-claude/models>.

## App web: Lovable + Supabase + GitHub

```
 Lovable (React)  ──auth/DB/storage──►  Supabase  ──Edge Function `analyze`──►  API Python (FastAPI)
      │                                    ▲                                       │
      └── GitHub (repo frontend)           └──── escribe resultados (service role) ┘
```

1. **Supabase**: ejecutar `supabase/migrations/0001_mamoia_init.sql`; desplegar
   `supabase/functions/analyze` (`supabase functions deploy analyze`) con los secrets `MAMOIA_API_URL`
   y `MAMOIA_API_KEY`.
2. **API**: desplegar `api/Dockerfile` (p. ej. Hugging Face Spaces tipo Docker, Render o Railway) con
   `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `MAMOIA_API_KEY` y, si aplica, `ANTHROPIC_API_KEY`.
   Copiar los checkpoints entrenados a `checkpoints/`.
3. **Lovable**: conectar Supabase y GitHub, y pegar el prompt de `docs/LOVABLE_PROMPT.md`.
4. **Ciclo de mejora**: los radiólogos revisan en la app → `scripts/export_reviews_to_labels.py` →
   reentrenar.

**GitHub**: dos repositorios. Este (`mamografia-ia`, Python, notebooks y `supabase/`) y el que crea
Lovable para el frontend. Agreguen `data/raw/`, `data/processed/` y `checkpoints/` al `.gitignore`
(ya incluido): **nunca** suban imágenes de pacientes a GitHub.

## Limitaciones que los alumnos deben discutir

- Sin biopsia, la etiqueta "maligno" es un proxy del BI-RADS del radiólogo.
- La base es pequeña y de dos centros: hay que reportar intervalos de confianza y validar externamente.
- Las descripciones del LSTM aprenden de plantillas: miden capacidad de **estructurar** hallazgos, no
  de redactar como un radiólogo.
- Métrica clínica primaria: **sensibilidad a especificidad fija** (y AUC), no exactitud.
